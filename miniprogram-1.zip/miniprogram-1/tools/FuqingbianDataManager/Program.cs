using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace FuqingbianDataManager
{
    internal static class Program
    {
        [STAThread]
        private static int Main(string[] args)
        {
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072 | SecurityProtocolType.Tls;

            if (args.Length > 0 && args[0] == "--self-test")
            {
                return SelfTest.Run(args.Length > 1 ? args[1] : null);
            }
            if (args.Length > 0 && args[0] == "--ui-preview")
            {
                string previewPath = args.Length > 1 ? args[1] : Path.Combine(Path.GetTempPath(), "fu-manager-preview.png");
                string familyPath = ProjectLocator.FindFamilyFile(args.Length > 2 ? args[2] : null);
                using (MainForm previewForm = new MainForm(familyPath))
                {
                    previewForm.Size = new Size(1280, 820);
                    previewForm.ShowInTaskbar = false;
                    previewForm.Opacity = 0;
                    previewForm.Show();
                    Application.DoEvents();
                    using (Bitmap preview = new Bitmap(previewForm.Width, previewForm.Height))
                    {
                        previewForm.DrawToBitmap(preview, new Rectangle(Point.Empty, previewForm.Size));
                        preview.Save(previewPath);
                    }
                    previewForm.Close();
                }
                return 0;
            }
            if (args.Length > 0 && args[0] == "--export-cloud")
            {
                string exportPath = ProjectLocator.FindFamilyFile(args.Length > 1 ? args[1] : null);
                FamilyDataStore exportStore = new FamilyDataStore(exportPath);
                exportStore.Load();
                exportStore.ExportCloudJson();
                return 0;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            string requestedPath = args.Length > 0 ? args[0] : null;
            Application.Run(new MainForm(ProjectLocator.FindFamilyFile(requestedPath)));
            return 0;
        }
    }

    internal static class ProjectLocator
    {
        public static string FindFamilyFile(string requestedPath)
        {
            if (!String.IsNullOrWhiteSpace(requestedPath))
            {
                string full = Path.GetFullPath(requestedPath.Trim('"'));
                if (File.Exists(full)) return full;
            }

            DirectoryInfo current = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory);
            for (int i = 0; i < 8 && current != null; i++, current = current.Parent)
            {
                string candidate = Path.Combine(current.FullName, "miniprogram", "data", "family.ts");
                if (File.Exists(candidate)) return candidate;
            }

            return requestedPath;
        }
    }

    internal sealed class FamilyMember
    {
        public string Id = "";
        public string Name = "";
        public string Gender = "男";
        public int Generation = 1;
        public string GenerationName = "";
        public string Branch = "";
        public int BirthYear = DateTime.Now.Year;
        public int? DeathYear;
        public string FatherId = "";
        public string MotherId = "";
        public List<string> SpouseIds = new List<string>();
        public string Region = "";
        public string Role = "";
        public string CourtesyName = "";
        public string Bio = "";
        public string Story = "";

        public FamilyMember Clone()
        {
            return new FamilyMember
            {
                Id = Id,
                Name = Name,
                Gender = Gender,
                Generation = Generation,
                GenerationName = GenerationName,
                Branch = Branch,
                BirthYear = BirthYear,
                DeathYear = DeathYear,
                FatherId = FatherId,
                MotherId = MotherId,
                SpouseIds = new List<string>(SpouseIds),
                Region = Region,
                Role = Role,
                CourtesyName = CourtesyName,
                Bio = Bio,
                Story = Story
            };
        }
    }

    internal sealed class CloudSyncResult
    {
        public int MemberCount;
        public string ResponseText = "";
    }

    internal sealed class CloudSyncConfig
    {
        public string ConfigPath = "";
        public string SyncUrl = "";
        public string SyncToken = "";

        public bool IsConfigured
        {
            get { return !String.IsNullOrWhiteSpace(SyncUrl) && !String.IsNullOrWhiteSpace(SyncToken); }
        }

        public static CloudSyncConfig LoadOrCreate(string path)
        {
            if (!File.Exists(path))
            {
                string template = "{\r\n"
                    + "  \"syncUrl\": \"\",\r\n"
                    + "  \"syncToken\": \"\"\r\n"
                    + "}\r\n";
                File.WriteAllText(path, template, new UTF8Encoding(false));
            }

            string text = File.ReadAllText(path, Encoding.UTF8);
            return new CloudSyncConfig
            {
                ConfigPath = path,
                SyncUrl = ReadJsonString(text, "syncUrl"),
                SyncToken = ReadJsonString(text, "syncToken")
            };
        }

        private static string ReadJsonString(string source, string field)
        {
            Match match = Regex.Match(source, "\"" + Regex.Escape(field) + "\"\\s*:\\s*\"((?:\\\\.|[^\"])*)\"", RegexOptions.Singleline);
            return match.Success ? UnescapeJson(match.Groups[1].Value) : "";
        }

        private static string UnescapeJson(string value)
        {
            StringBuilder result = new StringBuilder();
            bool escaped = false;
            foreach (char c in value)
            {
                if (!escaped)
                {
                    if (c == '\\') escaped = true;
                    else result.Append(c);
                    continue;
                }
                if (c == 'n') result.Append('\n');
                else if (c == 'r') result.Append('\r');
                else if (c == 't') result.Append('\t');
                else result.Append(c);
                escaped = false;
            }
            if (escaped) result.Append('\\');
            return result.ToString();
        }
    }

    internal sealed class FamilyDataStore
    {
        private const string StartMarker = "export const familyMembers: FamilyMember[] = [";
        private const string NextMarker = "export const familyArticles";
        private readonly UTF8Encoding utf8 = new UTF8Encoding(false);

        public string FilePath { get; private set; }
        public List<FamilyMember> Members { get; private set; }

        public FamilyDataStore(string filePath)
        {
            FilePath = filePath;
            Members = new List<FamilyMember>();
        }

        public void Load()
        {
            if (String.IsNullOrWhiteSpace(FilePath) || !File.Exists(FilePath))
                throw new FileNotFoundException("没有找到小程序数据文件 family.ts。", FilePath);

            string text = File.ReadAllText(FilePath, Encoding.UTF8);
            int start = text.IndexOf(StartMarker, StringComparison.Ordinal);
            int next = text.IndexOf(NextMarker, start + StartMarker.Length, StringComparison.Ordinal);
            if (start < 0 || next < 0)
                throw new InvalidDataException("family.ts 的数据结构与管理器不兼容。请恢复文件后重试。");

            int arrayEnd = text.LastIndexOf(']', next);
            if (arrayEnd < start) throw new InvalidDataException("没有找到族人数组的结束位置。");
            string body = text.Substring(start + StartMarker.Length, arrayEnd - start - StartMarker.Length);
            List<string> objects = SplitObjects(body);
            Members = objects.Select(ParseMember).ToList();
            Validate(Members);
        }

        public string Save()
        {
            Validate(Members);
            string original = File.ReadAllText(FilePath, Encoding.UTF8);
            int start = original.IndexOf(StartMarker, StringComparison.Ordinal);
            int next = original.IndexOf(NextMarker, start + StartMarker.Length, StringComparison.Ordinal);
            int arrayEnd = original.LastIndexOf(']', next);
            if (start < 0 || next < 0 || arrayEnd < start)
                throw new InvalidDataException("无法安全定位族人数据，已取消保存。");

            string newline = original.Contains("\r\n") ? "\r\n" : "\n";
            StringBuilder block = new StringBuilder();
            block.Append(StartMarker).Append(newline);
            for (int i = 0; i < Members.Count; i++)
            {
                block.Append("  ").Append(SerializeMember(Members[i])).Append(',').Append(newline);
                if (i + 1 < Members.Count && Members[i + 1].Generation != Members[i].Generation)
                    block.Append(newline);
            }
            block.Append(']');

            string updated = original.Substring(0, start) + block + original.Substring(arrayEnd + 1);
            string projectRoot = Directory.GetParent(Directory.GetParent(Directory.GetParent(FilePath).FullName).FullName).FullName;
            string backupDir = Path.Combine(projectRoot, "backups", "family-data");
            Directory.CreateDirectory(backupDir);
            string backup = Path.Combine(backupDir, "family_" + DateTime.Now.ToString("yyyyMMdd_HHmmss_fff") + ".ts");
            File.Copy(FilePath, backup, false);

            string temp = FilePath + ".manager.tmp";
            File.WriteAllText(temp, updated, utf8);
            try
            {
                File.Replace(temp, FilePath, null);
            }
            catch (PlatformNotSupportedException)
            {
                File.Delete(FilePath);
                File.Move(temp, FilePath);
            }
            catch (IOException)
            {
                File.Delete(FilePath);
                File.Move(temp, FilePath);
            }
            return backup;
        }

        public string GetBackupDirectory()
        {
            return Path.Combine(GetProjectRoot(), "backups", "family-data");
        }

        public string ExportCloudJson()
        {
            Validate(Members);
            string exportDir = Path.Combine(GetProjectRoot(), "exports");
            Directory.CreateDirectory(exportDir);
            string exportPath = Path.Combine(exportDir, "family_members_cloud.json");
            File.WriteAllText(exportPath, SerializeMembersJsonArray(), utf8);
            return exportPath;
        }

        public CloudSyncResult SyncCloudDatabase()
        {
            Validate(Members);
            CloudSyncConfig config = CloudSyncConfig.LoadOrCreate(GetCloudSyncConfigPath());
            string payload = "{"
                + "\"token\":\"" + EscapeJson(config.SyncToken) + "\","
                + "\"members\":" + SerializeMembersJsonArray()
                + "}";
            string body = PostCloudRequest(config, payload, "同步云数据库失败。");
            if (body.IndexOf("\"ok\":true", StringComparison.OrdinalIgnoreCase) < 0)
                throw new InvalidOperationException("云函数返回失败：\n" + body);
            return new CloudSyncResult { ResponseText = body, MemberCount = Members.Count };
        }

        public CloudSyncResult PullCloudDatabase()
        {
            CloudSyncConfig config = CloudSyncConfig.LoadOrCreate(GetCloudSyncConfigPath());
            string payload = "{"
                + "\"token\":\"" + EscapeJson(config.SyncToken) + "\","
                + "\"action\":\"pull\""
                + "}";
            string body = PostCloudRequest(config, payload, "从云端更新失败。");
            if (body.IndexOf("\"ok\":true", StringComparison.OrdinalIgnoreCase) < 0)
                throw new InvalidOperationException("云函数返回失败：\n" + body);

            List<FamilyMember> cloudMembers = ParseCloudMembersResponse(body);
            if (cloudMembers.Count == 0) throw new InvalidDataException("云端没有返回族人数据，已取消覆盖本地。");
            Validate(cloudMembers);
            Members = cloudMembers.OrderBy(delegate(FamilyMember item) { return item.Generation; }).ThenBy(delegate(FamilyMember item) { return item.Id; }).ToList();
            return new CloudSyncResult { ResponseText = body, MemberCount = Members.Count };
        }

        private string PostCloudRequest(CloudSyncConfig config, string payload, string errorPrefix)
        {
            if (!config.IsConfigured)
            {
                throw new InvalidOperationException("还没有配置云端同步地址和口令。\n\n已生成配置文件：\n" + config.ConfigPath + "\n\n请先部署 syncfamilymembers 云函数，再把 HTTP 访问地址和 SYNC_TOKEN 填进去。");
            }
            byte[] bytes = utf8.GetBytes(payload);
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(config.SyncUrl);
            request.Method = "POST";
            request.ContentType = "application/json; charset=utf-8";
            request.Timeout = 30000;
            request.Headers["X-Sync-Token"] = config.SyncToken;
            request.ContentLength = bytes.Length;
            using (Stream stream = request.GetRequestStream())
            {
                stream.Write(bytes, 0, bytes.Length);
            }

            try
            {
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                using (StreamReader reader = new StreamReader(response.GetResponseStream(), Encoding.UTF8))
                {
                    string body = reader.ReadToEnd();
                    return body;
                }
            }
            catch (WebException ex)
            {
                string errorBody = "";
                if (ex.Response != null)
                {
                    using (StreamReader reader = new StreamReader(ex.Response.GetResponseStream(), Encoding.UTF8))
                        errorBody = reader.ReadToEnd();
                }
                throw new InvalidOperationException(errorPrefix + (String.IsNullOrWhiteSpace(errorBody) ? "\n" + ex.Message : "\n" + errorBody), ex);
            }
        }

        public string GetProjectRoot()
        {
            return Directory.GetParent(Directory.GetParent(Directory.GetParent(FilePath).FullName).FullName).FullName;
        }

        public string GetCloudSyncConfigPath()
        {
            return Path.Combine(GetProjectRoot(), "tools", "FuqingbianDataManager", "cloud-sync.json");
        }

        public string GetNextId()
        {
            int max = 0;
            foreach (FamilyMember member in Members)
            {
                Match match = Regex.Match(member.Id ?? "", @"(\d+)$");
                int value;
                if (match.Success && Int32.TryParse(match.Groups[1].Value, out value)) max = Math.Max(max, value);
            }
            return "f" + (max + 1).ToString("000");
        }

        public void SyncSpouses(FamilyMember saved)
        {
            foreach (FamilyMember member in Members)
            {
                if (member.Id == saved.Id) continue;
                member.SpouseIds.RemoveAll(delegate(string id) { return id == saved.Id; });
            }
            foreach (string spouseId in saved.SpouseIds.Distinct().ToList())
            {
                FamilyMember spouse = Members.FirstOrDefault(delegate(FamilyMember item) { return item.Id == spouseId; });
                if (spouse != null && !spouse.SpouseIds.Contains(saved.Id)) spouse.SpouseIds.Add(saved.Id);
            }
        }

        public void DeleteAndClean(string id)
        {
            Members.RemoveAll(delegate(FamilyMember member) { return member.Id == id; });
            foreach (FamilyMember member in Members)
            {
                member.SpouseIds.RemoveAll(delegate(string spouseId) { return spouseId == id; });
                if (member.FatherId == id) member.FatherId = "";
                if (member.MotherId == id) member.MotherId = "";
            }
        }

        public static void Validate(List<FamilyMember> members)
        {
            HashSet<string> ids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (FamilyMember member in members)
            {
                if (String.IsNullOrWhiteSpace(member.Id) || !Regex.IsMatch(member.Id, @"^[A-Za-z][A-Za-z0-9_-]*$"))
                    throw new InvalidDataException("成员编号“" + member.Id + "”无效，只能使用字母、数字、下划线和短横线，并以字母开头。");
                if (!ids.Add(member.Id)) throw new InvalidDataException("成员编号重复：" + member.Id);
                if (String.IsNullOrWhiteSpace(member.Name)) throw new InvalidDataException("成员 " + member.Id + " 缺少姓名。");
                if (member.Gender != "男" && member.Gender != "女") throw new InvalidDataException(member.Name + " 的性别无效。");
                if (member.Generation < 1 || member.Generation > 99) throw new InvalidDataException(member.Name + " 的世代应在 1 至 99 之间。");
                if (member.BirthYear < 1000 || member.BirthYear > DateTime.Now.Year + 1) throw new InvalidDataException(member.Name + " 的出生年份不合理。");
                if (member.DeathYear.HasValue && member.DeathYear.Value < member.BirthYear) throw new InvalidDataException(member.Name + " 的卒年不能早于出生年份。");
                if (member.SpouseIds.Contains(member.Id)) throw new InvalidDataException(member.Name + " 不能把自己设为配偶。");
            }

            foreach (FamilyMember member in members)
            {
                List<string> refs = new List<string>();
                if (!String.IsNullOrWhiteSpace(member.FatherId)) refs.Add(member.FatherId);
                if (!String.IsNullOrWhiteSpace(member.MotherId)) refs.Add(member.MotherId);
                refs.AddRange(member.SpouseIds);
                foreach (string reference in refs)
                    if (!ids.Contains(reference)) throw new InvalidDataException(member.Name + " 引用了不存在的成员编号：" + reference);
            }
        }

        private static List<string> SplitObjects(string body)
        {
            List<string> result = new List<string>();
            int depth = 0;
            int start = -1;
            bool inString = false;
            bool escaped = false;
            for (int i = 0; i < body.Length; i++)
            {
                char c = body[i];
                if (inString)
                {
                    if (escaped) escaped = false;
                    else if (c == '\\') escaped = true;
                    else if (c == '\'') inString = false;
                    continue;
                }
                if (c == '\'') { inString = true; continue; }
                if (c == '{')
                {
                    if (depth == 0) start = i;
                    depth++;
                }
                else if (c == '}')
                {
                    depth--;
                    if (depth == 0 && start >= 0)
                    {
                        result.Add(body.Substring(start, i - start + 1));
                        start = -1;
                    }
                }
            }
            if (depth != 0 || inString) throw new InvalidDataException("族人数据中存在未闭合的对象或字符串。");
            return result;
        }

        private static FamilyMember ParseMember(string source)
        {
            FamilyMember member = new FamilyMember();
            member.Id = ReadString(source, "id", true);
            member.Name = ReadString(source, "name", true);
            member.Gender = ReadString(source, "gender", true);
            member.Generation = ReadInt(source, "generation", true).Value;
            member.GenerationName = ReadString(source, "generationName", true);
            member.Branch = ReadString(source, "branch", true);
            member.BirthYear = ReadInt(source, "birthYear", true).Value;
            member.DeathYear = ReadInt(source, "deathYear", false);
            member.FatherId = ReadString(source, "fatherId", false);
            member.MotherId = ReadString(source, "motherId", false);
            member.SpouseIds = ReadStringArray(source, "spouseIds");
            member.Region = ReadString(source, "region", true);
            member.Role = ReadString(source, "role", false);
            member.CourtesyName = ReadString(source, "courtesyName", false);
            member.Bio = ReadString(source, "bio", true);
            member.Story = ReadString(source, "story", true);
            return member;
        }

        private static List<FamilyMember> ParseCloudMembersResponse(string source)
        {
            string array = ExtractJsonArray(source, "members");
            List<string> objects = SplitJsonObjects(array);
            return objects.Select(ParseCloudMember).ToList();
        }

        private static FamilyMember ParseCloudMember(string source)
        {
            FamilyMember member = new FamilyMember();
            member.Id = ReadJsonString(source, "id", true);
            member.Name = ReadJsonString(source, "name", true);
            member.Gender = ReadJsonString(source, "gender", true);
            member.Generation = ReadJsonInt(source, "generation", true).Value;
            member.GenerationName = ReadJsonString(source, "generationName", true);
            member.Branch = ReadJsonString(source, "branch", true);
            member.BirthYear = ReadJsonInt(source, "birthYear", true).Value;
            member.DeathYear = ReadJsonInt(source, "deathYear", false);
            member.FatherId = ReadJsonString(source, "fatherId", false);
            member.MotherId = ReadJsonString(source, "motherId", false);
            member.SpouseIds = ReadJsonStringArray(source, "spouseIds");
            member.Region = ReadJsonString(source, "region", true);
            member.Role = ReadJsonString(source, "role", false);
            member.CourtesyName = ReadJsonString(source, "courtesyName", false);
            member.Bio = ReadJsonString(source, "bio", true);
            member.Story = ReadJsonString(source, "story", true);
            return member;
        }

        private static string ExtractJsonArray(string source, string field)
        {
            Match fieldMatch = Regex.Match(source, "\"" + Regex.Escape(field) + "\"\\s*:", RegexOptions.Singleline);
            if (!fieldMatch.Success) throw new InvalidDataException("云端返回缺少字段：" + field);
            int start = source.IndexOf('[', fieldMatch.Index + fieldMatch.Length);
            if (start < 0) throw new InvalidDataException("云端返回的 " + field + " 不是数组。");

            int depth = 0;
            bool inString = false;
            bool escaped = false;
            for (int i = start; i < source.Length; i++)
            {
                char c = source[i];
                if (inString)
                {
                    if (escaped) escaped = false;
                    else if (c == '\\') escaped = true;
                    else if (c == '"') inString = false;
                    continue;
                }
                if (c == '"') { inString = true; continue; }
                if (c == '[') depth++;
                else if (c == ']')
                {
                    depth--;
                    if (depth == 0) return source.Substring(start + 1, i - start - 1);
                }
            }
            throw new InvalidDataException("云端返回的成员数组没有正常结束。");
        }

        private static List<string> SplitJsonObjects(string body)
        {
            List<string> result = new List<string>();
            int depth = 0;
            int start = -1;
            bool inString = false;
            bool escaped = false;
            for (int i = 0; i < body.Length; i++)
            {
                char c = body[i];
                if (inString)
                {
                    if (escaped) escaped = false;
                    else if (c == '\\') escaped = true;
                    else if (c == '"') inString = false;
                    continue;
                }
                if (c == '"') { inString = true; continue; }
                if (c == '{')
                {
                    if (depth == 0) start = i;
                    depth++;
                }
                else if (c == '}')
                {
                    depth--;
                    if (depth == 0 && start >= 0)
                    {
                        result.Add(body.Substring(start, i - start + 1));
                        start = -1;
                    }
                }
            }
            if (depth != 0 || inString) throw new InvalidDataException("云端成员数据中存在未闭合对象或字符串。");
            return result;
        }

        private static string ReadString(string source, string field, bool required)
        {
            Match match = Regex.Match(source, @"\b" + Regex.Escape(field) + @"\s*:\s*'((?:\\.|[^'])*)'", RegexOptions.Singleline);
            if (!match.Success)
            {
                if (required) throw new InvalidDataException("成员数据缺少字段：" + field);
                return "";
            }
            return Unescape(match.Groups[1].Value);
        }

        private static string ReadJsonString(string source, string field, bool required)
        {
            Match match = Regex.Match(source, "\"" + Regex.Escape(field) + "\"\\s*:\\s*\"((?:\\\\.|[^\"])*)\"", RegexOptions.Singleline);
            if (!match.Success)
            {
                if (required) throw new InvalidDataException("云端成员数据缺少字段：" + field);
                return "";
            }
            return UnescapeJson(match.Groups[1].Value);
        }

        private static int? ReadInt(string source, string field, bool required)
        {
            Match match = Regex.Match(source, @"\b" + Regex.Escape(field) + @"\s*:\s*(-?\d+)");
            if (!match.Success)
            {
                if (required) throw new InvalidDataException("成员数据缺少字段：" + field);
                return null;
            }
            return Int32.Parse(match.Groups[1].Value);
        }

        private static int? ReadJsonInt(string source, string field, bool required)
        {
            Match match = Regex.Match(source, "\"" + Regex.Escape(field) + "\"\\s*:\\s*(-?\\d+)", RegexOptions.Singleline);
            if (!match.Success)
            {
                if (required) throw new InvalidDataException("云端成员数据缺少字段：" + field);
                return null;
            }
            return Int32.Parse(match.Groups[1].Value);
        }

        private static List<string> ReadStringArray(string source, string field)
        {
            Match match = Regex.Match(source, @"\b" + Regex.Escape(field) + @"\s*:\s*\[([^\]]*)\]", RegexOptions.Singleline);
            List<string> result = new List<string>();
            if (!match.Success) return result;
            foreach (Match item in Regex.Matches(match.Groups[1].Value, @"'((?:\\.|[^'])*)'"))
                result.Add(Unescape(item.Groups[1].Value));
            return result;
        }

        private static List<string> ReadJsonStringArray(string source, string field)
        {
            Match match = Regex.Match(source, "\"" + Regex.Escape(field) + "\"\\s*:\\s*\\[([^\\]]*)\\]", RegexOptions.Singleline);
            List<string> result = new List<string>();
            if (!match.Success) return result;
            foreach (Match item in Regex.Matches(match.Groups[1].Value, "\"((?:\\\\.|[^\"])*)\""))
                result.Add(UnescapeJson(item.Groups[1].Value));
            return result;
        }

        private static string SerializeMember(FamilyMember member)
        {
            List<string> fields = new List<string>();
            fields.Add("id: '" + Escape(member.Id) + "'");
            fields.Add("name: '" + Escape(member.Name) + "'");
            fields.Add("gender: '" + Escape(member.Gender) + "'");
            fields.Add("generation: " + member.Generation);
            fields.Add("generationName: '" + Escape(member.GenerationName) + "'");
            fields.Add("branch: '" + Escape(member.Branch) + "'");
            fields.Add("birthYear: " + member.BirthYear);
            if (member.DeathYear.HasValue) fields.Add("deathYear: " + member.DeathYear.Value);
            if (!String.IsNullOrWhiteSpace(member.FatherId)) fields.Add("fatherId: '" + Escape(member.FatherId) + "'");
            if (!String.IsNullOrWhiteSpace(member.MotherId)) fields.Add("motherId: '" + Escape(member.MotherId) + "'");
            fields.Add("spouseIds: [" + String.Join(", ", member.SpouseIds.Select(delegate(string id) { return "'" + Escape(id) + "'"; }).ToArray()) + "]");
            fields.Add("region: '" + Escape(member.Region) + "'");
            if (!String.IsNullOrWhiteSpace(member.Role)) fields.Add("role: '" + Escape(member.Role) + "'");
            if (!String.IsNullOrWhiteSpace(member.CourtesyName)) fields.Add("courtesyName: '" + Escape(member.CourtesyName) + "'");
            fields.Add("bio: '" + Escape(member.Bio) + "'");
            fields.Add("story: '" + Escape(member.Story) + "'");
            return "{ " + String.Join(", ", fields.ToArray()) + " }";
        }

        private static string SerializeMemberJson(FamilyMember member)
        {
            List<string> fields = new List<string>();
            fields.Add("\"id\":\"" + EscapeJson(member.Id) + "\"");
            fields.Add("\"name\":\"" + EscapeJson(member.Name) + "\"");
            fields.Add("\"gender\":\"" + EscapeJson(member.Gender) + "\"");
            fields.Add("\"generation\":" + member.Generation);
            fields.Add("\"generationName\":\"" + EscapeJson(member.GenerationName) + "\"");
            fields.Add("\"branch\":\"" + EscapeJson(member.Branch) + "\"");
            fields.Add("\"birthYear\":" + member.BirthYear);
            if (member.DeathYear.HasValue) fields.Add("\"deathYear\":" + member.DeathYear.Value);
            if (!String.IsNullOrWhiteSpace(member.FatherId)) fields.Add("\"fatherId\":\"" + EscapeJson(member.FatherId) + "\"");
            if (!String.IsNullOrWhiteSpace(member.MotherId)) fields.Add("\"motherId\":\"" + EscapeJson(member.MotherId) + "\"");
            fields.Add("\"spouseIds\":[" + String.Join(",", member.SpouseIds.Select(delegate(string id) { return "\"" + EscapeJson(id) + "\""; }).ToArray()) + "]");
            fields.Add("\"region\":\"" + EscapeJson(member.Region) + "\"");
            if (!String.IsNullOrWhiteSpace(member.Role)) fields.Add("\"role\":\"" + EscapeJson(member.Role) + "\"");
            if (!String.IsNullOrWhiteSpace(member.CourtesyName)) fields.Add("\"courtesyName\":\"" + EscapeJson(member.CourtesyName) + "\"");
            fields.Add("\"bio\":\"" + EscapeJson(member.Bio) + "\"");
            fields.Add("\"story\":\"" + EscapeJson(member.Story) + "\"");
            return "{ " + String.Join(", ", fields.ToArray()) + " }";
        }

        private string SerializeMembersJsonArray()
        {
            StringBuilder json = new StringBuilder();
            json.AppendLine("[");
            for (int i = 0; i < Members.Count; i++)
            {
                json.Append("  ").Append(SerializeMemberJson(Members[i]));
                if (i + 1 < Members.Count) json.Append(',');
                json.AppendLine();
            }
            json.Append("]");
            return json.ToString();
        }

        private static string Escape(string value)
        {
            return (value ?? "").Replace("\\", "\\\\").Replace("'", "\\'").Replace("\r", "\\r").Replace("\n", "\\n");
        }

        private static string EscapeJson(string value)
        {
            return (value ?? "")
                .Replace("\\", "\\\\")
                .Replace("\"", "\\\"")
                .Replace("\r", "\\r")
                .Replace("\n", "\\n");
        }

        private static string UnescapeJson(string value)
        {
            StringBuilder result = new StringBuilder();
            bool escaped = false;
            foreach (char c in value)
            {
                if (!escaped)
                {
                    if (c == '\\') escaped = true;
                    else result.Append(c);
                    continue;
                }
                if (c == 'n') result.Append('\n');
                else if (c == 'r') result.Append('\r');
                else if (c == 't') result.Append('\t');
                else result.Append(c);
                escaped = false;
            }
            if (escaped) result.Append('\\');
            return result.ToString();
        }

        private static string Unescape(string value)
        {
            StringBuilder result = new StringBuilder();
            bool escaped = false;
            foreach (char c in value)
            {
                if (!escaped)
                {
                    if (c == '\\') escaped = true;
                    else result.Append(c);
                    continue;
                }
                if (c == 'n') result.Append('\n');
                else if (c == 'r') result.Append('\r');
                else if (c == 't') result.Append('\t');
                else result.Append(c);
                escaped = false;
            }
            if (escaped) result.Append('\\');
            return result.ToString();
        }
    }

    internal sealed class BorderPanel : Panel
    {
        public Color BorderColor { get; set; }
        public Color AccentColor { get; set; }

        public BorderPanel()
        {
            BorderColor = Color.FromArgb(190, 203, 188);
            AccentColor = Color.FromArgb(49, 92, 76);
            DoubleBuffered = true;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            Rectangle border = ClientRectangle;
            border.Width -= 1;
            border.Height -= 1;
            using (Pen line = new Pen(BorderColor))
            {
                e.Graphics.DrawRectangle(line, border);
            }
            using (Pen inner = new Pen(Color.FromArgb(105, Color.White)))
            {
                Rectangle innerBorder = new Rectangle(1, 1, Math.Max(0, Width - 3), Math.Max(0, Height - 3));
                e.Graphics.DrawRectangle(inner, innerBorder);
            }
            using (Brush accent = new SolidBrush(AccentColor))
            {
                e.Graphics.FillRectangle(accent, 0, 0, Width, 4);
            }
        }
    }

    internal sealed class AtmosphereHeaderPanel : Panel
    {
        public AtmosphereHeaderPanel()
        {
            DoubleBuffered = true;
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer, true);
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            Rectangle area = ClientRectangle;
            if (area.Width <= 0 || area.Height <= 0) return;

            using (LinearGradientBrush background = new LinearGradientBrush(
                area,
                Color.FromArgb(19, 54, 45),
                Color.FromArgb(46, 91, 72),
                LinearGradientMode.Horizontal))
            {
                e.Graphics.FillRectangle(background, area);
            }

            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            using (Brush glow = new SolidBrush(Color.FromArgb(22, 232, 222, 181)))
            {
                e.Graphics.FillEllipse(glow, Width - 430, -150, 520, 360);
            }

            DrawBamboo(e.Graphics, Width - 360, -22, 0.82F, 34);
            DrawBamboo(e.Graphics, Width - 210, -42, 0.66F, 22);
        }

        private static void DrawBamboo(Graphics graphics, int x, int y, float scale, int alpha)
        {
            Color stalkColor = Color.FromArgb(alpha, 207, 226, 183);
            using (Pen stalk = new Pen(stalkColor, 12F * scale))
            using (Pen highlight = new Pen(Color.FromArgb(Math.Min(255, alpha + 15), 235, 240, 213), 2F * scale))
            using (Pen branch = new Pen(Color.FromArgb(alpha, 193, 218, 166), 3F * scale))
            using (Brush leaf = new SolidBrush(Color.FromArgb(alpha + 10, 205, 229, 176)))
            {
                stalk.StartCap = LineCap.Round;
                stalk.EndCap = LineCap.Round;
                graphics.DrawLine(stalk, x, y, x - Convert.ToInt32(22 * scale), y + Convert.ToInt32(178 * scale));
                graphics.DrawLine(highlight, x - Convert.ToInt32(3 * scale), y, x - Convert.ToInt32(25 * scale), y + Convert.ToInt32(178 * scale));

                for (int i = 1; i <= 4; i++)
                {
                    int nodeY = y + Convert.ToInt32(i * 38 * scale);
                    int nodeX = x - Convert.ToInt32(i * 5 * scale);
                    graphics.DrawLine(branch, nodeX, nodeY, nodeX - Convert.ToInt32(72 * scale), nodeY - Convert.ToInt32(30 * scale));
                    graphics.DrawLine(branch, nodeX, nodeY + Convert.ToInt32(8 * scale), nodeX + Convert.ToInt32(64 * scale), nodeY - Convert.ToInt32(18 * scale));
                    DrawLeaf(graphics, leaf, nodeX - Convert.ToInt32(55 * scale), nodeY - Convert.ToInt32(25 * scale), -24F, scale);
                    DrawLeaf(graphics, leaf, nodeX - Convert.ToInt32(78 * scale), nodeY - Convert.ToInt32(39 * scale), -12F, scale);
                    DrawLeaf(graphics, leaf, nodeX + Convert.ToInt32(42 * scale), nodeY - Convert.ToInt32(20 * scale), 18F, scale);
                    DrawLeaf(graphics, leaf, nodeX + Convert.ToInt32(66 * scale), nodeY - Convert.ToInt32(29 * scale), 30F, scale);
                }
            }
        }

        private static void DrawLeaf(Graphics graphics, Brush brush, int x, int y, float angle, float scale)
        {
            GraphicsState state = graphics.Save();
            graphics.TranslateTransform(x, y);
            graphics.RotateTransform(angle);
            using (GraphicsPath path = new GraphicsPath())
            {
                path.AddBezier(0, 0, 15F * scale, -8F * scale, 33F * scale, -6F * scale, 48F * scale, 0);
                path.AddBezier(48F * scale, 0, 31F * scale, 7F * scale, 15F * scale, 8F * scale, 0, 0);
                graphics.FillPath(brush, path);
            }
            graphics.Restore(state);
        }
    }

    internal sealed class MainForm : Form
    {
        private static readonly Color DeepGreen = Color.FromArgb(25, 59, 50);
        private static readonly Color MidGreen = Color.FromArgb(49, 92, 76);
        private static readonly Color SoftGreen = Color.FromArgb(226, 232, 222);
        private static readonly Color WindowPaper = Color.FromArgb(244, 241, 232);
        private static readonly Color CardPaper = Color.FromArgb(253, 251, 246);
        private static readonly Color BorderGreen = Color.FromArgb(190, 203, 188);
        private static readonly Color TextMuted = Color.FromArgb(78, 91, 84);

        private readonly FamilyDataStore store;
        private readonly DataGridView grid = new DataGridView();
        private readonly SplitContainer mainSplit = new SplitContainer();
        private readonly TextBox searchBox = new TextBox();
        private readonly Label summaryLabel = new Label();
        private readonly Label statusLabel = new Label();
        private readonly TextBox idBox = new TextBox();
        private readonly TextBox nameBox = new TextBox();
        private readonly ComboBox genderBox = new ComboBox();
        private readonly NumericUpDown generationBox = new NumericUpDown();
        private readonly TextBox generationNameBox = new TextBox();
        private readonly TextBox branchBox = new TextBox();
        private readonly NumericUpDown birthYearBox = new NumericUpDown();
        private readonly TextBox deathYearBox = new TextBox();
        private readonly ComboBox fatherBox = new ComboBox();
        private readonly ComboBox motherBox = new ComboBox();
        private readonly TextBox spouseBox = new TextBox();
        private readonly TextBox regionBox = new TextBox();
        private readonly TextBox roleBox = new TextBox();
        private readonly TextBox courtesyNameBox = new TextBox();
        private readonly TextBox bioBox = new TextBox();
        private readonly TextBox storyBox = new TextBox();
        private string selectedId = "";
        private bool isNew;

        public MainForm(string familyFilePath)
        {
            store = new FamilyDataStore(familyFilePath);
            Text = "傅庭知源 · 数据管理器";
            Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
            StartPosition = FormStartPosition.CenterScreen;
            AutoScaleMode = AutoScaleMode.Dpi;
            AutoScaleDimensions = new SizeF(96F, 96F);
            MinimumSize = new Size(1120, 720);
            Size = new Size(1280, 820);
            Font = new Font("Microsoft YaHei UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            BackColor = WindowPaper;
            BuildUi();
            Shown += delegate
            {
                mainSplit.SplitterDistance = Math.Max(420, Convert.ToInt32(mainSplit.ClientSize.Width * 0.43));
                LoadData(true);
            };
        }

        private void BuildUi()
        {
            AtmosphereHeaderPanel header = new AtmosphereHeaderPanel { Dock = DockStyle.Top, Height = 148 };
            Panel brand = new Panel { Dock = DockStyle.Top, Height = 84, BackColor = Color.Transparent };
            PictureBox mark = new PictureBox { Size = new Size(52, 52), Location = new Point(25, 16), SizeMode = PictureBoxSizeMode.Zoom, BackColor = Color.Transparent };
            if (Icon != null) mark.Image = Icon.ToBitmap();
            Label title = new Label { Text = "傅庭知源", ForeColor = Color.White, Font = new Font("Microsoft YaHei UI", 20F, FontStyle.Bold), AutoSize = true, Location = new Point(91, 13), BackColor = Color.Transparent };
            Label subtitle = new Label { Text = "族人数据管理器  ·  云端同步与本地备份", ForeColor = Color.FromArgb(215, 231, 221), Font = new Font("Microsoft YaHei UI", 9.5F), AutoSize = true, Location = new Point(94, 51), BackColor = Color.Transparent };
            Label motto = new Label { Text = "敬宗睦族  ·  数字续谱", Dock = DockStyle.Right, Width = 290, ForeColor = Color.FromArgb(195, 225, 207), Font = new Font("KaiTi", 13F, FontStyle.Bold), TextAlign = ContentAlignment.MiddleCenter, BackColor = Color.Transparent };
            brand.Controls.Add(mark);
            brand.Controls.Add(title);
            brand.Controls.Add(subtitle);
            brand.Controls.Add(motto);

            Panel actionBar = new Panel { Dock = DockStyle.Bottom, Height = 64, BackColor = Color.FromArgb(238, 243, 235), Padding = new Padding(18, 11, 18, 10) };
            Label actionHint = new Label { Text = "数据操作", Dock = DockStyle.Left, Width = 92, ForeColor = DeepGreen, Font = new Font("Microsoft YaHei UI", 10F, FontStyle.Bold), TextAlign = ContentAlignment.MiddleLeft };
            FlowLayoutPanel actions = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft, WrapContents = false, AutoScroll = true, BackColor = Color.Transparent };
            actions.Controls.Add(MakeButton("保存修改", SaveMember, ManagerButtonStyle.Primary));
            actions.Controls.Add(MakeButton("一键同步云端", SyncCloudData, ManagerButtonStyle.Primary));
            actions.Controls.Add(MakeButton("从云端更新", PullCloudData, ManagerButtonStyle.Secondary));
            actions.Controls.Add(MakeButton("新增族人", NewMember, ManagerButtonStyle.Secondary));
            actions.Controls.Add(MakeButton("重新加载", delegate { LoadData(false); }, ManagerButtonStyle.Secondary));
            actions.Controls.Add(MakeButton("导出云数据", ExportCloudData, ManagerButtonStyle.Secondary));
            actions.Controls.Add(MakeButton("备份目录", OpenBackups, ManagerButtonStyle.Secondary));
            actions.Controls.Add(MakeButton("删除", DeleteMember, ManagerButtonStyle.Danger));
            actionBar.Controls.Add(actions);
            actionBar.Controls.Add(actionHint);
            header.Controls.Add(actionBar);
            header.Controls.Add(brand);
            Controls.Add(header);

            StatusStrip strip = new StatusStrip { BackColor = Color.FromArgb(235, 239, 230), ForeColor = DeepGreen, SizingGrip = false, Padding = new Padding(14, 0, 14, 0) };
            ToolStripStatusLabel status = new ToolStripStatusLabel { Spring = true, TextAlign = ContentAlignment.MiddleLeft, Font = new Font("Microsoft YaHei UI", 9F) };
            statusLabel.AutoSize = false;
            strip.Items.Add(status);
            statusLabel.TextChanged += delegate { status.Text = statusLabel.Text; };
            Controls.Add(strip);

            mainSplit.Dock = DockStyle.Fill;
            mainSplit.BackColor = WindowPaper;
            mainSplit.Padding = new Padding(20, 18, 20, 18);
            mainSplit.SplitterWidth = 14;
            Controls.Add(mainSplit);
            mainSplit.BringToFront();

            BorderPanel left = new BorderPanel { Dock = DockStyle.Fill, BackColor = CardPaper, BorderColor = BorderGreen, AccentColor = MidGreen, Padding = new Padding(18, 18, 18, 16) };
            Label searchLabel = new Label { Text = "族人列表", Dock = DockStyle.Top, Height = 34, Font = new Font("Microsoft YaHei UI", 14F, FontStyle.Bold), ForeColor = DeepGreen, TextAlign = ContentAlignment.MiddleLeft };
            Label searchHint = new Label { Text = "按姓名、编号、地区或排行筛选", Dock = DockStyle.Top, Height = 27, ForeColor = TextMuted, Font = new Font("Microsoft YaHei UI", 9F), TextAlign = ContentAlignment.MiddleLeft };
            searchBox.Dock = DockStyle.Top;
            searchBox.Height = 35;
            searchBox.Text = "";
            searchBox.Margin = new Padding(0, 3, 0, 8);
            StyleInput(searchBox);
            searchBox.TextChanged += delegate { RefreshGrid(); };
            summaryLabel.Dock = DockStyle.Top;
            summaryLabel.Height = 36;
            summaryLabel.Padding = new Padding(1, 9, 0, 0);
            summaryLabel.ForeColor = Color.FromArgb(86, 105, 96);
            ConfigureGrid();
            left.Controls.Add(grid);
            left.Controls.Add(summaryLabel);
            left.Controls.Add(searchBox);
            left.Controls.Add(searchHint);
            left.Controls.Add(searchLabel);
            mainSplit.Panel1.Controls.Add(left);

            BorderPanel right = new BorderPanel { Dock = DockStyle.Fill, BackColor = CardPaper, BorderColor = BorderGreen, AccentColor = Color.FromArgb(105, 133, 91), Padding = new Padding(22, 18, 22, 18) };
            Label editorTitle = new Label { Text = "族人资料", Dock = DockStyle.Top, Height = 35, Font = new Font("Microsoft YaHei UI", 15F, FontStyle.Bold), ForeColor = DeepGreen, TextAlign = ContentAlignment.MiddleLeft };
            Label editorHint = new Label { Text = "基本信息、亲属关系与人物记述", Dock = DockStyle.Top, Height = 31, ForeColor = TextMuted, Font = new Font("Microsoft YaHei UI", 9F), TextAlign = ContentAlignment.MiddleLeft };
            TableLayoutPanel form = BuildForm();
            right.Controls.Add(form);
            right.Controls.Add(editorHint);
            right.Controls.Add(editorTitle);
            mainSplit.Panel2.Controls.Add(right);
        }

        private enum ManagerButtonStyle
        {
            Primary,
            Secondary,
            Danger
        }

        private Button MakeButton(string text, EventHandler click, ManagerButtonStyle style)
        {
            Button button = new Button { Text = text, AutoSize = true, Height = 39, MinimumSize = new Size(96, 39), Padding = new Padding(13, 0, 13, 0), Margin = new Padding(6, 1, 0, 1), FlatStyle = FlatStyle.Flat, Cursor = Cursors.Hand, Font = new Font("Microsoft YaHei UI", 9.5F, FontStyle.Bold), TextAlign = ContentAlignment.MiddleCenter, UseVisualStyleBackColor = false };
            button.FlatAppearance.BorderSize = 1;
            if (style == ManagerButtonStyle.Primary)
            {
                button.BackColor = MidGreen;
                button.ForeColor = Color.White;
                button.FlatAppearance.BorderColor = Color.FromArgb(88, 128, 108);
                button.FlatAppearance.MouseOverBackColor = Color.FromArgb(60, 112, 91);
                button.FlatAppearance.MouseDownBackColor = Color.FromArgb(35, 75, 61);
            }
            else if (style == ManagerButtonStyle.Danger)
            {
                button.BackColor = Color.FromArgb(250, 241, 238);
                button.ForeColor = Color.FromArgb(148, 51, 38);
                button.FlatAppearance.BorderColor = Color.FromArgb(209, 157, 148);
                button.FlatAppearance.MouseOverBackColor = Color.FromArgb(244, 226, 222);
                button.FlatAppearance.MouseDownBackColor = Color.FromArgb(235, 209, 204);
            }
            else
            {
                button.BackColor = Color.FromArgb(242, 245, 238);
                button.ForeColor = Color.FromArgb(37, 75, 60);
                button.FlatAppearance.BorderColor = Color.FromArgb(159, 178, 162);
                button.FlatAppearance.MouseOverBackColor = Color.FromArgb(230, 238, 226);
                button.FlatAppearance.MouseDownBackColor = Color.FromArgb(215, 226, 211);
            }
            button.Click += click;
            return button;
        }

        private void ConfigureGrid()
        {
            grid.Dock = DockStyle.Fill;
            grid.BackgroundColor = Color.FromArgb(250, 249, 244);
            grid.BorderStyle = BorderStyle.None;
            grid.ReadOnly = true;
            grid.AllowUserToAddRows = false;
            grid.AllowUserToDeleteRows = false;
            grid.AllowUserToResizeRows = false;
            grid.MultiSelect = false;
            grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            grid.RowHeadersVisible = false;
            grid.AutoGenerateColumns = false;
            grid.EnableHeadersVisualStyles = false;
            grid.GridColor = Color.FromArgb(226, 229, 219);
            grid.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            grid.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            grid.ColumnHeadersHeight = 42;
            grid.ColumnHeadersDefaultCellStyle.BackColor = SoftGreen;
            grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.FromArgb(36, 66, 53);
            grid.ColumnHeadersDefaultCellStyle.Font = new Font(Font, FontStyle.Bold);
            grid.ColumnHeadersDefaultCellStyle.Padding = new Padding(6, 0, 6, 0);
            grid.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            grid.DefaultCellStyle.BackColor = Color.White;
            grid.DefaultCellStyle.ForeColor = Color.FromArgb(35, 47, 42);
            grid.DefaultCellStyle.Padding = new Padding(6, 0, 6, 0);
            grid.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            grid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(207, 221, 210);
            grid.DefaultCellStyle.SelectionForeColor = DeepGreen;
            grid.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(249, 248, 244);
            grid.RowTemplate.Height = 40;
            grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Id", HeaderText = "编号", DataPropertyName = "Id", Width = 72 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "MemberName", HeaderText = "姓名", DataPropertyName = "Name", Width = 96 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Generation", HeaderText = "世", DataPropertyName = "Generation", Width = 48 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Branch", HeaderText = "排行", DataPropertyName = "Branch", Width = 92 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Region", HeaderText = "籍居", DataPropertyName = "Region", AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill });
            grid.SelectionChanged += GridSelectionChanged;
        }

        private TableLayoutPanel BuildForm()
        {
            TableLayoutPanel form = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 4, RowCount = 9, Padding = new Padding(0, 5, 0, 0), BackColor = Color.Transparent };
            form.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 82));
            form.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            form.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 82));
            form.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            for (int i = 0; i < 7; i++) form.RowStyles.Add(new RowStyle(SizeType.Absolute, 52));
            form.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
            form.RowStyles.Add(new RowStyle(SizeType.Percent, 50));

            genderBox.DropDownStyle = ComboBoxStyle.DropDownList;
            genderBox.Items.AddRange(new object[] { "男", "女" });
            generationBox.Minimum = 1; generationBox.Maximum = 99;
            birthYearBox.Minimum = 1000; birthYearBox.Maximum = DateTime.Now.Year + 1; birthYearBox.Value = DateTime.Now.Year;
            fatherBox.DropDownStyle = ComboBoxStyle.DropDown;
            motherBox.DropDownStyle = ComboBoxStyle.DropDown;
            bioBox.Multiline = true; bioBox.ScrollBars = ScrollBars.Vertical;
            storyBox.Multiline = true; storyBox.ScrollBars = ScrollBars.Vertical;

            AddField(form, 0, 0, "编号", idBox); AddField(form, 0, 2, "姓名", nameBox);
            AddField(form, 1, 0, "性别", genderBox); AddField(form, 1, 2, "第几世", generationBox);
            AddField(form, 2, 0, "字辈", generationNameBox); AddField(form, 2, 2, "排行", branchBox);
            AddField(form, 3, 0, "出生年", birthYearBox); AddField(form, 3, 2, "卒年", deathYearBox);
            AddField(form, 4, 0, "父亲编号", fatherBox); AddField(form, 4, 2, "母亲编号", motherBox);
            AddField(form, 5, 0, "配偶编号", spouseBox); AddField(form, 5, 2, "籍居", regionBox);
            AddField(form, 6, 0, "身份", roleBox); AddField(form, 6, 2, "字/号", courtesyNameBox);
            AddWideField(form, 7, "人物小传", bioBox);
            AddWideField(form, 8, "家族故事", storyBox);
            return form;
        }

        private void StyleInput(Control control)
        {
            control.BackColor = Color.White;
            control.ForeColor = Color.FromArgb(35, 47, 42);
            control.Font = new Font("Microsoft YaHei UI", 10F, FontStyle.Regular);
            TextBox box = control as TextBox;
            if (box != null)
            {
                box.BorderStyle = BorderStyle.FixedSingle;
                return;
            }

            ComboBox combo = control as ComboBox;
            if (combo != null)
            {
                combo.FlatStyle = FlatStyle.Flat;
                return;
            }

            NumericUpDown number = control as NumericUpDown;
            if (number != null)
            {
                number.BorderStyle = BorderStyle.FixedSingle;
                number.TextAlign = HorizontalAlignment.Left;
            }
        }

        private void AddField(TableLayoutPanel panel, int row, int column, string label, Control control)
        {
            Label text = new Label { Text = label, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleRight, Padding = new Padding(0, 0, 10, 0), ForeColor = TextMuted, Font = new Font("Microsoft YaHei UI", 9.5F, FontStyle.Bold), Margin = new Padding(0) };
            control.Dock = DockStyle.Fill;
            control.Margin = new Padding(0, 9, column == 0 ? 14 : 0, 9);
            StyleInput(control);
            panel.Controls.Add(text, column, row);
            panel.Controls.Add(control, column + 1, row);
        }

        private void AddWideField(TableLayoutPanel panel, int row, string label, Control control)
        {
            Label text = new Label { Text = label, Dock = DockStyle.Fill, TextAlign = ContentAlignment.TopRight, Padding = new Padding(0, 12, 10, 0), ForeColor = TextMuted, Font = new Font("Microsoft YaHei UI", 9.5F, FontStyle.Bold), Margin = new Padding(0) };
            control.Dock = DockStyle.Fill;
            control.Margin = new Padding(0, 8, 0, 8);
            StyleInput(control);
            panel.Controls.Add(text, 0, row);
            panel.Controls.Add(control, 1, row);
            panel.SetColumnSpan(control, 3);
        }

        private void LoadData(bool initial)
        {
            try
            {
                store.Load();
                PopulateRelationChoices();
                RefreshGrid();
                if (store.Members.Count > 0) SelectMember(store.Members[0].Id);
                statusLabel.Text = "已加载 " + store.Members.Count + " 位族人 · " + store.FilePath;
            }
            catch (Exception ex)
            {
                statusLabel.Text = "加载失败";
                MessageBox.Show(this, ex.Message, "无法读取数据", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (initial) DisableEditor();
            }
        }

        private void DisableEditor()
        {
            foreach (Control control in Controls) control.Enabled = false;
        }

        private void RefreshGrid()
        {
            string keyword = (searchBox.Text ?? "").Trim();
            IEnumerable<FamilyMember> query = store.Members;
            if (keyword.Length > 0)
            {
                query = query.Where(delegate(FamilyMember member)
                {
                    string haystack = String.Join(" ", new[] { member.Id, member.Name, member.Branch, member.Region, member.Role, member.GenerationName });
                    return haystack.IndexOf(keyword, StringComparison.OrdinalIgnoreCase) >= 0;
                });
            }
            List<FamilyMember> rows = query.OrderBy(delegate(FamilyMember item) { return item.Generation; }).ThenBy(delegate(FamilyMember item) { return item.Id; }).ToList();
            grid.DataSource = rows.Select(delegate(FamilyMember member) { return new { member.Id, member.Name, member.Generation, member.Branch, member.Region }; }).ToList();
            summaryLabel.Text = "显示 " + rows.Count + " / 共 " + store.Members.Count + " 位族人";
        }

        private void GridSelectionChanged(object sender, EventArgs e)
        {
            if (grid.SelectedRows.Count == 0 || grid.SelectedRows[0].Cells["Id"].Value == null) return;
            SelectMember(Convert.ToString(grid.SelectedRows[0].Cells["Id"].Value));
        }

        private void SelectMember(string id)
        {
            FamilyMember member = store.Members.FirstOrDefault(delegate(FamilyMember item) { return item.Id == id; });
            if (member == null) return;
            selectedId = member.Id;
            isNew = false;
            idBox.ReadOnly = true;
            FillForm(member);
            foreach (DataGridViewRow row in grid.Rows)
            {
                if (Convert.ToString(row.Cells["Id"].Value) == id) { row.Selected = true; break; }
            }
        }

        private void FillForm(FamilyMember member)
        {
            idBox.Text = member.Id;
            nameBox.Text = member.Name;
            genderBox.SelectedItem = member.Gender;
            generationBox.Value = Math.Max(generationBox.Minimum, Math.Min(generationBox.Maximum, member.Generation));
            generationNameBox.Text = member.GenerationName;
            branchBox.Text = member.Branch;
            birthYearBox.Value = Math.Max(birthYearBox.Minimum, Math.Min(birthYearBox.Maximum, member.BirthYear));
            deathYearBox.Text = member.DeathYear.HasValue ? member.DeathYear.Value.ToString() : "";
            fatherBox.Text = member.FatherId;
            motherBox.Text = member.MotherId;
            spouseBox.Text = String.Join(", ", member.SpouseIds.ToArray());
            regionBox.Text = member.Region;
            roleBox.Text = member.Role;
            courtesyNameBox.Text = member.CourtesyName;
            bioBox.Text = member.Bio;
            storyBox.Text = member.Story;
        }

        private FamilyMember ReadForm()
        {
            int death;
            int? deathYear = null;
            if (!String.IsNullOrWhiteSpace(deathYearBox.Text))
            {
                if (!Int32.TryParse(deathYearBox.Text.Trim(), out death)) throw new InvalidDataException("卒年必须是数字，或留空表示在世。");
                deathYear = death;
            }
            return new FamilyMember
            {
                Id = idBox.Text.Trim(),
                Name = nameBox.Text.Trim(),
                Gender = Convert.ToString(genderBox.SelectedItem),
                Generation = Convert.ToInt32(generationBox.Value),
                GenerationName = generationNameBox.Text.Trim(),
                Branch = branchBox.Text.Trim(),
                BirthYear = Convert.ToInt32(birthYearBox.Value),
                DeathYear = deathYear,
                FatherId = fatherBox.Text.Trim(),
                MotherId = motherBox.Text.Trim(),
                SpouseIds = spouseBox.Text.Split(new[] { ',', '，', ';', '；' }, StringSplitOptions.RemoveEmptyEntries).Select(delegate(string value) { return value.Trim(); }).Where(delegate(string value) { return value.Length > 0; }).Distinct().ToList(),
                Region = regionBox.Text.Trim(),
                Role = roleBox.Text.Trim(),
                CourtesyName = courtesyNameBox.Text.Trim(),
                Bio = bioBox.Text.Trim(),
                Story = storyBox.Text.Trim()
            };
        }

        private void NewMember(object sender, EventArgs e)
        {
            isNew = true;
            selectedId = "";
            idBox.ReadOnly = false;
            FamilyMember member = new FamilyMember { Id = store.GetNextId(), BirthYear = DateTime.Now.Year, Bio = "资料待补充。", Story = "家族故事待补充。" };
            FillForm(member);
            nameBox.Focus();
            statusLabel.Text = "正在新增族人，填写后点击“保存修改”";
        }

        private void SaveMember(object sender, EventArgs e)
        {
            try
            {
                FamilyMember edited = ReadForm();
                if (isNew)
                {
                    if (store.Members.Any(delegate(FamilyMember item) { return item.Id.Equals(edited.Id, StringComparison.OrdinalIgnoreCase); }))
                        throw new InvalidDataException("成员编号已经存在：" + edited.Id);
                    store.Members.Add(edited);
                }
                else
                {
                    FamilyMember existing = store.Members.FirstOrDefault(delegate(FamilyMember item) { return item.Id == selectedId; });
                    if (existing == null) throw new InvalidDataException("原成员记录已不存在，请重新加载。");
                    int index = store.Members.IndexOf(existing);
                    store.Members[index] = edited;
                }
                store.SyncSpouses(edited);
                string backup = store.Save();
                store.Load();
                PopulateRelationChoices();
                RefreshGrid();
                SelectMember(edited.Id);
                isNew = false;
                statusLabel.Text = "保存成功 · 已自动备份至 " + backup + " · 请在微信开发者工具中重新编译";
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "无法保存", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void DeleteMember(object sender, EventArgs e)
        {
            if (isNew) { if (store.Members.Count > 0) SelectMember(store.Members[0].Id); return; }
            FamilyMember member = store.Members.FirstOrDefault(delegate(FamilyMember item) { return item.Id == selectedId; });
            if (member == null) return;
            DialogResult answer = MessageBox.Show(this, "确定删除“" + member.Name + "”（" + member.Id + "）吗？\n\n其配偶、父母引用会一并清理，保存前会自动备份。", "确认删除族人", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            if (answer != DialogResult.Yes) return;
            try
            {
                store.DeleteAndClean(member.Id);
                string backup = store.Save();
                store.Load();
                PopulateRelationChoices();
                RefreshGrid();
                if (store.Members.Count > 0) SelectMember(store.Members[0].Id);
                statusLabel.Text = "已删除 " + member.Name + " · 备份：" + backup;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "删除失败", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void PopulateRelationChoices()
        {
            string father = fatherBox.Text;
            string mother = motherBox.Text;
            object[] choices = store.Members.Select(delegate(FamilyMember member) { return (object)member.Id; }).ToArray();
            fatherBox.Items.Clear(); motherBox.Items.Clear();
            fatherBox.Items.Add(""); motherBox.Items.Add("");
            fatherBox.Items.AddRange(choices); motherBox.Items.AddRange(choices);
            fatherBox.Text = father; motherBox.Text = mother;
        }

        private void OpenBackups(object sender, EventArgs e)
        {
            try
            {
                string dir = store.GetBackupDirectory();
                Directory.CreateDirectory(dir);
                Process.Start("explorer.exe", dir);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "无法打开备份目录", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExportCloudData(object sender, EventArgs e)
        {
            try
            {
                string path = store.ExportCloudJson();
                statusLabel.Text = "已导出云数据库导入文件 · " + path;
                MessageBox.Show(this, "已导出云数据库导入文件：\n\n" + path + "\n\n在微信开发者工具的云开发数据库中，导入到 family_members 集合即可。", "导出成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "导出云数据失败", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SyncCloudData(object sender, EventArgs e)
        {
            try
            {
                statusLabel.Text = "正在同步云数据库...";
                string exportPath = store.ExportCloudJson();
                CloudSyncResult result = store.SyncCloudDatabase();
                statusLabel.Text = "云端同步成功 · " + result.MemberCount + " 位族人 · " + exportPath;
                MessageBox.Show(this, "云端同步成功。\n\n已同步 " + result.MemberCount + " 位族人到 family_members 集合。", "同步成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                statusLabel.Text = "云端同步失败";
                MessageBox.Show(this, ex.Message, "云端同步失败", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void PullCloudData(object sender, EventArgs e)
        {
            DialogResult answer = MessageBox.Show(this, "将从云数据库 family_members 拉取数据，并覆盖当前本地 family.ts。\n\n覆盖前会自动备份当前本地文件。确定继续吗？", "从云端更新", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            if (answer != DialogResult.Yes) return;
            try
            {
                statusLabel.Text = "正在从云端读取族人数据...";
                CloudSyncResult result = store.PullCloudDatabase();
                string backup = store.Save();
                PopulateRelationChoices();
                RefreshGrid();
                if (store.Members.Count > 0) SelectMember(store.Members[0].Id);
                statusLabel.Text = "已从云端更新 " + result.MemberCount + " 位族人 · 本地已备份：" + backup;
                MessageBox.Show(this, "已从云端更新 " + result.MemberCount + " 位族人。\n\n本地文件已自动备份：\n" + backup, "更新成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                statusLabel.Text = "从云端更新失败";
                MessageBox.Show(this, ex.Message, "从云端更新失败", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }

    internal static class SelfTest
    {
        public static int Run(string sourcePath)
        {
            string tempRoot = Path.Combine(Path.GetTempPath(), "fuqingbian-manager-test-" + Guid.NewGuid().ToString("N"));
            try
            {
                if (String.IsNullOrWhiteSpace(sourcePath) || !File.Exists(sourcePath)) return 10;
                string dataDir = Path.Combine(tempRoot, "miniprogram", "data");
                Directory.CreateDirectory(dataDir);
                string tempFile = Path.Combine(dataDir, "family.ts");
                File.Copy(sourcePath, tempFile);
                string originalSource = File.ReadAllText(sourcePath, Encoding.UTF8);

                FamilyDataStore store = new FamilyDataStore(tempFile);
                store.Load();
                int originalCount = store.Members.Count;
                if (originalCount == 0) return 11;

                FamilyMember sample = store.Members[0];
                string oldBio = sample.Bio;
                sample.Bio = oldBio + "（管理器测试）";
                store.Save();
                store.Load();
                if (store.Members[0].Bio != oldBio + "（管理器测试）") return 12;

                FamilyMember added = new FamilyMember
                {
                    Id = "ftest999",
                    Name = "测试成员",
                    Gender = "男",
                    Generation = 9,
                    GenerationName = "测",
                    Branch = "测试支",
                    BirthYear = 2000,
                    SpouseIds = new List<string>(),
                    Region = "测试地区",
                    Bio = "测试小传",
                    Story = "测试故事"
                };
                store.Members.Add(added);
                store.Save();
                store.Load();
                if (store.Members.Count != originalCount + 1 || !store.Members.Any(delegate(FamilyMember item) { return item.Id == added.Id; })) return 13;
                store.DeleteAndClean(added.Id);
                store.Save();
                store.Load();
                if (store.Members.Count != originalCount) return 14;
                if (File.ReadAllText(sourcePath, Encoding.UTF8) != originalSource) return 15;
                return 0;
            }
            catch
            {
                return 99;
            }
            finally
            {
                try { if (Directory.Exists(tempRoot)) Directory.Delete(tempRoot, true); } catch { }
            }
        }
    }
}


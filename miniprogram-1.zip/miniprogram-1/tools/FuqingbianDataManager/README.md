# 傅庭知源数据管理器

Windows 本地族人数据管理软件，直接维护 `miniprogram/data/family.ts`。

功能：

- 搜索、查看族人资料
- 新增、编辑、删除族人
- 自动维护双向配偶关系
- 删除时清理相关亲属引用
- 保存前校验编号、年份和亲属引用
- 每次写入前自动备份到 `backups/family-data`
- 可导出微信云数据库导入文件到 `exports/family_members_cloud.json`
- 可通过 `syncfamilymembers` 云函数一键同步到云数据库
- 可从云数据库拉取 `family_members` 并覆盖更新本地 `family.ts`

云开发流程：

1. 在管理器中修改族人数据，点击“保存修改”
2. 已配置一键同步时，点击“一键同步云端”
3. 未配置一键同步时，点击“导出云数据”，再在微信开发者工具的云开发数据库中，将 `exports/family_members_cloud.json` 导入到 `family_members` 集合

如果云端数据比本地更新，例如小程序端审核通过后写入了云数据库，可以点击“从云端更新”。该操作会用云端 `family_members` 覆盖本地 `family.ts`，覆盖前会自动备份当前本地文件。

小程序已配置云开发环境 `cloud1-d4g4s48pf5206f259`，会优先读取云数据库；云端读取失败时使用本地 `family.ts` 兜底。

一键同步配置：

1. 在微信开发者工具中上传并部署云函数 `syncfamilymembers`
2. 给云函数配置环境变量 `SYNC_TOKEN`
3. 开启云函数 HTTP 访问，复制访问地址
4. 将访问地址和同一串 `SYNC_TOKEN` 填入 `tools/FuqingbianDataManager/cloud-sync.json`

首次点击“一键同步云端”时，如果 `cloud-sync.json` 不存在，管理器会自动生成空模板。


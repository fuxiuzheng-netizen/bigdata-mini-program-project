const tabs = [
  { pagePath: '/pages/index/index', route: 'pages/index/index', text: '首页', mark: '首' },
  { pagePath: '/pages/tree/tree', route: 'pages/tree/tree', text: '族谱', mark: '谱' },
  { pagePath: '/pages/members/members', route: 'pages/members/members', text: '族人', mark: '族' },
  { pagePath: '/pages/history/history', route: 'pages/history/history', text: '族志', mark: '志' },
  { pagePath: '/pages/profile/profile', route: 'pages/profile/profile', text: '我的', mark: '我' },
]

Component({
  data: {
    selected: 0,
    tabs,
  },

  lifetimes: {
    attached() {
      this.syncSelected()
    },
  },

  pageLifetimes: {
    show() {
      this.syncSelected()
    },
  },

  methods: {
    syncSelected() {
      const pages = getCurrentPages()
      const current = pages[pages.length - 1]
      const currentRoute = current && current.route ? current.route : ''
      const selected = tabs.findIndex((item) => item.route === currentRoute)
      if (selected >= 0 && selected !== this.data.selected) {
        this.setData({ selected })
      }
    },

    switchTab(event: WechatMiniprogram.TouchEvent) {
      const index = Number(event.currentTarget.dataset.index)
      const tab = tabs[index]
      if (!tab || index === this.data.selected) return
      this.setData({ selected: index })
      wx.switchTab({ url: tab.pagePath })
    },
  },
})

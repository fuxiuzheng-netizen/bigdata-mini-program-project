import { FamilyMember } from '../data/family'

const orderNames = ['长', '次', '三', '四', '五', '六']

function sameParents(left: FamilyMember, right: FamilyMember): boolean {
  if (left.id === right.id) return false
  const sameFather = Boolean(left.fatherId && right.fatherId && left.fatherId === right.fatherId)
  const sameMother = Boolean(left.motherId && right.motherId && left.motherId === right.motherId)
  return sameFather || sameMother
}

function findMember(id: string | undefined, members: FamilyMember[]): FamilyMember | undefined {
  return id ? members.find((member) => member.id === id) : undefined
}

function isParentOf(parent: FamilyMember, child: FamilyMember): boolean {
  return child.fatherId === parent.id || child.motherId === parent.id
}

function siblingTitle(viewer: FamilyMember, target: FamilyMember, prefix = ''): string {
  const older = target.birthYear <= viewer.birthYear
  if (target.gender === '男') return `${prefix}${older ? '哥' : '弟'}`
  return `${prefix}${older ? '姐' : '妹'}`
}

function getBirthOrder(member: FamilyMember, members: FamilyMember[]): string {
  if (!member.fatherId && !member.motherId) return ''
  const sameGenderSiblings = members
    .filter((item) => item.gender === member.gender && (item.id === member.id || sameParents(item, member)))
    .sort((left, right) => left.birthYear - right.birthYear)
  const index = sameGenderSiblings.findIndex((item) => item.id === member.id)
  if (index < 0) return ''
  const prefix = orderNames[index] || `${index + 1}`
  return `${prefix}${member.gender === '男' ? '子' : '女'}`
}

export function getIdentityLabel(member: FamilyMember, members: FamilyMember[]): string {
  if (member.role === '始祖' || member.role === '始祖配偶') return member.role
  const order = getBirthOrder(member, members)
  return order || member.branch || '排行待考'
}

export function getRelationshipLabel(viewerId: string, targetId: string, members: FamilyMember[]): string {
  if (!viewerId) return ''
  if (viewerId === targetId) return '本人'
  const viewer = members.find((member) => member.id === viewerId)
  const target = members.find((member) => member.id === targetId)
  if (!viewer || !target) return ''

  if (viewer.fatherId === target.id) return '父亲'
  if (viewer.motherId === target.id) return '母亲'
  if (target.fatherId === viewer.id || target.motherId === viewer.id) return target.gender === '男' ? '儿子' : '女儿'
  if (viewer.spouseIds.includes(target.id)) return target.gender === '男' ? '丈夫' : '妻子'

  if (sameParents(viewer, target)) {
    return siblingTitle(viewer, target)
  }

  const viewerFather = findMember(viewer.fatherId, members)
  const viewerMother = findMember(viewer.motherId, members)
  if (viewerFather) {
    if (viewerFather.fatherId === target.id) return '祖父'
    if (viewerFather.motherId === target.id) return '祖母'
  }
  if (viewerMother) {
    if (viewerMother.fatherId === target.id) return '外祖父'
    if (viewerMother.motherId === target.id) return '外祖母'
  }

  const targetFather = findMember(target.fatherId, members)
  const targetMother = findMember(target.motherId, members)
  const targetParents = [targetFather, targetMother].filter((item): item is FamilyMember => Boolean(item))
  const childParent = targetParents.find((parent) => isParentOf(viewer, parent))
  if (childParent) {
    const outside = childParent.gender === '女' ? '外' : ''
    return `${outside}孙${target.gender === '男' ? '子' : '女'}`
  }

  if (viewerFather && sameParents(viewerFather, target)) {
    if (target.gender === '女') return '姑母'
    return target.birthYear <= viewerFather.birthYear ? '伯父' : '叔父'
  }

  if (viewerMother && sameParents(viewerMother, target)) return target.gender === '男' ? '舅父' : '姨母'

  if (viewerFather) {
    const paternalInLaw = members.find((member) => sameParents(viewerFather, member) && member.spouseIds.includes(target.id))
    if (paternalInLaw) {
      if (paternalInLaw.gender === '女') return '姑父'
      return paternalInLaw.birthYear <= viewerFather.birthYear ? '伯母' : '婶母'
    }
  }

  if (viewerMother) {
    const maternalInLaw = members.find((member) => sameParents(viewerMother, member) && member.spouseIds.includes(target.id))
    if (maternalInLaw) return maternalInLaw.gender === '男' ? '舅母' : '姨父'
  }

  const targetParentSibling = targetParents.find((parent) => sameParents(viewer, parent))
  if (targetParentSibling) {
    if (targetParentSibling.gender === '男') return target.gender === '男' ? '侄子' : '侄女'
    return target.gender === '男' ? '外甥' : '外甥女'
  }

  const viewerChild = members.find((member) => isParentOf(viewer, member) && member.spouseIds.includes(target.id))
  if (viewerChild) return viewerChild.gender === '男' ? '儿媳' : '女婿'

  const viewerSpouse = viewer.spouseIds.map((id) => findMember(id, members)).find((item): item is FamilyMember => Boolean(item))
  if (viewerSpouse) {
    if (viewerSpouse.fatherId === target.id) return viewer.gender === '男' ? '岳父' : '公公'
    if (viewerSpouse.motherId === target.id) return viewer.gender === '男' ? '岳母' : '婆婆'
  }

  const viewerParents = [viewerFather, viewerMother].filter((item): item is FamilyMember => Boolean(item))
  const viewerParent = viewerParents.find((parent) => targetParents.some((targetParent) => sameParents(parent, targetParent)))
  if (viewerParent) {
    const targetParent = targetParents.find((parent) => sameParents(viewerParent, parent))
    const isPaternalLine = viewerParent.id === viewerFather?.id && targetParent?.gender === '男'
    return siblingTitle(viewer, target, isPaternalLine ? '堂' : '表')
  }

  return '同族宗亲'
}

import { initFamilyCloud } from './data/family'
import { refreshAccountRole } from './services/admin'

App<IAppOption>({
  globalData: {},
  onLaunch() {
    initFamilyCloud()
    refreshAccountRole()
    const openedAt = wx.getStorageSync<number>('fuqingpu_opened_at')
    if (!openedAt) {
      wx.setStorageSync('fuqingpu_opened_at', Date.now())
    }
  },
})

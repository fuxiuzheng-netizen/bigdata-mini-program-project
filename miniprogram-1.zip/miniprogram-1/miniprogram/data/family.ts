export type Gender = '男' | '女'
export type LifeStatus = '在世' | '已故'

export interface FamilyMember {
  id: string
  name: string
  gender: Gender
  generation: number
  generationName: string
  branch: string
  birthYear: number
  deathYear?: number
  fatherId?: string
  motherId?: string
  spouseIds: string[]
  region: string
  role?: string
  courtesyName?: string
  bio: string
  story: string
}

export type EditableMemberField = 'name' | 'region' | 'bio' | 'story'
export type IdentityEditableMemberField = 'name' | 'gender' | 'birthYear' | 'region' | 'generation' | 'generationName' | 'branch'
export type MemberOverride = Partial<Pick<FamilyMember, EditableMemberField | IdentityEditableMemberField>>

const MEMBER_OVERRIDES_KEY = 'fuqingpu_member_overrides'
const CUSTOM_MEMBERS_KEY = 'fuqingpu_custom_members'
const CLOUD_ENV_ID = 'cloud1-d4g4s48pf5206f259'
const FAMILY_MEMBERS_COLLECTION = 'family_members'

let activeFamilyMembers: FamilyMember[] | null = null
let cloudInitialized = false
let cloudLoadPromise: Promise<FamilyMember[]> | null = null

export const generationPoem = ['承', '德', '泽', '绵', '世', '远']

export const familyMembers: FamilyMember[] = [
  { id: 'f001', name: '傅承岳', gender: '男', generation: 1, generationName: '承', branch: '始祖', birthYear: 1912, deathYear: 1988, spouseIds: ['f002'], region: '江西临川', role: '始祖', courtesyName: '景山', bio: '早年从事乡塾教育，为人端方，重视家学与乡邻互助。', story: '留下“敬宗睦族，诗礼传家”的家训手书，是本谱示例家系的共同先祖。' },
  { id: 'f002', name: '周静仪', gender: '女', generation: 1, generationName: '承', branch: '始祖配偶', birthYear: 1916, deathYear: 1997, spouseIds: ['f001'], region: '江西临川', role: '始祖配偶', bio: '勤俭持家，熟习女红，关爱晚辈。', story: '每逢岁末召集子孙共叙家事，许多家族旧闻由她口述留存。' },

  { id: 'f101', name: '傅德昌', gender: '男', generation: 2, generationName: '德', branch: '长子', birthYear: 1936, deathYear: 2010, fatherId: 'f001', motherId: 'f002', spouseIds: ['f102'], region: '江西南昌', role: '长子', bio: '从事水利建设四十余年，做事严谨。', story: '主持整理过一次纸质家谱，将散落各家的旧照片编号保存。' },
  { id: 'f102', name: '林素琴', gender: '女', generation: 2, generationName: '德', branch: '长媳', birthYear: 1940, spouseIds: ['f101'], region: '江西南昌', bio: '退休教师，喜爱书法与地方戏曲。', story: '长期为家中晚辈讲述傅氏源流，并保存了多封旧家书。' },
  { id: 'f103', name: '傅德安', gender: '男', generation: 2, generationName: '德', branch: '次子', birthYear: 1941, fatherId: 'f001', motherId: 'f002', spouseIds: ['f104'], region: '福建建瓯', role: '次子', bio: '青年时期迁居福建，从事林业工作。', story: '曾协助整理族人联络册，使两地亲族重新取得联系。' },
  { id: 'f104', name: '陈月华', gender: '女', generation: 2, generationName: '德', branch: '次媳', birthYear: 1944, spouseIds: ['f103'], region: '福建建瓯', bio: '擅长茶艺和传统糕点制作。', story: '家族聚会时常以家乡茶点招待远道而来的亲人。' },
  { id: 'f105', name: '傅德宁', gender: '女', generation: 2, generationName: '德', branch: '长女', birthYear: 1947, fatherId: 'f001', motherId: 'f002', spouseIds: [], region: '浙江杭州', bio: '从事图书管理工作，喜欢地方文献。', story: '协助查找傅氏历史资料，为家族文化整理提供了许多线索。' },

  { id: 'f201', name: '傅泽民', gender: '男', generation: 3, generationName: '泽', branch: '长子', birthYear: 1962, fatherId: 'f101', motherId: 'f102', spouseIds: ['f202'], region: '江西南昌', role: '谱务召集人', bio: '建筑工程师，热心宗亲事务。', story: '发起数字族谱计划，希望用更清晰的方式留住家族记忆。' },
  { id: 'f202', name: '王雅文', gender: '女', generation: 3, generationName: '泽', branch: '长媳', birthYear: 1965, spouseIds: ['f201'], region: '江西南昌', bio: '医务工作者，温和细致。', story: '整理家族成员生卒与健康记录时，坚持尊重每一位成员的隐私。' },
  { id: 'f203', name: '傅泽川', gender: '男', generation: 3, generationName: '泽', branch: '次子', birthYear: 1967, fatherId: 'f101', motherId: 'f102', spouseIds: ['f204'], region: '广东深圳', bio: '机械设计师，后迁居深圳。', story: '每年清明返乡，并负责联络在粤族人。' },
  { id: 'f204', name: '赵清荷', gender: '女', generation: 3, generationName: '泽', branch: '次媳', birthYear: 1969, spouseIds: ['f203'], region: '广东深圳', bio: '园林设计师，钟爱竹与兰。', story: '为家族纪念册设计过墨竹纹样。' },
  { id: 'f205', name: '傅泽兰', gender: '女', generation: 3, generationName: '泽', branch: '长女', birthYear: 1970, fatherId: 'f101', motherId: 'f102', spouseIds: [], region: '浙江杭州', bio: '中学语文教师，关注传统文化教育。', story: '将家训整理成适合孩子阅读的小故事。' },
  { id: 'f206', name: '傅泽林', gender: '男', generation: 3, generationName: '泽', branch: '长子', birthYear: 1965, fatherId: 'f103', motherId: 'f104', spouseIds: ['f207'], region: '福建福州', role: '宗亲联络人', bio: '从事林业科研，常年关注乡土树种保护。', story: '提出用“竹节”表现世代、用“竹叶”表现族人的青谱设计构想。' },
  { id: 'f207', name: '许惠真', gender: '女', generation: 3, generationName: '泽', branch: '长媳', birthYear: 1968, spouseIds: ['f206'], region: '福建福州', bio: '社区工作者，乐于助人。', story: '负责收集在外族人的联系方式与公开资料。' },
  { id: 'f208', name: '傅泽海', gender: '男', generation: 3, generationName: '泽', branch: '次子', birthYear: 1972, fatherId: 'f103', motherId: 'f104', spouseIds: ['f209'], region: '福建厦门', bio: '摄影爱好者，从事交通行业。', story: '拍摄了多组家乡古厝和祠堂影像。' },
  { id: 'f209', name: '苏云舒', gender: '女', generation: 3, generationName: '泽', branch: '次媳', birthYear: 1974, spouseIds: ['f208'], region: '福建厦门', bio: '平面设计师，爱好古籍装帧。', story: '协助修复旧谱扫描件的版面。' },

  { id: 'f301', name: '傅绵远', gender: '男', generation: 4, generationName: '绵', branch: '长子', birthYear: 1987, fatherId: 'f201', motherId: 'f202', spouseIds: ['f302'], region: '上海', bio: '软件工程师，关注数字人文。', story: '承担青谱小程序的数据结构设计。' },
  { id: 'f302', name: '沈知秋', gender: '女', generation: 4, generationName: '绵', branch: '长媳', birthYear: 1989, spouseIds: ['f301'], region: '上海', bio: '博物馆教育工作者。', story: '建议以年轻人也愿意阅读的方式呈现家族历史。' },
  { id: 'f303', name: '傅绵清', gender: '女', generation: 4, generationName: '绵', branch: '长女', birthYear: 1990, fatherId: 'f201', motherId: 'f202', spouseIds: [], region: '江西南昌', bio: '儿科医生，喜爱古琴。', story: '为家族影像采访提供了录音整理。' },
  { id: 'f304', name: '傅绵竹', gender: '男', generation: 4, generationName: '绵', branch: '长子', birthYear: 1992, fatherId: 'f203', motherId: 'f204', spouseIds: [], region: '广东深圳', bio: '景观设计师，性格沉静。', story: '以南方竹林为灵感绘制族谱视觉草图。' },
  { id: 'f305', name: '傅绵书', gender: '女', generation: 4, generationName: '绵', branch: '长女', birthYear: 1995, fatherId: 'f203', motherId: 'f204', spouseIds: [], region: '广东广州', bio: '编辑，喜欢口述史与非虚构写作。', story: '正在整理长辈们的迁徙与求学故事。' },
  { id: 'f306', name: '傅绵松', gender: '男', generation: 4, generationName: '绵', branch: '长子', birthYear: 1988, fatherId: 'f206', motherId: 'f207', spouseIds: ['f307'], region: '福建福州', bio: '大学教师，研究地方文化。', story: '参与考证家族迁徙路线与旧地名。' },
  { id: 'f307', name: '郑若水', gender: '女', generation: 4, generationName: '绵', branch: '长媳', birthYear: 1990, spouseIds: ['f306'], region: '福建福州', bio: '图书编辑，爱好篆刻。', story: '为“傅氏家乘”设计了朱文小印。' },
  { id: 'f308', name: '傅绵山', gender: '男', generation: 4, generationName: '绵', branch: '次子', birthYear: 1993, fatherId: 'f206', motherId: 'f207', spouseIds: [], region: '北京', bio: '测绘工程师，长期在外工作。', story: '尝试将家族成员居住地整理成迁徙地图。' },
  { id: 'f309', name: '傅绵月', gender: '女', generation: 4, generationName: '绵', branch: '长女', birthYear: 1996, fatherId: 'f208', motherId: 'f209', spouseIds: [], region: '福建厦门', bio: '视觉设计师，关注东方美学。', story: '负责整理旧照片的年代和拍摄地点。' },
  { id: 'f310', name: '傅绵舟', gender: '男', generation: 4, generationName: '绵', branch: '长子', birthYear: 1998, fatherId: 'f208', motherId: 'f209', spouseIds: [], region: '福建厦门', bio: '在读研究生，爱好历史。', story: '利用假期采访家中长辈并录入资料。' },

  { id: 'f401', name: '傅世和', gender: '男', generation: 5, generationName: '世', branch: '长子', birthYear: 2014, fatherId: 'f301', motherId: 'f302', spouseIds: [], region: '上海', bio: '喜欢天文与围棋。', story: '在家族活动中画了一幅“竹林里的家”。' },
  { id: 'f402', name: '傅世宁', gender: '女', generation: 5, generationName: '世', branch: '长女', birthYear: 2017, fatherId: 'f301', motherId: 'f302', spouseIds: [], region: '上海', bio: '喜欢阅读和绘画。', story: '能认出族谱中大部分亲人的名字。' },
  { id: 'f403', name: '傅世谦', gender: '男', generation: 5, generationName: '世', branch: '长子', birthYear: 2015, fatherId: 'f306', motherId: 'f307', spouseIds: [], region: '福建福州', bio: '热爱自然观察。', story: '将院中的竹子按四季变化拍成照片。' },
  { id: 'f404', name: '傅世晴', gender: '女', generation: 5, generationName: '世', branch: '长女', birthYear: 2019, fatherId: 'f306', motherId: 'f307', spouseIds: [], region: '福建福州', bio: '活泼开朗，喜欢唱歌。', story: '家族聚会时最喜欢听太奶奶讲旧故事。' },
  { id: 'f405', name: '傅世安', gender: '男', generation: 5, generationName: '世', branch: '长子', birthYear: 2020, fatherId: 'f304', spouseIds: [], region: '广东深圳', bio: '示例成员，资料仅作演示。', story: '他的加入让数字族谱继续长出新的竹叶。' },
  { id: 'f406', name: '傅世嘉', gender: '女', generation: 5, generationName: '世', branch: '长女', birthYear: 2021, fatherId: 'f308', spouseIds: [], region: '北京', bio: '示例成员，资料仅作演示。', story: '名字寄托着家人对和美生活的祝愿。' },

  { id: 'f520', name: '傅秀正', gender: '男', generation: 50, generationName: '秀', branch: '排行待考', birthYear: 2005, spouseIds: [], region: '贵州六盘水', bio: '资料待补充。', story: '因前代资料暂缺，排行与上下世系待后续考证补录。' },
]

export const familyArticles = [
  { id: 'origin', category: '傅氏源流', title: '青谱序：一脉相承，枝叶同源', summary: '从姓氏源流到本支迁徙，以可考资料续写共同记忆。', readTime: '6 分钟', mark: '源' },
  { id: 'migration', category: '迁徙纪事', title: '从临川到闽粤：族人迁居小记', summary: '一条河、一封家书与几代人的远行，串起散居各地的亲族。', readTime: '8 分钟', mark: '迁' },
  { id: 'rules', category: '家训家风', title: '敬宗睦族，诗礼传家', summary: '家训不是墙上的旧句，而是每一代人待人处事的朴素准则。', readTime: '4 分钟', mark: '训' },
  { id: 'names', category: '字辈谱', title: '承德泽绵，世远流长', summary: '用字辈标识世次，也把长辈的期许藏进每一个名字。', readTime: '3 分钟', mark: '字' },
]

function normalizeCloudMember(value: Partial<FamilyMember>): FamilyMember | null {
  if (!value || !value.id || !value.name) return null
  return {
    id: String(value.id),
    name: String(value.name),
    gender: value.gender === '女' ? '女' : '男',
    generation: Number(value.generation || 1),
    generationName: String(value.generationName || ''),
    branch: String(value.branch || ''),
    birthYear: Number(value.birthYear || new Date().getFullYear()),
    deathYear: value.deathYear ? Number(value.deathYear) : undefined,
    fatherId: value.fatherId ? String(value.fatherId) : undefined,
    motherId: value.motherId ? String(value.motherId) : undefined,
    spouseIds: Array.isArray(value.spouseIds) ? value.spouseIds.map((id) => String(id)) : [],
    region: String(value.region || ''),
    role: value.role ? String(value.role) : undefined,
    courtesyName: value.courtesyName ? String(value.courtesyName) : undefined,
    bio: String(value.bio || ''),
    story: String(value.story || ''),
  }
}

function sortMembers(members: FamilyMember[]): FamilyMember[] {
  return members.slice().sort((left, right) => left.generation - right.generation || left.id.localeCompare(right.id))
}

export function initFamilyCloud(): boolean {
  if (cloudInitialized) return true
  if (!wx.cloud) return false
  wx.cloud.init({
    env: CLOUD_ENV_ID,
    traceUser: false,
  })
  cloudInitialized = true
  return true
}

export function getCurrentFamilyMembers(): FamilyMember[] {
  return activeFamilyMembers || familyMembers
}

export function refreshFamilyDataFromCloud(force = true): Promise<FamilyMember[]> {
  if (!force && cloudLoadPromise) return cloudLoadPromise
  cloudLoadPromise = new Promise(async (resolve) => {
    if (!initFamilyCloud()) {
      resolve(getCurrentFamilyMembers())
      return
    }
    try {
      const collection = wx.cloud.database().collection(FAMILY_MEMBERS_COLLECTION)
      const allRecords: unknown[] = []
      const pageSize = 20 // 小程序云数据库单次读取上限为 20 条

      for (let offset = 0; offset < 1000; offset += pageSize) {
        const result = await collection.skip(offset).limit(pageSize).get()
        const page = result.data || []
        allRecords.push(...page)
        if (page.length < pageSize) break
      }

      const members = allRecords
        .map((item) => normalizeCloudMember(item as Partial<FamilyMember>))
        .filter((item): item is FamilyMember => Boolean(item))
      if (members.length) {
        activeFamilyMembers = sortMembers(members)
      }
    } catch (error) {
      console.warn('读取云端族人数据失败，已使用本地兜底数据', error)
    }
    resolve(getCurrentFamilyMembers())
  })
  return cloudLoadPromise
}

export function getMemberById(id: string): FamilyMember | undefined {
  return getCurrentFamilyMembers().find((member) => member.id === id)
}

export function getLifeStatus(member: FamilyMember): LifeStatus {
  return member.deathYear ? '已故' : '在世'
}

export function getChildren(memberId: string): FamilyMember[] {
  return getCurrentFamilyMembers().filter((member) => member.fatherId === memberId || member.motherId === memberId)
}

export function getSpouses(member: FamilyMember): FamilyMember[] {
  return member.spouseIds.map(getMemberById).filter((item): item is FamilyMember => Boolean(item))
}

export function getMemberOverrides(): Record<string, MemberOverride> {
  return wx.getStorageSync<Record<string, MemberOverride>>(MEMBER_OVERRIDES_KEY) || {}
}

export function getResolvedFamilyMembers(): FamilyMember[] {
  const overrides = getMemberOverrides()
  const customMembers = wx.getStorageSync<FamilyMember[]>(CUSTOM_MEMBERS_KEY) || []
  const memberMap = new Map<string, FamilyMember>()
  getCurrentFamilyMembers().concat(customMembers).forEach((member) => {
    memberMap.set(member.id, { ...member, ...(overrides[member.id] || {}) })
  })
  return sortMembers(Array.from(memberMap.values()))
}

export function saveCustomFamilyMember(member: FamilyMember) {
  const customMembers = wx.getStorageSync<FamilyMember[]>(CUSTOM_MEMBERS_KEY) || []
  const index = customMembers.findIndex((item) => item.id === member.id)
  if (index >= 0) customMembers[index] = member
  else customMembers.push(member)
  wx.setStorageSync(CUSTOM_MEMBERS_KEY, customMembers)
}

export function getResolvedMemberById(id: string): FamilyMember | undefined {
  return getResolvedFamilyMembers().find((member) => member.id === id)
}

export function getResolvedChildren(memberId: string): FamilyMember[] {
  return getResolvedFamilyMembers().filter((member) => member.fatherId === memberId || member.motherId === memberId)
}

export function getResolvedSpouses(member: FamilyMember): FamilyMember[] {
  const members = getResolvedFamilyMembers()
  return member.spouseIds.map((id) => members.find((item) => item.id === id)).filter((item): item is FamilyMember => Boolean(item))
}

export function saveMemberOverride(memberId: string, field: EditableMemberField, value: string) {
  const overrides = getMemberOverrides()
  overrides[memberId] = { ...(overrides[memberId] || {}), [field]: value }
  wx.setStorageSync(MEMBER_OVERRIDES_KEY, overrides)
}

export function saveMemberOverrides(memberId: string, values: MemberOverride) {
  const overrides = getMemberOverrides()
  overrides[memberId] = { ...(overrides[memberId] || {}), ...values }
  wx.setStorageSync(MEMBER_OVERRIDES_KEY, overrides)
}

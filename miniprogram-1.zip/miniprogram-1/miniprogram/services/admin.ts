import {
  EditableMemberField,
  FamilyMember,
  IdentityEditableMemberField,
  saveMemberOverride,
} from '../data/family'

export type AdminRole = 'owner' | 'admin' | 'member'
export type ReviewStatus = 'pending' | 'approved' | 'rejected'

export interface AdminApplication {
  id: string
  applicantOpenid: string
  applicantMemberId: string
  applicantName: string
  reason: string
  submittedAt: string
  status: ReviewStatus
}

export interface MemberChangeRequest {
  id: string
  memberId: string
  memberName: string
  field: EditableMemberField
  fieldLabel: string
  oldValue: string
  newValue: string
  submitterMemberId: string
  submitterName: string
  submittedAt: string
  status: ReviewStatus
  reviewerName?: string
  reviewedAt?: string
}

export type IdentityApplicationType = 'existing' | 'new' | 'edit'

export interface IdentityFieldChange {
  field: IdentityEditableMemberField
  label: string
  oldValue: string
  newValue: string
}

export interface IdentityEditDraft {
  name: string
  gender: '男' | '女'
  birthYear: number
  region: string
  generation: number
  generationName: string
  branch: string
}

export interface IdentityApplication {
  id: string
  type: IdentityApplicationType
  applicantOpenid?: string
  targetMemberId?: string
  targetMemberName?: string
  applicantName: string
  gender?: '男' | '女'
  birthYear?: number
  region?: string
  generation?: number
  generationName?: string
  changes?: IdentityFieldChange[]
  note: string
  submittedAt: string
  status: ReviewStatus
  approvedMemberId?: string
  reviewedAt?: string
}

const IDENTITY_KEY = 'fuqingpu_identity_member_id'
const IDENTITY_APPROVED_KEY = 'fuqingpu_identity_approved'
const ADMIN_APPLICATIONS_KEY = 'fuqingpu_admin_applications'
const ADMIN_MEMBERS_KEY = 'fuqingpu_admin_members'
const CHANGE_REQUESTS_KEY = 'fuqingpu_member_change_requests'
const IDENTITY_APPLICATIONS_KEY = 'fuqingpu_identity_applications'
const ACCOUNT_ROLE_KEY = 'fuqingpu_account_role'
const ACCOUNT_OPENID_KEY = 'fuqingpu_account_openid'
const OWNER_CONFIGURED_KEY = 'fuqingpu_owner_configured'
const CLOUD_ADMINS_KEY = 'fuqingpu_cloud_admins'
const ACCOUNT_ERROR_KEY = 'fuqingpu_account_error'

export interface CloudAdminAccount {
  openid: string
  memberId: string
  memberName: string
  enabled: boolean
}

export const editableFields: Array<{ key: EditableMemberField; label: string }> = [
  { key: 'name', label: '姓名' },
  { key: 'region', label: '籍居地区' },
  { key: 'bio', label: '人物小传' },
  { key: 'story', label: '家族故事' },
]

function nowText(): string {
  const date = new Date()
  const pad = (value: number) => String(value).padStart(2, '0')
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}`
}

function createId(prefix: string): string {
  return `${prefix}-${Date.now()}-${Math.floor(Math.random() * 10000)}`
}

export function getVerifiedMemberId(): string {
  if (!wx.getStorageSync<boolean>(IDENTITY_APPROVED_KEY)) return ''
  return wx.getStorageSync<string>(IDENTITY_KEY) || ''
}

export function setVerifiedMemberId(memberId: string) {
  wx.setStorageSync(IDENTITY_KEY, memberId)
  wx.setStorageSync(IDENTITY_APPROVED_KEY, true)
}

export function clearVerifiedMemberId() {
  wx.removeStorageSync(IDENTITY_KEY)
  wx.removeStorageSync(IDENTITY_APPROVED_KEY)
}

export function getIdentityApplications(): IdentityApplication[] {
  return wx.getStorageSync<IdentityApplication[]>(IDENTITY_APPLICATIONS_KEY) || []
}

function saveIdentityApplications(applications: IdentityApplication[]) {
  wx.setStorageSync(IDENTITY_APPLICATIONS_KEY, applications)
}

function mergeIdentityApplications(incoming: IdentityApplication[], replace = false): IdentityApplication[] {
  const map = new Map<string, IdentityApplication>()
  if (!replace) getIdentityApplications().forEach((item) => map.set(item.id, item))
  incoming.forEach((item) => {
    if (item && item.id) map.set(item.id, item)
  })
  const applications = Array.from(map.values()).sort((left, right) => right.submittedAt.localeCompare(left.submittedAt))
  saveIdentityApplications(applications)
  return applications
}

function isCurrentAccountApplication(application: IdentityApplication): boolean {
  const currentOpenid = getCurrentAccountOpenid()
  if (!currentOpenid) return !application.applicantOpenid
  return !application.applicantOpenid || application.applicantOpenid === currentOpenid
}

function cloudMessage(value: unknown, fallback: string): string {
  if (value && typeof value === 'object' && 'message' in value) {
    const message = String((value as { message?: unknown }).message || '').trim()
    if (message) return message
  }
  return fallback
}

async function callIdentityCloud(
  action: string,
  data: WechatMiniprogram.IAnyObject = {},
): Promise<{ ok?: boolean; message?: string; application?: IdentityApplication; applications?: IdentityApplication[]; approvedMemberId?: string }> {
  if (!wx.cloud) throw new Error('当前基础库不支持云开发，请升级微信后重试。')
  const result = await wx.cloud.callFunction({
    name: 'accountidentity',
    data: { action, ...data },
  })
  const response = result.result as {
    ok?: boolean
    message?: string
    application?: IdentityApplication
    applications?: IdentityApplication[]
    approvedMemberId?: string
  }
  if (!response || !response.ok) throw new Error(cloudMessage(response, '云端身份服务没有返回有效结果。'))
  return response
}

export function getCurrentIdentityApplication(): IdentityApplication | undefined {
  return getIdentityApplications().find((item) => isCurrentAccountApplication(item) && item.type !== 'edit' && item.status === 'pending')
}

export function getCurrentIdentityEditApplication(memberId: string): IdentityApplication | undefined {
  return getIdentityApplications().find((item) => isCurrentAccountApplication(item) && item.type === 'edit' && item.targetMemberId === memberId && item.status === 'pending')
}

export async function refreshMyIdentityApplications(): Promise<IdentityApplication[]> {
  try {
    const response = await callIdentityCloud('listMyIdentityApplications')
    return mergeIdentityApplications(Array.isArray(response.applications) ? response.applications : [], true)
  } catch (error) {
    console.warn('读取我的身份申请失败', error)
    return getIdentityApplications()
  }
}

export async function refreshCloudIdentityApplications(): Promise<IdentityApplication[]> {
  const role = getCurrentAdminRole()
  if (role !== 'owner' && role !== 'admin') return getIdentityApplications()
  try {
    const response = await callIdentityCloud('listIdentityApplications')
    return mergeIdentityApplications(Array.isArray(response.applications) ? response.applications : [], true)
  } catch (error) {
    console.warn('读取待审核身份申请失败', error)
    return getIdentityApplications()
  }
}

export async function submitExistingIdentityApplication(
  member: FamilyMember,
  applicantName: string,
  note: string,
): Promise<IdentityApplication> {
  const current = getIdentityApplications().find((item) => isCurrentAccountApplication(item) && item.status === 'pending')
  if (current) return current
  const response = await callIdentityCloud('submitIdentityApplication', {
    application: {
      type: 'existing',
      targetMemberId: member.id,
      applicantName,
      note,
    },
  })
  if (!response.application) throw new Error('云端没有返回身份申请。')
  mergeIdentityApplications([response.application])
  return response.application
}

export async function submitNewIdentityApplication(
  draft: Pick<IdentityApplication, 'applicantName' | 'gender' | 'birthYear' | 'region' | 'generation' | 'generationName' | 'note'>,
): Promise<IdentityApplication> {
  const current = getIdentityApplications().find((item) => isCurrentAccountApplication(item) && item.status === 'pending')
  if (current) return current
  const response = await callIdentityCloud('submitIdentityApplication', {
    application: { type: 'new', ...draft },
  })
  if (!response.application) throw new Error('云端没有返回身份申请。')
  mergeIdentityApplications([response.application])
  return response.application
}

export async function submitIdentityEditApplication(
  member: FamilyMember,
  draft: IdentityEditDraft,
  note: string,
): Promise<IdentityApplication | undefined> {
  const current = getIdentityApplications().find((item) => isCurrentAccountApplication(item) && item.type === 'edit' && item.targetMemberId === member.id && item.status === 'pending')
  if (current) return current

  const fields: Array<{ field: IdentityEditableMemberField; label: string; value: string | number }> = [
    { field: 'name', label: '姓名', value: draft.name.trim() },
    { field: 'gender', label: '性别', value: draft.gender },
    { field: 'birthYear', label: '出生年份', value: draft.birthYear },
    { field: 'region', label: '籍居地区', value: draft.region.trim() },
    { field: 'generation', label: '世次', value: draft.generation },
    { field: 'generationName', label: '字辈', value: draft.generationName.trim() },
    { field: 'branch', label: '排行', value: draft.branch.trim() },
  ]
  const changes = fields.reduce<IdentityFieldChange[]>((result, item) => {
    const oldValue = String(member[item.field] || '')
    const newValue = String(item.value)
    if (oldValue !== newValue) result.push({ field: item.field, label: item.label, oldValue, newValue })
    return result
  }, [])
  if (!changes.length) return undefined

  const response = await callIdentityCloud('submitIdentityApplication', {
    application: {
      type: 'edit',
      targetMemberId: member.id,
      applicantName: member.name,
      changes,
      note,
    },
  })
  if (!response.application) throw new Error('云端没有返回身份修改申请。')
  mergeIdentityApplications([response.application])
  return response.application
}

export async function reviewIdentityApplication(id: string, status: 'approved' | 'rejected'): Promise<boolean> {
  const role = getCurrentAdminRole()
  if (role !== 'owner' && role !== 'admin') return false
  const applications = getIdentityApplications()
  const target = applications.find((item) => item.id === id)
  if (!target || target.status !== 'pending') return false
  const response = await callIdentityCloud('reviewIdentityApplication', {
    applicationId: id,
    status,
  })
  const reviewed = response.application || { ...target, status, reviewedAt: nowText(), approvedMemberId: response.approvedMemberId }
  mergeIdentityApplications([reviewed])

  if (
    status === 'approved'
    && response.approvedMemberId
    && target.applicantOpenid
    && target.applicantOpenid === getCurrentAccountOpenid()
  ) {
    setVerifiedMemberId(response.approvedMemberId)
  }
  return true
}

export function isOwnerSession(): boolean {
  return wx.getStorageSync<AdminRole>(ACCOUNT_ROLE_KEY) === 'owner'
}

export function getCurrentAccountOpenid(): string {
  return wx.getStorageSync<string>(ACCOUNT_OPENID_KEY) || ''
}

export function isOwnerAccountConfigured(): boolean {
  return Boolean(wx.getStorageSync<boolean>(OWNER_CONFIGURED_KEY))
}

export function getAccountRoleError(): string {
  return wx.getStorageSync<string>(ACCOUNT_ERROR_KEY) || ''
}

export async function refreshAccountRole(): Promise<AdminRole> {
  const legacyMemberId = getVerifiedMemberId()
  try {
    let response: {
      ok?: boolean
      role?: AdminRole
      openid?: string
      ownerConfigured?: boolean
      identityMemberId?: string
      message?: string
    } | undefined
    let lastError: unknown
    for (let attempt = 0; attempt < 2; attempt += 1) {
      try {
        const result = await wx.cloud.callFunction({
          name: 'accountidentity',
          data: { action: 'getRole' },
        })
        response = result.result as typeof response
        if (!response || !response.ok) throw new Error(response && response.message ? response.message : '云函数没有返回有效账号信息')
        break
      } catch (error) {
        lastError = error
      }
    }
    if (!response || !response.ok) throw lastError || new Error('云函数没有返回有效账号信息')
    const role = response.role || 'member'
    wx.setStorageSync(ACCOUNT_ROLE_KEY, role)
    wx.setStorageSync(ACCOUNT_OPENID_KEY, response.openid || '')
    wx.setStorageSync(OWNER_CONFIGURED_KEY, Boolean(response.ownerConfigured))
    let cloudIdentityMemberId = response.identityMemberId || ''
    if (!cloudIdentityMemberId && role === 'owner' && legacyMemberId) {
      try {
        const migration = await wx.cloud.callFunction({
          name: 'accountidentity',
          data: { action: 'bindOwnerIdentity', memberId: legacyMemberId },
        })
        const migrationResponse = migration.result as { ok?: boolean; identityMemberId?: string }
        if (migrationResponse && migrationResponse.ok && migrationResponse.identityMemberId) {
          cloudIdentityMemberId = migrationResponse.identityMemberId
        }
      } catch (migrationError) {
        console.warn('迁移谱主原有身份绑定失败', migrationError)
      }
    }
    if (cloudIdentityMemberId) setVerifiedMemberId(cloudIdentityMemberId)
    else clearVerifiedMemberId()
    wx.removeStorageSync(ACCOUNT_ERROR_KEY)
    return role
  } catch (error) {
    console.warn('读取云端账号权限失败', error)
    const detail = error && (error as { errMsg?: string; message?: string }).errMsg
      ? (error as { errMsg: string }).errMsg
      : error && (error as { message?: string }).message
        ? (error as { message: string }).message
        : String(error)
    wx.setStorageSync(ACCOUNT_ERROR_KEY, detail)
    wx.setStorageSync(ACCOUNT_ROLE_KEY, 'member')
    wx.removeStorageSync(ACCOUNT_OPENID_KEY)
    wx.setStorageSync(OWNER_CONFIGURED_KEY, false)
    clearVerifiedMemberId()
    return 'member'
  }
}

export function getAdminMembers(): string[] {
  const cloudAdmins = wx.getStorageSync<CloudAdminAccount[]>(CLOUD_ADMINS_KEY) || []
  if (cloudAdmins.length) return cloudAdmins.map((item) => item.memberId).filter(Boolean)
  return wx.getStorageSync<string[]>(ADMIN_MEMBERS_KEY) || []
}

export function getCurrentAdminRole(): AdminRole {
  return wx.getStorageSync<AdminRole>(ACCOUNT_ROLE_KEY) || 'member'
}

export async function refreshCloudAdmins(): Promise<CloudAdminAccount[]> {
  if (!isOwnerSession()) return []
  try {
    const result = await wx.cloud.callFunction({ name: 'accountidentity', data: { action: 'listAdmins' } })
    const response = result.result as { ok?: boolean; admins?: CloudAdminAccount[] }
    const admins = response && response.ok && Array.isArray(response.admins) ? response.admins : []
    wx.setStorageSync(CLOUD_ADMINS_KEY, admins)
    return admins
  } catch (error) {
    console.warn('读取管理员列表失败', error)
    return wx.getStorageSync<CloudAdminAccount[]>(CLOUD_ADMINS_KEY) || []
  }
}

export function getAdminApplications(): AdminApplication[] {
  return wx.getStorageSync<AdminApplication[]>(ADMIN_APPLICATIONS_KEY) || []
}

export function submitAdminApplication(member: FamilyMember, reason: string): AdminApplication {
  const applications = getAdminApplications()
  const existing = applications.find((item) => item.applicantMemberId === member.id && item.status === 'pending')
  if (existing) return existing
  const application: AdminApplication = {
    id: createId('admin'),
    applicantOpenid: getCurrentAccountOpenid(),
    applicantMemberId: member.id,
    applicantName: member.name,
    reason,
    submittedAt: nowText(),
    status: 'pending',
  }
  applications.unshift(application)
  wx.setStorageSync(ADMIN_APPLICATIONS_KEY, applications)
  return application
}

export async function reviewAdminApplication(id: string, status: 'approved' | 'rejected'): Promise<boolean> {
  if (!isOwnerSession()) return false
  const applications = getAdminApplications()
  const target = applications.find((item) => item.id === id)
  if (!target || !target.applicantOpenid) return false
  if (status === 'approved') {
    const result = await wx.cloud.callFunction({
      name: 'accountidentity',
      data: {
        action: 'grantAdmin',
        targetOpenid: target.applicantOpenid,
        memberId: target.applicantMemberId,
        memberName: target.applicantName,
      },
    })
    const response = result.result as { ok?: boolean }
    if (!response || !response.ok) return false
  }
  target.status = status
  wx.setStorageSync(ADMIN_APPLICATIONS_KEY, applications)
  await refreshCloudAdmins()
  return true
}

export async function revokeAdmin(memberId: string): Promise<boolean> {
  if (!isOwnerSession()) return false
  const admins = wx.getStorageSync<CloudAdminAccount[]>(CLOUD_ADMINS_KEY) || []
  const target = admins.find((item) => item.memberId === memberId)
  if (!target || !target.openid) return false
  const result = await wx.cloud.callFunction({
    name: 'accountidentity',
    data: { action: 'revokeAdmin', targetOpenid: target.openid },
  })
  const response = result.result as { ok?: boolean }
  if (!response || !response.ok) return false
  await refreshCloudAdmins()
  return true
}

export function getMemberChangeRequests(): MemberChangeRequest[] {
  return wx.getStorageSync<MemberChangeRequest[]>(CHANGE_REQUESTS_KEY) || []
}

export function submitMemberChangeRequest(
  member: FamilyMember,
  field: EditableMemberField,
  value: string,
  submitter: FamilyMember,
): MemberChangeRequest {
  const fieldInfo = editableFields.find((item) => item.key === field) as { key: EditableMemberField; label: string }
  const request: MemberChangeRequest = {
    id: createId('change'),
    memberId: member.id,
    memberName: member.name,
    field,
    fieldLabel: fieldInfo.label,
    oldValue: String(member[field]),
    newValue: value,
    submitterMemberId: submitter.id,
    submitterName: submitter.name,
    submittedAt: nowText(),
    status: 'pending',
  }
  const requests = getMemberChangeRequests()
  requests.unshift(request)
  wx.setStorageSync(CHANGE_REQUESTS_KEY, requests)
  return request
}

export function reviewMemberChangeRequest(
  id: string,
  status: 'approved' | 'rejected',
  reviewerName: string,
): boolean {
  const role = getCurrentAdminRole()
  if (role !== 'owner' && role !== 'admin') return false
  const requests = getMemberChangeRequests()
  const target = requests.find((item) => item.id === id)
  if (!target || target.status !== 'pending') return false
  target.status = status
  target.reviewerName = reviewerName
  target.reviewedAt = nowText()
  if (status === 'approved') saveMemberOverride(target.memberId, target.field, target.newValue)
  wx.setStorageSync(CHANGE_REQUESTS_KEY, requests)
  return true
}

import { FamilyMember, getLifeStatus, getResolvedFamilyMembers, refreshFamilyDataFromCloud } from '../../data/family'
import { getAccountRoleError, getVerifiedMemberId, refreshAccountRole } from '../../services/admin'
import { getIdentityLabel, getRelationshipLabel } from '../../utils/relationship'

interface MemberCard extends FamilyMember {
  avatar: string
  status: string
  years: string
  identityTag: string
  relationTag: string
}

interface DirectoryMetric {
  value: number
  label: string
  mark: string
}

function toCard(member: FamilyMember, viewerId: string, members: FamilyMember[]): MemberCard {
  return {
    ...member,
    avatar: member.name.slice(1, 2),
    status: getLifeStatus(member),
    years: member.deathYear ? `${member.birthYear}—${member.deathYear}` : `${member.birthYear}—`,
    identityTag: getIdentityLabel(member, members),
    relationTag: getRelationshipLabel(viewerId, member.id, members),
  }
}

function buildDirectoryMetrics(members: FamilyMember[]): DirectoryMetric[] {
  return [
    { value: members.length, label: '谱中成员', mark: '人' },
    { value: members.filter((member) => !member.deathYear).length, label: '在世族人', mark: '生' },
    { value: new Set(members.map((member) => member.region)).size, label: '分布地区', mark: '地' },
  ]
}

const initialMembers = getResolvedFamilyMembers()

Page({
  data: {
    keyword: '',
    branch: '全部',
    generation: 0,
    branches: ['全部', '长子', '长女', '次子', '次女', '长媳', '次媳', '排行待考'],
    generations: [
      { value: 0, label: '全部' },
      { value: 1, label: '一世·承' },
      { value: 2, label: '二世·德' },
      { value: 3, label: '三世·泽' },
      { value: 4, label: '四世·绵' },
      { value: 5, label: '五世·世' },
    ],
    members: initialMembers.map((member) => toCard(member, '', initialMembers)),
    resultCount: initialMembers.length,
    viewMode: 'card',
    directoryMetrics: buildDirectoryMetrics(initialMembers),
  },

  async onShow() {
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({ selected: 2 })
    }
    await refreshAccountRole()
    if (!getVerifiedMemberId()) {
      const accountError = getAccountRoleError()
      wx.showModal({
        title: accountError ? '云端身份暂时未连接' : '族人资料尚未开放',
        content: accountError ? '原绑定仍保存在云端，恢复网络后会自动恢复，不需要重新认证。' : '请先提交身份认证。管理员审核通过并绑定身份后，才能查看族人名录和详细资料。',
        confirmText: accountError ? '去重新连接' : '去认证',
        showCancel: false,
        success: () => wx.switchTab({ url: '/pages/profile/profile' }),
      })
      return
    }
    await refreshFamilyDataFromCloud()
    const storedBranch = wx.getStorageSync<string>('fuqingpu_member_branch')
    if (storedBranch) {
      wx.removeStorageSync('fuqingpu_member_branch')
      this.setData({ branch: storedBranch })
    }
    this.applyFilters()
  },

  onSearchInput(event: WechatMiniprogram.Input) {
    this.setData({ keyword: event.detail.value }, () => this.applyFilters())
  },

  clearSearch() {
    this.setData({ keyword: '' }, () => this.applyFilters())
  },

  chooseBranch(event: WechatMiniprogram.TouchEvent) {
    this.setData({ branch: event.currentTarget.dataset.branch }, () => this.applyFilters())
  },

  chooseGeneration(event: WechatMiniprogram.TouchEvent) {
    this.setData({ generation: Number(event.currentTarget.dataset.value) }, () => this.applyFilters())
  },

  applyFilters() {
    const allMembers = getResolvedFamilyMembers()
    const viewerId = getVerifiedMemberId()
    const keyword = this.data.keyword.trim().toLowerCase()
    const members = allMembers.filter((member) => {
      const matchKeyword = !keyword || [member.name, member.courtesyName || '', member.region, member.generationName].some((value) => value.toLowerCase().includes(keyword))
      const matchBranch = this.data.branch === '全部' || member.branch === this.data.branch
      const matchGeneration = this.data.generation === 0 || member.generation === this.data.generation
      return matchKeyword && matchBranch && matchGeneration
    }).map((member) => toCard(member, viewerId, allMembers))
    this.setData({
      members,
      resultCount: members.length,
      directoryMetrics: buildDirectoryMetrics(allMembers),
    })
  },

  resetFilters() {
    this.setData({ keyword: '', branch: '全部', generation: 0 }, () => this.applyFilters())
  },

  toggleView() {
    this.setData({ viewMode: this.data.viewMode === 'card' ? 'compact' : 'card' })
  },

  openMember(event: WechatMiniprogram.TouchEvent) {
    wx.navigateTo({ url: `/pages/member-detail/member-detail?id=${event.currentTarget.dataset.id}` })
  },
})

import { FamilyMember, getResolvedFamilyMembers, getResolvedMemberById, getResolvedSpouses, refreshFamilyDataFromCloud } from '../../data/family'
import { getAccountRoleError, getVerifiedMemberId, refreshAccountRole } from '../../services/admin'

interface TreeNode extends FamilyMember {
  x: number
  y: number
  spouseNames: string
  avatar: string
}

interface TreeLink {
  id: string
  parentId: string
  childId: string
  left: number
  top: number
  width: number
  angle: number
}

const NODE_WIDTH = 240
const NODE_HEIGHT = 142
const MIN_SCALE = 0.55
const MAX_SCALE = 1.4
const SCALE_STEP = 0.1
const INITIAL_SCALE = 0.68
const INITIAL_GRAPH_X = -225
const INITIAL_GRAPH_Y = 10
const positions: Record<string, { x: number; y: number }> = {
  f001: { x: 850, y: 80 },
  f101: { x: 350, y: 370 }, f103: { x: 1050, y: 370 }, f105: { x: 1580, y: 370 },
  f201: { x: 90, y: 660 }, f203: { x: 420, y: 660 }, f205: { x: 750, y: 660 }, f206: { x: 1080, y: 660 }, f208: { x: 1510, y: 660 },
  f301: { x: 20, y: 950 }, f303: { x: 280, y: 950 }, f304: { x: 540, y: 950 }, f305: { x: 800, y: 950 }, f306: { x: 1060, y: 950 }, f308: { x: 1320, y: 950 }, f309: { x: 1580, y: 950 }, f310: { x: 1840, y: 950 },
  f401: { x: 20, y: 1240 }, f402: { x: 280, y: 1240 }, f405: { x: 580, y: 1240 }, f403: { x: 1050, y: 1240 }, f404: { x: 1310, y: 1240 }, f406: { x: 1570, y: 1240 },
}

function buildNodes(): TreeNode[] {
  return Object.keys(positions).map((id) => {
    const member = getResolvedMemberById(id)
    if (!member) return null
    return {
      ...member,
      ...positions[id],
      spouseNames: getResolvedSpouses(member).map((spouse) => spouse.name).join('、'),
      avatar: member.name.slice(1, 2),
    }
  }).filter((item): item is TreeNode => Boolean(item))
}

function buildLinks(nodes: TreeNode[]): TreeLink[] {
  const nodeMap = new Map(nodes.map((node) => [node.id, node]))
  const links: TreeLink[] = []
  nodes.forEach((child) => {
    if (!child.fatherId || !nodeMap.has(child.fatherId)) return
    const parent = nodeMap.get(child.fatherId) as TreeNode
    const left = parent.x + NODE_WIDTH / 2
    const top = parent.y + NODE_HEIGHT
    const dx = child.x - parent.x
    const dy = child.y - top
    links.push({
      id: `${parent.id}-${child.id}`,
      parentId: parent.id,
      childId: child.id,
      left,
      top,
      width: Math.sqrt(dx * dx + dy * dy),
      angle: Math.atan2(dy, dx) * 180 / Math.PI,
    })
  })
  return links
}

let treeNodes = buildNodes()
let treeLinks = buildLinks(treeNodes)
let currentScale = INITIAL_SCALE
let currentGraphX = INITIAL_GRAPH_X
let currentGraphY = INITIAL_GRAPH_Y

function clampScale(scale: number) {
  return Math.min(MAX_SCALE, Math.max(MIN_SCALE, scale))
}

Page({
  data: {
    treeNodes,
    treeLinks,
    generations: [
      { name: '第一世 · 承', y: 100 },
      { name: '第二世 · 德', y: 390 },
      { name: '第三世 · 泽', y: 680 },
      { name: '第四世 · 绵', y: 970 },
      { name: '第五世 · 世', y: 1260 },
    ],
    keyword: '',
    focusedId: 'f001',
    selectedMember: treeNodes[0],
    scaleValue: INITIAL_SCALE,
    scaleText: 68,
    graphX: INITIAL_GRAPH_X,
    graphY: INITIAL_GRAPH_Y,
    mode: '完整谱系',
  },

  onLoad() {
    currentScale = this.data.scaleValue
    currentGraphX = this.data.graphX
    currentGraphY = this.data.graphY
  },

  async onShow() {
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({ selected: 1 })
    }
    await refreshAccountRole()
    if (!getVerifiedMemberId()) {
      const accountError = getAccountRoleError()
      wx.showModal({
        title: accountError ? '云端身份暂时未连接' : '族谱尚未开放',
        content: accountError ? '原绑定仍保存在云端，恢复网络后会自动恢复，不需要重新认证。' : '族谱关系属于认证族人资料。请先提交身份认证，等待管理员审核通过。',
        confirmText: accountError ? '去重新连接' : '去认证',
        showCancel: false,
        success: () => wx.switchTab({ url: '/pages/profile/profile' }),
      })
      return
    }
    await refreshFamilyDataFromCloud()
    treeNodes = buildNodes()
    treeLinks = buildLinks(treeNodes)
    const selectedMember = treeNodes.find((item) => item.id === this.data.focusedId) || treeNodes[0]
    this.setData({ treeNodes, treeLinks, selectedMember })
    const focusId = wx.getStorageSync('fuqingpu_tree_focus') as string
    if (!focusId) return
    wx.removeStorageSync('fuqingpu_tree_focus')
    const node = treeNodes.find((item) => item.id === focusId)
    if (node) {
      setTimeout(() => this.focusNode(node), 120)
    }
  },

  onSearchInput(event: WechatMiniprogram.Input) {
    this.setData({ keyword: event.detail.value })
  },

  searchMember() {
    const keyword = this.data.keyword.trim()
    if (!keyword) {
      wx.showToast({ title: '请输入族人姓名', icon: 'none' })
      return
    }
    const found = getResolvedFamilyMembers().find((member) => member.name.includes(keyword))
    if (!found) {
      wx.showToast({ title: '未找到该族人', icon: 'none' })
      return
    }
    let node = treeNodes.find((item) => item.id === found.id)
    if (!node && found.spouseIds.length) {
      node = treeNodes.find((item) => found.spouseIds.includes(item.id))
    }
    if (!node) {
      wx.showToast({ title: '成员暂未加入关系图', icon: 'none' })
      return
    }
    this.focusNode(node)
    wx.showToast({ title: `已定位 ${found.name}`, icon: 'none' })
  },

  chooseNode(event: WechatMiniprogram.TouchEvent) {
    const id = event.currentTarget.dataset.id as string
    const node = treeNodes.find((item) => item.id === id)
    if (node) this.setData({ focusedId: id, selectedMember: node })
  },

  focusNode(node: TreeNode) {
    const nodeIsVisible = this.data.treeNodes.some((item) => item.id === node.id)
    const info = wx.getSystemInfoSync()
    const rpx = info.windowWidth / 750
    this.createSelectorQuery().select('.graph-viewport').boundingClientRect((rect) => {
      currentGraphX = rect.width / 2 - (node.x + NODE_WIDTH / 2) * rpx * currentScale
      currentGraphY = rect.height / 2 - (node.y + NODE_HEIGHT / 2) * rpx * currentScale
      this.setData({
        focusedId: node.id,
        selectedMember: node,
        graphX: currentGraphX,
        graphY: currentGraphY,
        ...(nodeIsVisible ? {} : { treeNodes, treeLinks, mode: '完整谱系' }),
      })
    }).exec()
  },

  backToAncestor() {
    this.focusNode(treeNodes[0])
  },

  zoomIn() {
    this.zoomTo(currentScale + SCALE_STEP)
  },

  zoomOut() {
    this.zoomTo(currentScale - SCALE_STEP)
  },

  zoomTo(nextScale: number) {
    const scaleValue = Number(clampScale(nextScale).toFixed(2))
    if (scaleValue === currentScale) return
    const previousScale = currentScale
    this.createSelectorQuery().select('.graph-viewport').boundingClientRect((rect) => {
      const ratio = scaleValue / previousScale
      const centerX = rect.width / 2
      const centerY = rect.height / 2
      currentGraphX = centerX - (centerX - currentGraphX) * ratio
      currentGraphY = centerY - (centerY - currentGraphY) * ratio
      currentScale = scaleValue
      this.setData({
        scaleValue,
        scaleText: Math.round(scaleValue * 100),
        graphX: currentGraphX,
        graphY: currentGraphY,
      })
    }).exec()
  },

  onGraphChange(event: WechatMiniprogram.CustomEvent) {
    const detail = event.detail as { x: number; y: number }
    if (Number.isFinite(detail.x)) currentGraphX = detail.x
    if (Number.isFinite(detail.y)) currentGraphY = detail.y
  },

  onScale(event: WechatMiniprogram.CustomEvent) {
    const detail = event.detail as { x: number; y: number; scale: number }
    if (!Number.isFinite(detail.scale)) return
    currentScale = clampScale(detail.scale)
    if (Number.isFinite(detail.x)) currentGraphX = detail.x
    if (Number.isFinite(detail.y)) currentGraphY = detail.y

  },

  onGraphTouchEnd() {
    // movable-view 在双指缩放期间保持纯原生更新；手势结束后再一次性保存最终状态，
    // 避免 setData 在手势过程中将旧的 x/y/scale 写回组件造成持续抖动。
    this.setData({
      scaleValue: Number(currentScale.toFixed(3)),
      scaleText: Math.round(currentScale * 100),
      graphX: currentGraphX,
      graphY: currentGraphY,
    })
  },

  openDetail() {
    wx.navigateTo({ url: `/pages/member-detail/member-detail?id=${this.data.selectedMember.id}` })
  },

  switchMode() {
    const modes = ['完整谱系', '直系谱系', '上下三代']
    const nextIndex = (modes.indexOf(this.data.mode) + 1) % modes.length
    const mode = modes[nextIndex]
    let visibleIds = new Set(treeNodes.map((node) => node.id))

    if (mode === '上下三代') {
      const generation = this.data.selectedMember.generation
      visibleIds = new Set(treeNodes.filter((node) => Math.abs(node.generation - generation) <= 1).map((node) => node.id))
    }

    if (mode === '直系谱系') {
      visibleIds = new Set([this.data.selectedMember.id])
      let ancestor = this.data.selectedMember
      while (ancestor.fatherId) {
        visibleIds.add(ancestor.fatherId)
        const nextAncestor = treeNodes.find((node) => node.id === ancestor.fatherId)
        if (!nextAncestor) break
        ancestor = nextAncestor
      }
      let changed = true
      while (changed) {
        changed = false
        treeNodes.forEach((node) => {
          if (node.fatherId && visibleIds.has(node.fatherId) && !visibleIds.has(node.id)) {
            visibleIds.add(node.id)
            changed = true
          }
        })
      }
    }

    const visibleNodes = treeNodes.filter((node) => visibleIds.has(node.id))
    const visibleLinks = treeLinks.filter((link) => visibleIds.has(link.parentId) && visibleIds.has(link.childId))
    this.setData({ mode, treeNodes: visibleNodes, treeLinks: visibleLinks })
    wx.showToast({ title: `${visibleNodes.length} 位谱系成员`, icon: 'none' })
  },
})

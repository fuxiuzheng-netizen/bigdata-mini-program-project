import { getResolvedFamilyMembers, getResolvedMemberById, refreshFamilyDataFromCloud } from '../../data/family'
import {
  getAdminApplications,
  getAccountRoleError,
  getCurrentAdminRole,
  getCurrentIdentityApplication,
  getIdentityApplications,
  getMemberChangeRequests,
  getVerifiedMemberId,
  refreshAccountRole,
  refreshCloudIdentityApplications,
  refreshMyIdentityApplications,
} from '../../services/admin'
import { getIdentityLabel } from '../../utils/relationship'

Page({
  data: {
    collectedCount: 0,
    submissionCount: 0,
    generationText: '—',
    isVerified: false,
    avatar: '傅',
    profileName: '访客族人',
    profileTag: '未认证',
    profileNote: '认证族人后，可定位自己的族谱位置',
    verifyButtonText: '去认证',
    identityInviteTitle: '找到你在族谱中的位置',
    identityInviteText: '完成族人认证，连接父母、子女与家族世系',
    adminRole: 'member',
    adminRoleLabel: '普通成员',
    adminRoleNote: '认证后可申请成为谱务管理员',
    adminPendingCount: 0,
    tools: [
      { key: 'kinship', icon: '称', title: '亲属称谓', note: '按族人查看我的称呼' },
      { key: 'poster', icon: '签', title: '家族签章', note: '生成青谱名帖' },
      { key: 'invite', icon: '邀', title: '邀请族人', note: '一起补全族谱' },
      { key: 'backup', icon: '存', title: '资料备份', note: '安全导出留存' },
    ],
    menuGroups: [
      { id: 'identity', items: [
        { key: 'identity', icon: '谱', title: '我的家族身份', note: '认证后定位本人世系' },
        { key: 'relations', icon: '亲', title: '我的亲属', note: '查看上下三代亲属' },
        { key: 'collect', icon: '藏', title: '我的收藏', note: '0 位族人' },
      ] },
      { id: 'contribute', items: [
        { key: 'edit', icon: '补', title: '补充家族资料', note: '从族人档案提交资料修订' },
        { key: 'review', icon: '核', title: '纠错与审核记录', note: '查看谱务审核进度' },
        { key: 'privacy', icon: '隐', title: '隐私与资料说明', note: '三级资料保护规则' },
      ] },
      { id: 'about', items: [
        { key: 'about', icon: '青', title: '关于傅庭知源', note: '墨竹成谱，枝叶同源' },
      ] },
    ],
  },

  async onShow() {
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({ selected: 4 })
    }
    const role = await refreshAccountRole()
    if (role === 'owner' || role === 'admin') await refreshCloudIdentityApplications()
    else await refreshMyIdentityApplications()
    await refreshFamilyDataFromCloud()
    this.refreshProfile()
  },

  refreshProfile() {
    const collected = wx.getStorageSync<string[]>('fuqingpu_collected') || []
    const verifiedId = getVerifiedMemberId()
    const member = verifiedId ? getResolvedMemberById(verifiedId) : undefined
    const members = getResolvedFamilyMembers()
    const requests = getMemberChangeRequests()
    const applications = getAdminApplications()
    const identityApplications = getIdentityApplications()
    const role = getCurrentAdminRole()
    const accountError = getAccountRoleError()
    const identityApplication = getCurrentIdentityApplication()
    const submissionCount = member ? requests.filter((item) => item.submitterMemberId === member.id).length : 0
    const pendingReviewCount = role === 'owner' || role === 'admin'
      ? requests.filter((item) => item.status === 'pending').length + identityApplications.filter((item) => item.status === 'pending').length
      : applications.filter((item) => item.applicantMemberId === verifiedId && item.status === 'pending').length
    const roleLabel = role === 'owner' ? '唯一谱主' : role === 'admin' ? '谱务管理员' : '普通成员'
    let roleNote = member ? '可申请成为谱务管理员' : '认证后可申请成为谱务管理员'
    if (role === 'owner') roleNote = '唯一授权人，可任免管理员并审核资料'
    if (role === 'admin') roleNote = '可审核成员资料，不可授权其他管理员'
    if (role === 'member' && pendingReviewCount) roleNote = '管理员申请已提交，等待谱主授权'

    const menuGroups = this.data.menuGroups.map((group) => ({
      ...group,
      items: group.items.map((item) => {
        if (item.key === 'collect') return { ...item, note: `${collected.length} 位族人` }
        if (item.key === 'review') return { ...item, note: submissionCount ? `${submissionCount} 条资料提交记录` : '查看谱务审核进度' }
        if (item.key === 'identity' && member) return { ...item, note: `${getIdentityLabel(member, members)} · 第${member.generation}世` }
        return item
      }),
    }))

    this.setData({
      collectedCount: collected.length,
      submissionCount,
      generationText: member ? `第${member.generation}世` : '—',
      isVerified: Boolean(member),
      avatar: member ? member.name.slice(1, 2) : '傅',
      profileName: member ? member.name : '访客族人',
      profileTag: member ? '已认证' : accountError ? '连接中断' : identityApplication ? '审核中' : '未认证',
      profileNote: member
        ? `${getIdentityLabel(member, members)} · ${member.region}`
        : accountError
          ? '暂时无法向云端确认身份，恢复网络后会自动恢复，无需重新绑定'
          : identityApplication
            ? '身份申请已提交，等待管理员审核'
            : '认证族人后，可定位自己的族谱位置',
      verifyButtonText: member ? '查看身份' : accountError ? '重新连接' : identityApplication ? '查看进度' : '去认证',
      identityInviteTitle: member ? `已归谱：${member.name}` : accountError ? '云端身份暂时未连接' : identityApplication ? '身份正在审核' : '找到你在族谱中的位置',
      identityInviteText: member ? '身份已保存到当前微信账号，下次进入会自动恢复' : accountError ? '绑定记录仍保存在云端，网络恢复后自动读取' : identityApplication ? `${identityApplication.submittedAt} 提交，审核通过后自动绑定` : '可认证已有身份，或申请创建新的族人身份',
      adminRole: role,
      adminRoleLabel: roleLabel,
      adminRoleNote: roleNote,
      adminPendingCount: pendingReviewCount,
      menuGroups,
    })
  },

  startVerify() {
    wx.navigateTo({ url: '/pages/identity-verify/identity-verify' })
  },

  openAdminCenter() {
    wx.navigateTo({ url: '/pages/admin/admin' })
  },

  openMenu(event: WechatMiniprogram.TouchEvent) {
    const key = event.currentTarget.dataset.key as string
    if (key === 'identity') {
      this.startVerify()
      return
    }
    if (key === 'collect' || key === 'relations' || key === 'edit') {
      wx.switchTab({ url: '/pages/members/members' })
      return
    }
    if (key === 'review') {
      this.openAdminCenter()
      return
    }
    if (key === 'privacy') {
      wx.showModal({ title: '资料分级', content: '公开资料、认证族内资料、私密资料分级展示；电话、详细地址和证件信息默认不公开。', showCancel: false })
      return
    }
    wx.showToast({ title: '功能入口已预留', icon: 'none' })
  },

  openTool(event: WechatMiniprogram.TouchEvent) {
    const key = event.currentTarget.dataset.key as string
    if (key === 'kinship') {
      if (!getVerifiedMemberId()) {
        wx.showModal({
          title: '请先认证身份',
          content: '绑定本人身份后，系统才能根据族谱关系显示每位族人的姓名和你应使用的称谓。',
          confirmText: '去认证',
          success: (result) => {
            if (result.confirm) this.startVerify()
          },
        })
        return
      }
      wx.switchTab({ url: '/pages/members/members' })
      return
    }
    if (key === 'invite') {
      wx.showShareMenu({ menus: ['shareAppMessage'] })
      wx.showToast({ title: '可点击右上角分享给族人', icon: 'none' })
      return
    }
    const content = key === 'poster'
      ? '家族名帖将组合姓名、字辈与青谱签章。完成族人认证后即可生成专属版本。'
      : '正式版支持加密导出族谱摘要与个人收藏，敏感资料默认不会包含在备份中。'
    wx.showModal({ title: key === 'poster' ? '家族签章' : '资料备份', content, showCancel: false })
  },

  contactAdmin() {
    this.openAdminCenter()
  },

  onShareAppMessage() {
    return { title: '邀请你一起续写傅庭知源', path: '/pages/index/index' }
  },
})

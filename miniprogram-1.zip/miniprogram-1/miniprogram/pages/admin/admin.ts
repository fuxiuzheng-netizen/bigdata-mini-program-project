import { FamilyMember, getResolvedMemberById, refreshFamilyDataFromCloud } from '../../data/family'
import {
  AdminApplication,
  IdentityApplication,
  MemberChangeRequest,
  getAdminApplications,
  getAdminMembers,
  getAccountRoleError,
  getCurrentAccountOpenid,
  getCurrentAdminRole,
  getIdentityApplications,
  getMemberChangeRequests,
  getVerifiedMemberId,
  isOwnerAccountConfigured,
  reviewAdminApplication,
  reviewIdentityApplication,
  reviewMemberChangeRequest,
  refreshAccountRole,
  refreshCloudAdmins,
  refreshCloudIdentityApplications,
  revokeAdmin,
  submitAdminApplication,
} from '../../services/admin'

interface AdminMemberCard {
  id: string
  name: string
  avatar: string
  identity: string
}

Page({
  data: {
    role: 'member',
    roleLabel: '普通成员',
    roleNote: '可提交资料修订，也可以申请成为谱务管理员',
    isOwner: false,
    ownerConfigured: false,
    currentOpenid: '',
    accountError: '',
    canReview: false,
    verifiedMember: null as FamilyMember | null,
    verifiedAvatar: '',
    currentApplication: null as AdminApplication | null,
    pendingApplications: [] as AdminApplication[],
    authorizedAdmins: [] as AdminMemberCard[],
    pendingChanges: [] as MemberChangeRequest[],
    pendingIdentities: [] as IdentityApplication[],
    myRequests: [] as MemberChangeRequest[],
    reviewingIdentityId: '',
  },

  async onShow() {
    await refreshAccountRole()
    await refreshFamilyDataFromCloud()
    await refreshCloudAdmins()
    await refreshCloudIdentityApplications()
    this.refreshCenter()
  },

  refreshCenter() {
    const verifiedId = getVerifiedMemberId()
    const member = verifiedId ? getResolvedMemberById(verifiedId) : undefined
    const role = getCurrentAdminRole()
    const applications = getAdminApplications()
    const requests = getMemberChangeRequests()
    const identityApplications = getIdentityApplications()
    const isOwner = role === 'owner'
    const canReview = isOwner || role === 'admin'
    const roleLabel = isOwner ? '唯一谱主' : role === 'admin' ? '谱务管理员' : '普通成员'
    const roleNote = isOwner
      ? '只有谱主可以授权或撤销管理员；管理员不能继续授权他人'
      : role === 'admin'
        ? '可审核成员资料修订；管理员授权仍由唯一谱主负责'
        : '可提交资料修订，也可以申请成为谱务管理员'
    const authorizedAdmins = getAdminMembers().map((id) => getResolvedMemberById(id)).filter((item): item is FamilyMember => Boolean(item)).map((item) => ({
      id: item.id,
      name: item.name,
      avatar: item.name.slice(1, 2),
      identity: `${item.branch} · 第${item.generation}世`,
    }))

    this.setData({
      role,
      roleLabel,
      roleNote,
      isOwner,
      ownerConfigured: isOwnerAccountConfigured(),
      currentOpenid: getCurrentAccountOpenid(),
      accountError: getAccountRoleError(),
      canReview,
      verifiedMember: member || null,
      verifiedAvatar: member ? member.name.slice(1, 2) : '',
      currentApplication: applications.find((item) => item.applicantMemberId === verifiedId && item.status === 'pending') || null,
      pendingApplications: applications.filter((item) => item.status === 'pending'),
      authorizedAdmins,
      pendingChanges: requests.filter((item) => item.status === 'pending'),
      pendingIdentities: identityApplications.filter((item) => item.status === 'pending'),
      myRequests: member ? requests.filter((item) => item.submitterMemberId === member.id) : [],
    })
  },

  goVerify() {
    wx.navigateBack({
      fail: () => wx.switchTab({ url: '/pages/profile/profile' }),
    })
  },

  applyAdmin() {
    const member = this.data.verifiedMember
    if (!member) {
      wx.showModal({ title: '请先认证身份', content: '管理员申请必须绑定已核验的族人身份。', showCancel: false })
      return
    }
    if (this.data.currentApplication) {
      wx.showToast({ title: '申请正在等待谱主审核', icon: 'none' })
      return
    }
    wx.showModal({
      title: '申请成为管理员',
      editable: true,
      placeholderText: '请说明可协助的谱系资料或时间',
      confirmText: '提交申请',
      success: (result) => {
        if (!result.confirm) return
        const reason = (result.content || '').trim()
        if (!reason) {
          wx.showToast({ title: '请填写申请说明', icon: 'none' })
          return
        }
        submitAdminApplication(member, reason)
        this.refreshCenter()
        wx.showToast({ title: '申请已提交', icon: 'success' })
      },
    })
  },

  reviewApplication(event: WechatMiniprogram.TouchEvent) {
    const id = event.currentTarget.dataset.id as string
    const action = event.currentTarget.dataset.action as 'approved' | 'rejected'
    const target = this.data.pendingApplications.find((item) => item.id === id)
    if (!target) return
    wx.showModal({
      title: action === 'approved' ? '授权为管理员' : '驳回管理员申请',
      content: action === 'approved'
        ? `确认授权“${target.applicantName}”审核成员资料？对方不能授权其他管理员。`
        : `确认驳回“${target.applicantName}”的管理员申请？`,
      confirmText: action === 'approved' ? '确认授权' : '确认驳回',
      success: async (result) => {
        if (!result.confirm) return
        const success = await reviewAdminApplication(id, action)
        wx.showToast({ title: success ? (action === 'approved' ? '已授权' : '已驳回') : '仅谱主可操作', icon: 'none' })
        this.refreshCenter()
      },
    })
  },

  removeAdmin(event: WechatMiniprogram.TouchEvent) {
    const id = event.currentTarget.dataset.id as string
    const target = this.data.authorizedAdmins.find((item) => item.id === id)
    if (!target) return
    wx.showModal({
      title: '撤销管理员',
      content: `确认撤销“${target.name}”的谱务管理员权限？`,
      confirmText: '确认撤销',
      success: async (result) => {
        if (!result.confirm) return
        const success = await revokeAdmin(id)
        wx.showToast({ title: success ? '权限已撤销' : '仅谱主可操作', icon: 'none' })
        this.refreshCenter()
      },
    })
  },

  reviewChange(event: WechatMiniprogram.TouchEvent) {
    const id = event.currentTarget.dataset.id as string
    const action = event.currentTarget.dataset.action as 'approved' | 'rejected'
    const target = this.data.pendingChanges.find((item) => item.id === id)
    if (!target) return
    const reviewer = this.data.verifiedMember ? this.data.verifiedMember.name : '唯一谱主'
    wx.showModal({
      title: action === 'approved' ? '通过资料修订' : '驳回资料修订',
      content: action === 'approved'
        ? `通过后，“${target.memberName}”的${target.fieldLabel}将更新为提交内容。`
        : `确认驳回“${target.memberName}”的${target.fieldLabel}修订？`,
      confirmText: action === 'approved' ? '确认通过' : '确认驳回',
      success: (result) => {
        if (!result.confirm) return
        const success = reviewMemberChangeRequest(id, action, reviewer)
        wx.showToast({ title: success ? (action === 'approved' ? '资料已更新' : '修订已驳回') : '没有审核权限', icon: 'none' })
        this.refreshCenter()
      },
    })
  },

  reviewIdentity(event: WechatMiniprogram.TouchEvent) {
    const id = event.currentTarget.dataset.id as string
    const action = event.currentTarget.dataset.action as 'approved' | 'rejected'
    const target = this.data.pendingIdentities.find((item) => item.id === id)
    if (!target) return
    const identityName = target.targetMemberName || target.applicantName
    const isEdit = target.type === 'edit'
    wx.showModal({
      title: action === 'approved'
        ? (isEdit ? '通过身份资料修改' : '通过身份认证')
        : (isEdit ? '驳回身份资料修改' : '驳回身份认证'),
      content: action === 'approved'
        ? (isEdit
          ? `确认通过“${identityName}”提交的身份资料修改？通过后，所列变更将正式写入族谱。`
          : `确认核验通过“${identityName}”的身份申请？通过后将绑定身份并开放族谱详细资料。`)
        : `确认驳回“${identityName}”的${isEdit ? '身份资料修改' : '身份申请'}？`,
      confirmText: action === 'approved' ? '确认通过' : '确认驳回',
      success: async (result) => {
        if (!result.confirm) return
        this.setData({ reviewingIdentityId: id })
        try {
          const success = await reviewIdentityApplication(id, action)
          const approvedText = isEdit ? '身份资料已更新' : '身份已绑定'
          wx.showToast({ title: success ? (action === 'approved' ? approvedText : '申请已驳回') : '没有审核权限', icon: 'none' })
          await refreshFamilyDataFromCloud()
          await refreshCloudIdentityApplications()
          this.refreshCenter()
        } catch (error) {
          const message = error && (error as { message?: string }).message
            ? (error as { message: string }).message
            : String(error)
          wx.showModal({ title: '审核失败', content: message, showCancel: false })
        } finally {
          this.setData({ reviewingIdentityId: '' })
        }
      },
    })
  },

  openMember(event: WechatMiniprogram.TouchEvent) {
    wx.navigateTo({ url: `/pages/member-detail/member-detail?id=${event.currentTarget.dataset.id}` })
  },

  openMembers() {
    wx.switchTab({ url: '/pages/members/members' })
  },
})

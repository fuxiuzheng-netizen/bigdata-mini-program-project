import { familyArticles, generationPoem } from '../../data/family'

const articleBodies: Record<string, string[]> = {
  origin: [
    '族谱之作，在于记先人、联宗亲、启后世。今日以数字之法续写青谱，不求辞藻繁盛，惟愿所记有据、所叙有情。',
    '本演示谱系以临川为共同原乡，部分族人留居赣地，部分后迁闽中，子孙又散居沪、粤、京等地。人物均为虚构，待正式修谱时逐条考证替换。',
  ],
  migration: [
    '一九六〇年代前后，部分族人因工作迁往闽北。最初的往来靠家书，信封上的旧地址，后来成为寻找迁徙足迹的重要线索。',
    '进入新世纪，族人散居更广。青谱将以出生地、迁居地与现居地区三类资料，逐步绘出家族迁徙图。',
  ],
  rules: [
    '敬宗，不是拘于旧礼，而是懂得来处；睦族，不是回避分歧，而是以善意相待。修身立德，落实在诚实、勤勉与担当；诗礼传家，则是让每一代人都保有学习与温情。',
    '家训将以短句、家书和真实故事共同呈现，让年轻族人读得懂、记得住、愿意做。',
  ],
  names: [
    '示例字辈为“承、德、泽、绵、世、远”。一个字标明一代人的位置，也把家族对品德、福泽与长久传承的期待写进姓名。',
    '正式录入时，字辈与世次将分开保存，以兼容未按字辈取名、女性成员和上代资料缺失的实际情况。',
  ],
}

const allArticles = familyArticles.map((article) => ({ ...article, body: articleBodies[article.id] }))
const categoryMap: Record<string, string> = {
  源流: '傅氏源流',
  迁徙: '迁徙纪事',
  家训: '家训家风',
  字辈: '字辈谱',
}

Page({
  data: {
    categories: ['全部', '源流', '迁徙', '家训', '字辈'],
    activeCategory: '全部',
    articles: allArticles,
    expandedId: 'origin',
    generationPoem,
    heritageTopics: [
      { category: '迁徙', mark: '迁', title: '迁徙地图', sub: '从临川到闽粤' },
      { category: '字辈', mark: '字', title: '字辈长卷', sub: '承德泽绵，世远流长' },
      { category: '家训', mark: '训', title: '家训十则', sub: '诗礼传家的日用篇' },
    ],
    timeline: [
      { year: '1912', title: '示例始祖出生', text: '傅承岳生于临川，谱系由此展开。' },
      { year: '1965', title: '族人迁居闽地', text: '因工作与生活迁往福建，逐渐形成新的居住脉络。' },
      { year: '1998', title: '旧谱资料重整', text: '照片、家书与成员名录开始集中保存。' },
      { year: '2026', title: '傅庭知源始建', text: '以数字方式续写家族共同记忆。' },
    ],
  },

  onShow() {
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({ selected: 3 })
    }
  },

  chooseCategory(event: WechatMiniprogram.TouchEvent) {
    const category = event.currentTarget.dataset.category as string
    const articles = category === '全部' ? allArticles : allArticles.filter((article) => article.category === categoryMap[category])
    this.setData({ activeCategory: category, articles, expandedId: articles.length ? articles[0].id : '' })
  },

  toggleArticle(event: WechatMiniprogram.TouchEvent) {
    const id = event.currentTarget.dataset.id as string
    this.setData({ expandedId: this.data.expandedId === id ? '' : id })
  },

  shareArticle(event: WechatMiniprogram.TouchEvent) {
    const id = event.currentTarget.dataset.id as string
    const article = familyArticles.find((item) => item.id === id)
    wx.showToast({ title: article ? `可分享《${article.title}》` : '分享文章', icon: 'none' })
  },
})

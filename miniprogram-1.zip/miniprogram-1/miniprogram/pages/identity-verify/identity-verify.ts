import { FamilyMember, getResolvedFamilyMembers, getResolvedMemberById, refreshFamilyDataFromCloud } from '../../data/family'
import {
  IdentityApplication,
  getAccountRoleError,
  getCurrentIdentityApplication,
  getCurrentIdentityEditApplication,
  getVerifiedMemberId,
  refreshAccountRole,
  refreshMyIdentityApplications,
  submitExistingIdentityApplication,
  submitIdentityEditApplication,
  submitNewIdentityApplication,
} from '../../services/admin'

interface IdentityCandidate extends FamilyMember {
  avatar: string
}

function errorText(error: unknown): string {
  if (error && typeof error === 'object') {
    const value = error as { errMsg?: string; message?: string }
    return value.message || value.errMsg || '云端提交失败，请稍后重试'
  }
  return String(error || '云端提交失败，请稍后重试')
}

Page({
  data: {
    mode: 'existing' as 'existing' | 'new',
    keyword: '',
    candidates: [] as IdentityCandidate[],
    selectedMember: null as FamilyMember | null,
    currentApplication: null as IdentityApplication | null,
    editApplication: null as IdentityApplication | null,
    accountError: '',
    loadingAccount: false,
    verified: false,
    verifiedMember: null as FamilyMember | null,
    editing: false,
    submitting: false,
    applicantName: '',
    note: '',
    gender: '男' as '男' | '女',
    birthYear: '',
    region: '',
    generation: '',
    generationName: '',
    editName: '',
    editGender: '男' as '男' | '女',
    editBirthYear: '',
    editRegion: '',
    editGeneration: '',
    editGenerationName: '',
    editBranch: '',
    editNote: '',
  },

  async onShow() {
    await refreshAccountRole()
    await refreshMyIdentityApplications()
    await refreshFamilyDataFromCloud()
    this.refreshState()
  },

  refreshState() {
    const verifiedId = getVerifiedMemberId()
    const verifiedMember = verifiedId ? getResolvedMemberById(verifiedId) : undefined
    const application = getCurrentIdentityApplication()
    this.setData({
      verified: Boolean(verifiedId),
      verifiedMember: verifiedMember || null,
      currentApplication: application || null,
      editApplication: verifiedId ? getCurrentIdentityEditApplication(verifiedId) || null : null,
      accountError: getAccountRoleError(),
      editing: false,
    })
    this.filterCandidates()
  },

  async retryAccount() {
    this.setData({ loadingAccount: true })
    try {
      await refreshAccountRole()
      await refreshMyIdentityApplications()
      await refreshFamilyDataFromCloud()
      this.refreshState()
      if (!getAccountRoleError()) wx.showToast({ title: getVerifiedMemberId() ? '身份已自动恢复' : '云端连接已恢复', icon: 'success' })
    } finally {
      this.setData({ loadingAccount: false })
    }
  },

  switchMode(event: WechatMiniprogram.TouchEvent) {
    if (this.data.currentApplication || this.data.verified) return
    this.setData({ mode: event.currentTarget.dataset.mode })
  },

  onKeyword(event: WechatMiniprogram.Input) {
    this.setData({ keyword: event.detail.value }, () => this.filterCandidates())
  },

  filterCandidates() {
    const keyword = this.data.keyword.trim().toLowerCase()
    const candidates = getResolvedFamilyMembers().filter((member) => {
      if (!keyword) return true
      return [member.name, member.generationName, member.region, member.branch].some((value) => value.toLowerCase().includes(keyword))
    }).slice(0, 80).map((member) => ({ ...member, avatar: member.name.slice(1, 2) }))
    this.setData({ candidates })
  },

  selectMember(event: WechatMiniprogram.TouchEvent) {
    const member = getResolvedFamilyMembers().find((item) => item.id === event.currentTarget.dataset.id)
    if (member) this.setData({ selectedMember: member, applicantName: member.name })
  },

  onInput(event: WechatMiniprogram.Input) {
    const field = event.currentTarget.dataset.field as string
    this.setData({ [field]: event.detail.value } as WechatMiniprogram.IAnyObject)
  },

  chooseGender(event: WechatMiniprogram.TouchEvent) {
    this.setData({ gender: event.currentTarget.dataset.gender })
  },

  startEdit() {
    const member = this.data.verifiedMember
    if (!member || this.data.editApplication) return
    this.setData({
      editing: true,
      editName: member.name,
      editGender: member.gender,
      editBirthYear: String(member.birthYear),
      editRegion: member.region,
      editGeneration: String(member.generation),
      editGenerationName: member.generationName,
      editBranch: member.branch,
      editNote: '',
    })
  },

  cancelEdit() {
    this.setData({ editing: false })
  },

  onEditInput(event: WechatMiniprogram.Input) {
    const field = event.currentTarget.dataset.field as string
    this.setData({ [field]: event.detail.value } as WechatMiniprogram.IAnyObject)
  },

  chooseEditGender(event: WechatMiniprogram.TouchEvent) {
    this.setData({ editGender: event.currentTarget.dataset.gender })
  },

  submitEdit() {
    const member = this.data.verifiedMember
    if (!member) return
    const name = this.data.editName.trim()
    const birthYear = Number(this.data.editBirthYear)
    const generation = Number(this.data.editGeneration)
    const region = this.data.editRegion.trim()
    const currentYear = new Date().getFullYear()
    if (!name || !region || !birthYear || !generation) {
      wx.showToast({ title: '请填写姓名、出生年、地区和世次', icon: 'none' })
      return
    }
    if (birthYear < 1800 || birthYear > currentYear) {
      wx.showToast({ title: '请填写正确的出生年份', icon: 'none' })
      return
    }
    if (generation < 1 || generation > 200) {
      wx.showToast({ title: '请填写正确的世次', icon: 'none' })
      return
    }
    const draft = {
      name,
      gender: this.data.editGender,
      birthYear,
      region,
      generation,
      generationName: this.data.editGenerationName.trim(),
      branch: this.data.editBranch.trim() || '排行待考',
    }
    wx.showModal({
      title: '提交身份资料修改',
      content: '修改提交后不会立即生效。管理员审核通过前，族谱仍显示当前资料。',
      confirmText: '提交审核',
      success: async (result) => {
        if (!result.confirm) return
        this.setData({ submitting: true })
        try {
          const application = await submitIdentityEditApplication(member, draft, this.data.editNote.trim())
          if (!application) {
            wx.showToast({ title: '身份资料没有变化', icon: 'none' })
            return
          }
          this.refreshState()
          wx.showToast({ title: '修改申请已提交', icon: 'success' })
        } catch (error) {
          wx.showModal({ title: '提交失败', content: errorText(error), showCancel: false })
        } finally {
          this.setData({ submitting: false })
        }
      },
    })
  },

  submitExisting() {
    const member = this.data.selectedMember
    const applicantName = this.data.applicantName.trim()
    if (!member) {
      wx.showToast({ title: '请先选择谱中身份', icon: 'none' })
      return
    }
    if (!applicantName) {
      wx.showToast({ title: '请填写申请人姓名', icon: 'none' })
      return
    }
    wx.showModal({
      title: '提交身份认证',
      content: `申请认证为“${member.name}”。管理员审核通过前不会绑定，也不能查看族人详细资料。`,
      confirmText: '提交审核',
      success: async (result) => {
        if (!result.confirm) return
        this.setData({ submitting: true })
        try {
          await submitExistingIdentityApplication(member, applicantName, this.data.note.trim())
          this.refreshState()
          wx.showToast({ title: '申请已提交', icon: 'success' })
        } catch (error) {
          wx.showModal({ title: '提交失败', content: errorText(error), showCancel: false })
        } finally {
          this.setData({ submitting: false })
        }
      },
    })
  },

  async submitNew() {
    const applicantName = this.data.applicantName.trim()
    const birthYear = Number(this.data.birthYear)
    const generation = Number(this.data.generation)
    if (!applicantName || !birthYear || !this.data.region.trim()) {
      wx.showToast({ title: '请填写姓名、出生年和地区', icon: 'none' })
      return
    }
    this.setData({ submitting: true })
    try {
      await submitNewIdentityApplication({
        applicantName,
        gender: this.data.gender,
        birthYear,
        region: this.data.region.trim(),
        generation: generation || 1,
        generationName: this.data.generationName.trim(),
        note: this.data.note.trim(),
      })
      this.refreshState()
      wx.showToast({ title: '新身份已提交审核', icon: 'success' })
    } catch (error) {
      wx.showModal({ title: '提交失败', content: errorText(error), showCancel: false })
    } finally {
      this.setData({ submitting: false })
    }
  },
})

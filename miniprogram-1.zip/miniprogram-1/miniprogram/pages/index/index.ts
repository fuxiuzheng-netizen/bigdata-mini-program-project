import { FamilyMember, familyArticles, familyMembers, getResolvedFamilyMembers, refreshFamilyDataFromCloud } from '../../data/family'
import { getAccountRoleError, getVerifiedMemberId, refreshAccountRole } from '../../services/admin'

const branchOverview = [
  { name: '长子', tone: 'long' },
  { name: '长女', tone: 'root' },
  { name: '次子', tone: 'second' },
  { name: '次女', tone: 'root' },
].map((branch) => {
  const count = familyMembers.filter((member) => member.branch === branch.name).length
  return { ...branch, count, percent: Math.round((count / familyMembers.length) * 100) }
})

function buildBranchOverview(members: FamilyMember[]) {
  return [
    { name: '长子', tone: 'long' },
    { name: '长女', tone: 'root' },
    { name: '次子', tone: 'second' },
    { name: '次女', tone: 'root' },
  ].map((branch) => {
    const count = members.filter((member) => member.branch === branch.name).length
    return { ...branch, count, percent: members.length ? Math.round((count / members.length) * 100) : 0 }
  })
}

function buildStats(members: FamilyMember[]) {
  return [
    { value: members.length, label: '已录族人' },
    { value: Math.max(...members.map((member) => member.generation), 0), label: '传承世代' },
    { value: new Set(members.map((member) => member.branch).filter(Boolean)).size, label: '排行类型' },
    { value: familyArticles.length, label: '族志篇章' },
  ]
}

Page({
  data: {
    stats: [
      { value: familyMembers.length, label: '已录族人' },
      { value: 5, label: '传承世代' },
      { value: 4, label: '排行类型' },
      { value: familyArticles.length, label: '族志篇章' },
    ],
    quickLinks: [
      { key: 'tree', title: '查族谱', sub: '循竹节，看世代', icon: '谱' },
      { key: 'members', title: '寻族人', sub: '按姓名与排行查找', icon: '寻' },
      { key: 'generation', title: '看字辈', sub: '承德泽绵，世远流长', icon: '字' },
      { key: 'rules', title: '读家训', sub: '敬宗睦族，诗礼传家', icon: '训' },
    ],
    lineageProgress: { percent: 80, completed: familyMembers.length, target: 40, pending: 8 },
    branchOverview,
    familyCalendar: [
      { id: 'spring', month: '四月', day: '清明', title: '春祭与谱系校录', meta: '线上共修 · 核对长辈资料' },
      { id: 'autumn', month: '八月', day: '十五', title: '中秋家族云聚', meta: '分享旧照片与家书故事' },
    ],
    recentMembers: familyMembers.slice(-4).reverse().map((member) => ({ ...member, avatar: member.name.slice(1, 2) })),
    notice: '当前为第一版演示数据。真实族谱启用后，在世族人的敏感信息将默认隐藏。',
    isVerified: false,
  },

  async onShow() {
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({ selected: 0 })
    }
    await refreshAccountRole()
    await refreshFamilyDataFromCloud()
    const members = getResolvedFamilyMembers()
    this.setData({
      stats: buildStats(members),
      lineageProgress: { ...this.data.lineageProgress, completed: members.length, percent: Math.min(100, Math.round((members.length / this.data.lineageProgress.target) * 100)) },
      branchOverview: buildBranchOverview(members),
      recentMembers: members.slice(-4).reverse().map((member) => ({ ...member, avatar: member.name.slice(1, 2) })),
      isVerified: Boolean(getVerifiedMemberId()),
    })
  },

  openQuickLink(event: WechatMiniprogram.TouchEvent) {
    const key = event.currentTarget.dataset.key as string
    if (key === 'tree') {
      wx.switchTab({ url: '/pages/tree/tree' })
      return
    }
    if (key === 'members') {
      wx.switchTab({ url: '/pages/members/members' })
      return
    }
    wx.switchTab({ url: '/pages/history/history' })
  },

  async openMember(event: WechatMiniprogram.TouchEvent) {
    await refreshAccountRole()
    if (!getVerifiedMemberId()) {
      const accountError = getAccountRoleError()
      wx.showModal({
        title: accountError ? '云端身份暂时未连接' : '请先认证身份',
        content: accountError ? '绑定记录仍保存在云端，恢复网络后会自动读取，不需要重新绑定。' : '管理员审核并绑定身份后，才能查看族人档案。',
        confirmText: accountError ? '去重新连接' : '去认证',
        success: (result) => {
          if (result.confirm) wx.switchTab({ url: '/pages/profile/profile' })
        },
      })
      return
    }
    const id = event.currentTarget.dataset.id as string
    wx.navigateTo({ url: `/pages/member-detail/member-detail?id=${id}` })
  },

  openHistory() {
    wx.switchTab({ url: '/pages/history/history' })
  },

  openBranch(event: WechatMiniprogram.TouchEvent) {
    const branch = event.currentTarget.dataset.branch as string
    wx.setStorageSync('fuqingpu_member_branch', branch)
    wx.switchTab({ url: '/pages/members/members' })
  },

  continueCompile() {
    wx.switchTab({ url: '/pages/profile/profile' })
  },

  openCalendar(event: WechatMiniprogram.TouchEvent) {
    const item = this.data.familyCalendar.find((calendar) => calendar.id === event.currentTarget.dataset.id)
    if (!item) return
    wx.showModal({
      title: item.title,
      content: `${item.month}${item.day} · ${item.meta}\n\n活动提醒与宗亲报名能力已预留，接入真实族谱后可由谱务管理员发布。`,
      showCancel: false,
      confirmText: '知道了',
    })
  },

  onShareAppMessage() {
    return {
      title: '傅庭知源 · 墨竹成谱，枝叶同源',
      path: '/pages/index/index',
    }
  },
})

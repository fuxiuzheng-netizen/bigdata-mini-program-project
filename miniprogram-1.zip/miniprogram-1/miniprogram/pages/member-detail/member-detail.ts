import {
  FamilyMember,
  getLifeStatus,
  getResolvedChildren,
  getResolvedFamilyMembers,
  getResolvedMemberById,
  getResolvedSpouses,
  refreshFamilyDataFromCloud,
} from '../../data/family'
import {
  editableFields,
  getAccountRoleError,
  getVerifiedMemberId,
  refreshAccountRole,
  submitMemberChangeRequest,
} from '../../services/admin'
import { getIdentityLabel, getRelationshipLabel } from '../../utils/relationship'

interface RelationCard {
  id: string
  name: string
  relation: string
  salutation: string
  addressLead: string
  meta: string
  avatar: string
}

function relationCard(member: FamilyMember, relation: string, viewerId: string, members: FamilyMember[]): RelationCard {
  const salutation = getRelationshipLabel(viewerId, member.id, members) || '同族宗亲'
  return {
    id: member.id,
    name: member.name,
    relation,
    salutation,
    addressLead: salutation === '本人' ? '这是' : '我应称呼',
    meta: `第${member.generation}世 · ${member.region}`,
    avatar: member.name.slice(1, 2),
  }
}

Page({
  data: {
    currentId: '',
    member: null as FamilyMember | null,
    avatar: '',
    lifeStatus: '',
    years: '',
    identityTag: '',
    relationTag: '',
    relations: [] as RelationCard[],
  },

  async onLoad(options: Record<string, string | undefined>) {
    await refreshAccountRole()
    if (!getVerifiedMemberId()) {
      const accountError = getAccountRoleError()
      wx.showModal({
        title: accountError ? '云端身份暂时未连接' : '无法查看族人档案',
        content: accountError ? '原绑定仍保存在云端，恢复网络后会自动恢复，不需要重新认证。' : '身份审核通过并绑定前，不能查看族人的生卒、籍居、人物小传和家庭关系。',
        confirmText: accountError ? '去重新连接' : '去认证',
        showCancel: false,
        success: () => wx.switchTab({ url: '/pages/profile/profile' }),
      })
      return
    }
    const id = options.id || 'f001'
    this.setData({ currentId: id })
    await refreshFamilyDataFromCloud()
    this.loadMember(id)
  },

  async onShow() {
    await refreshAccountRole()
    if (!getVerifiedMemberId()) return
    await refreshFamilyDataFromCloud()
    if (this.data.currentId) this.loadMember(this.data.currentId)
  },

  loadMember(id: string) {
    const member = getResolvedMemberById(id) || getResolvedMemberById('f001') as FamilyMember
    const members = getResolvedFamilyMembers()
    const viewerId = getVerifiedMemberId()
    const relations: RelationCard[] = []
    const father = member.fatherId ? getResolvedMemberById(member.fatherId) : undefined
    const mother = member.motherId ? getResolvedMemberById(member.motherId) : undefined
    if (father) relations.push(relationCard(father, '父亲', viewerId, members))
    if (mother) relations.push(relationCard(mother, '母亲', viewerId, members))
    getResolvedSpouses(member).forEach((spouse) => relations.push(relationCard(spouse, '配偶', viewerId, members)))
    getResolvedChildren(member.id).forEach((child) => relations.push(relationCard(child, child.gender === '男' ? '儿子' : '女儿', viewerId, members)))
    const relationship = getRelationshipLabel(viewerId, member.id, members)

    this.setData({
      currentId: member.id,
      member,
      avatar: member.name.slice(1, 2),
      lifeStatus: getLifeStatus(member),
      years: member.deathYear ? `${member.birthYear}—${member.deathYear}` : `${member.birthYear}—`,
      identityTag: getIdentityLabel(member, members),
      relationTag: relationship ? `我称呼：${relationship}` : '',
      relations,
    })
    wx.setNavigationBarTitle({ title: `${member.name} · 族人档案` })
  },

  openRelation(event: WechatMiniprogram.TouchEvent) {
    const id = event.currentTarget.dataset.id as string
    wx.redirectTo({ url: `/pages/member-detail/member-detail?id=${id}` })
  },

  locateInTree() {
    const member = this.data.member
    if (!member) return
    let targetId = member.id
    const isPrimaryNode = getResolvedFamilyMembers().some((item) => item.id === member.id && item.name.startsWith('傅'))
    if (!isPrimaryNode && member.spouseIds.length) targetId = member.spouseIds[0]
    wx.setStorageSync('fuqingpu_tree_focus', targetId)
    wx.switchTab({ url: '/pages/tree/tree' })
  },

  collectMember() {
    const member = this.data.member
    if (!member) return
    const collected = wx.getStorageSync<string[]>('fuqingpu_collected') || []
    if (!collected.includes(member.id)) {
      collected.push(member.id)
      wx.setStorageSync('fuqingpu_collected', collected)
    }
    wx.showToast({ title: '已收藏族人', icon: 'success' })
  },

  submitCorrection() {
    const member = this.data.member
    if (!member) return
    const verifiedId = getVerifiedMemberId()
    const submitter = verifiedId ? getResolvedMemberById(verifiedId) : undefined
    if (!submitter) {
      wx.showModal({
        title: '请先认证族人身份',
        content: '资料修订需要记录提交人。请先在“我的”页面选择并认证你在族谱中的身份。',
        confirmText: '去认证',
        success: (result) => {
          if (result.confirm) wx.switchTab({ url: '/pages/profile/profile' })
        },
      })
      return
    }

    wx.showActionSheet({
      itemList: editableFields.map((item) => item.label),
      success: (sheetResult) => {
        const field = editableFields[sheetResult.tapIndex]
        const currentValue = String(member[field.key])
        wx.showModal({
          title: `修订${field.label}`,
          content: currentValue,
          editable: true,
          placeholderText: `请输入新的${field.label}`,
          confirmText: '提交审核',
          success: (modalResult) => {
            if (!modalResult.confirm) return
            const value = (modalResult.content || '').trim()
            if (!value || value === currentValue) {
              wx.showToast({ title: value ? '内容没有变化' : '内容不能为空', icon: 'none' })
              return
            }
            submitMemberChangeRequest(member, field.key, value, submitter)
            wx.showToast({ title: '已提交谱务审核', icon: 'success' })
          },
        })
      },
    })
  },
})

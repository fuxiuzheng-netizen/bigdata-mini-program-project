const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV,
})

const db = cloud.database()
const COLLECTION = 'family_members'

function parsePayload(event) {
  if (event && typeof event.body === 'string') {
    try {
      return JSON.parse(event.body)
    } catch (error) {
      return {}
    }
  }
  return event || {}
}

function cleanMember(member) {
  member = member || {}
  return {
    id: String(member.id || ''),
    name: String(member.name || ''),
    gender: member.gender === '女' ? '女' : '男',
    generation: Number(member.generation || 1),
    generationName: String(member.generationName || ''),
    branch: String(member.branch || ''),
    birthYear: Number(member.birthYear || new Date().getFullYear()),
    deathYear: member.deathYear ? Number(member.deathYear) : undefined,
    fatherId: member.fatherId ? String(member.fatherId) : undefined,
    motherId: member.motherId ? String(member.motherId) : undefined,
    spouseIds: Array.isArray(member.spouseIds) ? member.spouseIds.map(function (id) { return String(id) }) : [],
    region: String(member.region || ''),
    role: member.role ? String(member.role) : undefined,
    courtesyName: member.courtesyName ? String(member.courtesyName) : undefined,
    bio: String(member.bio || ''),
    story: String(member.story || ''),
  }
}

function memberToData(member) {
  const data = {
    id: member.id,
    name: member.name,
    gender: member.gender,
    generation: member.generation,
    generationName: member.generationName,
    branch: member.branch,
    birthYear: member.birthYear,
    spouseIds: member.spouseIds,
    region: member.region,
    bio: member.bio,
    story: member.story,
    syncedAt: db.serverDate(),
  }
  // 云数据库不能写入 undefined；可选字段只在有值时保存。
  if (member.deathYear !== undefined) data.deathYear = member.deathYear
  if (member.fatherId !== undefined) data.fatherId = member.fatherId
  if (member.motherId !== undefined) data.motherId = member.motherId
  if (member.role !== undefined) data.role = member.role
  if (member.courtesyName !== undefined) data.courtesyName = member.courtesyName
  return data
}

async function syncFamilyMembers(event) {
  const payload = parsePayload(event)
  const expectedToken = process.env.SYNC_TOKEN || process.env.fu
  const headers = event && event.headers ? event.headers : {}
  const requestToken = payload.token || headers['x-sync-token'] || headers['X-Sync-Token']

  if (!expectedToken) {
    return { ok: false, code: 'MISSING_TOKEN', message: '请先给云函数配置环境变量 SYNC_TOKEN，或使用现有的 fu 环境变量。' }
  }
  if (requestToken !== expectedToken) {
    return { ok: false, code: 'UNAUTHORIZED', message: '同步口令不正确。' }
  }

  const collection = db.collection(COLLECTION)
  if (payload.action === 'pull') {
    const result = await collection.limit(1000).get()
    const members = result.data.map(function (doc) { return cleanMember(doc) }).filter(function (member) {
      return member.id && member.name
    })
    return { ok: true, collection: COLLECTION, members: members }
  }

  if (!Array.isArray(payload.members)) {
    return { ok: false, code: 'BAD_REQUEST', message: 'members 必须是数组。' }
  }

  const members = payload.members.map(function (member) { return cleanMember(member) }).filter(function (member) {
    return member.id && member.name
  })
  if (!members.length) {
    return { ok: false, code: 'EMPTY_DATA', message: '没有可同步的族人数据。' }
  }

  const existingResult = await collection.limit(1000).get()
  const existingById = {}
  existingResult.data.forEach(function (doc) {
    if (doc.id) existingById[doc.id] = doc._id
  })

  const incomingIds = {}
  let saved = 0
  let removed = 0

  for (let i = 0; i < members.length; i += 1) {
    const member = members[i]
    const data = memberToData(member)
    incomingIds[member.id] = true
    if (existingById[member.id]) {
      await collection.doc(existingById[member.id]).update({ data: data })
    } else {
      await collection.doc(member.id).set({ data: data })
    }
    saved += 1
  }

  for (let i = 0; i < existingResult.data.length; i += 1) {
    const doc = existingResult.data[i]
    if (doc.id && !incomingIds[doc.id]) {
      await collection.doc(doc._id).remove()
      removed += 1
    }
  }

  return { ok: true, collection: COLLECTION, saved: saved, removed: removed }
}

exports.main = async function (event, context) {
  try {
    return await syncFamilyMembers(event, context)
  } catch (error) {
    const message = error && error.message ? error.message : String(error)
    console.error('syncfamilymembers failed:', error && error.stack ? error.stack : message)
    return {
      ok: false,
      code: 'SYNC_FUNCTION_ERROR',
      message: message,
    }
  }
}

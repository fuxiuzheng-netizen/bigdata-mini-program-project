# 身份认证云端配置

`accountidentity` 同时负责账号角色、身份申请、本人身份资料修改及管理员审核。

部署前请在当前云环境中确认：

1. 已存在 `family_members` 数据集合。
2. 新建 `family_admins` 数据集合。
3. `family_admins` 权限设置为“所有用户不可读写”；小程序只能通过云函数访问。
4. `accountidentity` 云函数保留 `OWNER_OPENID` 环境变量。
5. 在微信开发者工具中右键 `cloudfunctions/accountidentity`，选择“上传并部署：云端安装依赖”。

`family_admins` 集合同时保存管理员账号、审核后的身份绑定和身份申请记录，请勿用数据管理器的族人同步功能覆盖或删除该集合。

身份审核通过后会按微信 OpenID 永久记录在 `family_admins` 中。用户下次进入小程序时会自动读取原绑定，不需要重新认证；只有更换微信账号、变更小程序 AppID/云环境，或管理员主动解除身份绑定时，才会失去原绑定关系。

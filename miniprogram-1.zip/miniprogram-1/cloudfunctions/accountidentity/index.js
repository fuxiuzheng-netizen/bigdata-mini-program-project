const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const db = cloud.database()
const ACCOUNTS_COLLECTION = 'family_admins'
const MEMBERS_COLLECTION = 'family_members'
const APPLICATION_RECORD_TYPE = 'identityApplication'
const ACCOUNT_RECORD_TYPE = 'account'
const IDENTITY_FIELDS = ['name', 'gender', 'birthYear', 'region', 'generation', 'generationName', 'branch']
const IDENTITY_LABELS = {
  name: '姓名',
  gender: '性别',
  birthYear: '出生年份',
  region: '籍居地区',
  generation: '世次',
  generationName: '字辈',
  branch: '排行',
}

function nowText() {
  const date = new Date(Date.now() + 8 * 60 * 60 * 1000)
  const pad = function (value) { return String(value).padStart(2, '0') }
  return `${date.getUTCFullYear()}-${pad(date.getUTCMonth() + 1)}-${pad(date.getUTCDate())} ${pad(date.getUTCHours())}:${pad(date.getUTCMinutes())}`
}

function text(value, maxLength) {
  return String(value == null ? '' : value).trim().slice(0, maxLength || 200)
}

function isAdminAccount(account) {
  return Boolean(account && (account.adminEnabled === true || account.enabled === true))
}

function getApprovedMemberId(account) {
  if (!account || account.identityApproved === false) return ''
  return String(account.identityMemberId || '')
}

function isMissingDocumentError(error) {
  const code = String(error && (error.errCode || error.code) || '')
  const message = String(error && error.message || error || '').toLowerCase()
  return code.includes('DOCUMENT_NOT_FOUND')
    || message.includes('document not exists')
    || message.includes('document does not exist')
    || message.includes('document_not_found')
    || message.includes('cannot find document')
}

async function getAccount(openid) {
  try {
    const result = await db.collection(ACCOUNTS_COLLECTION).doc(openid).get()
    const account = result.data || null
    return account && account.recordType !== APPLICATION_RECORD_TYPE ? account : null
  } catch (error) {
    if (isMissingDocumentError(error)) return null
    throw error
  }
}

async function saveAccount(openid, values) {
  const existing = await getAccount(openid)
  const existingData = Object.assign({}, existing || {})
  delete existingData._id
  const data = Object.assign({}, existingData, values || {}, {
    openid,
    recordType: ACCOUNT_RECORD_TYPE,
    updatedAt: db.serverDate(),
  })
  if (!existing) data.createdAt = db.serverDate()
  await db.collection(ACCOUNTS_COLLECTION).doc(openid).set({ data })
  return data
}

async function listRecords() {
  try {
    const records = []
    const pageSize = 100
    for (let offset = 0; offset < 10000; offset += pageSize) {
      const result = await db.collection(ACCOUNTS_COLLECTION).skip(offset).limit(pageSize).get()
      const page = result.data || []
      records.push.apply(records, page)
      if (page.length < pageSize) break
    }
    return records
  } catch (error) {
    const message = error && error.message ? error.message : String(error)
    if (message.includes('collection not exists') || message.includes('Table not exist')) return []
    throw error
  }
}

function findBoundAccount(records, memberId, exceptOpenid) {
  return records.find(function (item) {
    if (!item || item.recordType === APPLICATION_RECORD_TYPE) return false
    const recordOpenid = String(item.openid || item._id || '')
    return recordOpenid !== String(exceptOpenid || '')
      && getApprovedMemberId(item) === String(memberId || '')
  })
}

function memberIdForApplication(applicationId) {
  const suffix = String(applicationId || '').replace(/[^a-zA-Z0-9]/g, '').slice(-28)
  return `u${suffix}`
}

async function getMember(memberId) {
  if (!memberId) return null
  const collection = db.collection(MEMBERS_COLLECTION)
  try {
    const direct = await collection.doc(memberId).get()
    if (direct.data && String(direct.data.id || memberId) === memberId) {
      return { docId: direct.data._id || memberId, data: direct.data }
    }
  } catch (error) {
    // 数据管理器旧版本可能使用随机 _id，继续按业务 id 查询。
  }
  const result = await collection.where({ id: memberId }).limit(1).get()
  const member = result.data && result.data[0]
  return member ? { docId: member._id, data: member } : null
}

function normalizeFieldValue(field, value) {
  if (field === 'gender') {
    if (value !== '男' && value !== '女') throw new Error('性别只能选择男或女。')
    return value
  }
  if (field === 'birthYear') {
    const year = Number(value)
    const currentYear = new Date().getFullYear()
    if (!Number.isInteger(year) || year < 1800 || year > currentYear) throw new Error('出生年份不正确。')
    return year
  }
  if (field === 'generation') {
    const generation = Number(value)
    if (!Number.isInteger(generation) || generation < 1 || generation > 200) throw new Error('世次不正确。')
    return generation
  }
  const limits = { name: 30, region: 80, generationName: 20, branch: 30 }
  const normalized = text(value, limits[field] || 100)
  if ((field === 'name' || field === 'region') && !normalized) throw new Error(`${IDENTITY_LABELS[field]}不能为空。`)
  return normalized
}

function publicApplication(record) {
  return {
    id: String(record._id || record.id || ''),
    type: record.type,
    applicantOpenid: String(record.applicantOpenid || ''),
    targetMemberId: record.targetMemberId ? String(record.targetMemberId) : undefined,
    targetMemberName: record.targetMemberName ? String(record.targetMemberName) : undefined,
    applicantName: String(record.applicantName || ''),
    gender: record.gender,
    birthYear: record.birthYear,
    region: record.region,
    generation: record.generation,
    generationName: record.generationName,
    changes: Array.isArray(record.changes) ? record.changes : [],
    note: String(record.note || ''),
    submittedAt: String(record.submittedAt || ''),
    status: record.status || 'pending',
    approvedMemberId: record.approvedMemberId ? String(record.approvedMemberId) : undefined,
    reviewedAt: record.reviewedAt ? String(record.reviewedAt) : undefined,
  }
}

async function submitIdentityApplication(openid, event) {
  const draft = event && event.application ? event.application : {}
  const type = ['existing', 'new', 'edit'].includes(draft.type) ? draft.type : ''
  if (!type) return { ok: false, code: 'BAD_TYPE', message: '身份申请类型不正确。' }

  const records = await listRecords()
  const pending = records.find(function (item) {
    return item.recordType === APPLICATION_RECORD_TYPE && item.applicantOpenid === openid && item.status === 'pending'
  })
  if (pending) return { ok: true, application: publicApplication(pending), existed: true }

  const account = await getAccount(openid)
  const submittedAt = nowText()
  const applicationId = `identity-${Date.now()}-${Math.floor(Math.random() * 100000)}`
  const application = {
    recordType: APPLICATION_RECORD_TYPE,
    type,
    applicantOpenid: openid,
    applicantName: text(draft.applicantName, 30),
    note: text(draft.note, 500),
    submittedAt,
    status: 'pending',
    createdAt: db.serverDate(),
  }

  if (type === 'existing') {
    if (getApprovedMemberId(account)) {
      return { ok: false, code: 'ALREADY_BOUND', message: '当前账号已经绑定族人身份。' }
    }
    const targetMemberId = text(draft.targetMemberId, 80)
    const member = await getMember(targetMemberId)
    if (!member) return { ok: false, code: 'MEMBER_NOT_FOUND', message: '没有找到要认证的族人身份。' }
    if (findBoundAccount(records, targetMemberId, openid)) {
      return { ok: false, code: 'IDENTITY_TAKEN', message: '该族人身份已经绑定其他微信账号，请联系谱主核验。' }
    }
    application.targetMemberId = targetMemberId
    application.targetMemberName = String(member.data.name || '')
    if (!application.applicantName) application.applicantName = application.targetMemberName
  }

  if (type === 'new') {
    if (getApprovedMemberId(account)) {
      return { ok: false, code: 'ALREADY_BOUND', message: '当前账号已经绑定族人身份。' }
    }
    application.applicantName = text(draft.applicantName, 30)
    application.gender = normalizeFieldValue('gender', draft.gender)
    application.birthYear = normalizeFieldValue('birthYear', draft.birthYear)
    application.region = normalizeFieldValue('region', draft.region)
    application.generation = normalizeFieldValue('generation', draft.generation || 1)
    application.generationName = normalizeFieldValue('generationName', draft.generationName)
    if (!application.applicantName) return { ok: false, code: 'MISSING_NAME', message: '姓名不能为空。' }
  }

  if (type === 'edit') {
    const memberId = getApprovedMemberId(account)
    if (!memberId) return { ok: false, code: 'IDENTITY_REQUIRED', message: '只有已审核绑定的本人身份可以提交修改。' }
    const member = await getMember(memberId)
    if (!member) return { ok: false, code: 'MEMBER_NOT_FOUND', message: '当前绑定的族人资料不存在。' }
    application.targetMemberId = memberId
    application.targetMemberName = String(member.data.name || '')
    application.applicantName = String(member.data.name || '')
    const requestedChanges = Array.isArray(draft.changes) ? draft.changes : []
    const changes = []
    requestedChanges.forEach(function (change) {
      const field = text(change && change.field, 30)
      if (!IDENTITY_FIELDS.includes(field) || changes.some(function (item) { return item.field === field })) return
      const newValue = normalizeFieldValue(field, change.newValue)
      const oldValue = member.data[field] == null ? '' : member.data[field]
      if (String(oldValue) !== String(newValue)) {
        changes.push({
          field,
          label: IDENTITY_LABELS[field],
          oldValue: String(oldValue),
          newValue: String(newValue),
        })
      }
    })
    if (!changes.length) return { ok: false, code: 'NO_CHANGES', message: '身份资料没有变化。' }
    application.changes = changes
  }

  await db.collection(ACCOUNTS_COLLECTION).doc(applicationId).set({ data: application })
  return { ok: true, application: publicApplication(Object.assign({ _id: applicationId }, application)) }
}

async function reviewIdentityApplication(openid, event, isOwner, account) {
  if (!isOwner && !isAdminAccount(account)) {
    return { ok: false, code: 'ADMIN_ONLY', message: '只有谱主或管理员可以审核身份申请。' }
  }
  const applicationId = text(event.applicationId, 100)
  const status = event.status === 'approved' ? 'approved' : event.status === 'rejected' ? 'rejected' : ''
  if (!applicationId || !status) return { ok: false, code: 'BAD_REVIEW', message: '审核参数不正确。' }

  let application
  try {
    const result = await db.collection(ACCOUNTS_COLLECTION).doc(applicationId).get()
    application = result.data
  } catch (error) {
    return { ok: false, code: 'APPLICATION_NOT_FOUND', message: '没有找到该身份申请。' }
  }
  if (!application || application.recordType !== APPLICATION_RECORD_TYPE || application.status !== 'pending') {
    return { ok: false, code: 'APPLICATION_CLOSED', message: '该申请已经处理或不存在。' }
  }
  if (!['existing', 'new', 'edit'].includes(application.type)) {
    return { ok: false, code: 'BAD_TYPE', message: '该身份申请类型无效，不能审核。' }
  }
  if (!isOwner && application.applicantOpenid === openid) {
    return { ok: false, code: 'SELF_REVIEW_NOT_ALLOWED', message: '管理员不能审核自己提交的身份申请，请由谱主或其他管理员处理。' }
  }

  let approvedMemberId = ''
  if (status === 'approved') {
    if (application.type === 'edit') {
      const applicantAccount = await getAccount(application.applicantOpenid)
      if (getApprovedMemberId(applicantAccount) !== String(application.targetMemberId || '')) {
        return { ok: false, code: 'IDENTITY_BINDING_CHANGED', message: '申请人的身份绑定已经变化，请驳回后重新提交。' }
      }
      const member = await getMember(String(application.targetMemberId || ''))
      if (!member) return { ok: false, code: 'MEMBER_NOT_FOUND', message: '要修改的族人资料不存在。' }
      if (!Array.isArray(application.changes) || !application.changes.length) {
        return { ok: false, code: 'NO_CHANGES', message: '该身份修改申请没有有效变更。' }
      }
      const conflict = application.changes.find(function (change) {
        if (!IDENTITY_FIELDS.includes(change.field)) return false
        const currentValue = member.data[change.field] == null ? '' : member.data[change.field]
        const oldValue = String(change.oldValue == null ? '' : change.oldValue)
        const newValue = String(change.newValue == null ? '' : change.newValue)
        return String(currentValue) !== oldValue && String(currentValue) !== newValue
      })
      if (conflict) {
        return {
          ok: false,
          code: 'MEMBER_DATA_CHANGED',
          message: `${IDENTITY_LABELS[conflict.field] || '族人资料'}在审核期间已经变化，请驳回后让申请人重新提交。`,
        }
      }
      const patch = { syncedAt: db.serverDate() }
      ;(application.changes || []).forEach(function (change) {
        if (!IDENTITY_FIELDS.includes(change.field)) return
        patch[change.field] = normalizeFieldValue(change.field, change.newValue)
      })
      await db.collection(MEMBERS_COLLECTION).doc(member.docId).update({ data: patch })
      approvedMemberId = String(application.targetMemberId)
      const renamed = (application.changes || []).find(function (change) { return change.field === 'name' })
      if (renamed) {
        await saveAccount(application.applicantOpenid, {
          identityMemberName: String(renamed.newValue || ''),
        })
      }
    } else if (application.type === 'existing') {
      const applicantAccount = await getAccount(application.applicantOpenid)
      const currentMemberId = getApprovedMemberId(applicantAccount)
      if (currentMemberId && currentMemberId !== String(application.targetMemberId || '')) {
        return { ok: false, code: 'ALREADY_BOUND', message: '申请账号已经绑定其他族人身份。' }
      }
      const member = await getMember(String(application.targetMemberId || ''))
      if (!member) return { ok: false, code: 'MEMBER_NOT_FOUND', message: '要绑定的族人资料不存在。' }
      approvedMemberId = String(application.targetMemberId)
      const records = await listRecords()
      if (findBoundAccount(records, approvedMemberId, application.applicantOpenid)) {
        return { ok: false, code: 'IDENTITY_TAKEN', message: '该族人身份已经绑定其他微信账号，不能重复绑定。' }
      }
      await saveAccount(application.applicantOpenid, {
        identityMemberId: approvedMemberId,
        identityMemberName: String(member.data.name || ''),
        identityApproved: true,
        identityApprovedAt: db.serverDate(),
      })
    } else if (application.type === 'new') {
      approvedMemberId = memberIdForApplication(applicationId)
      const applicantAccount = await getAccount(application.applicantOpenid)
      const currentMemberId = getApprovedMemberId(applicantAccount)
      if (currentMemberId && currentMemberId !== approvedMemberId) {
        return { ok: false, code: 'ALREADY_BOUND', message: '申请账号已经绑定其他族人身份。' }
      }
      const memberData = {
        id: approvedMemberId,
        name: text(application.applicantName, 30),
        gender: normalizeFieldValue('gender', application.gender),
        generation: normalizeFieldValue('generation', application.generation || 1),
        generationName: normalizeFieldValue('generationName', application.generationName),
        branch: '排行待考',
        birthYear: normalizeFieldValue('birthYear', application.birthYear),
        spouseIds: [],
        region: normalizeFieldValue('region', application.region),
        bio: '新身份审核通过，人物资料待后续补充。',
        story: text(application.note, 500) || '家族故事待补充。',
        syncedAt: db.serverDate(),
      }
      const existingMember = await getMember(approvedMemberId)
      if (!existingMember) {
        await db.collection(MEMBERS_COLLECTION).doc(approvedMemberId).set({ data: memberData })
      }
      await saveAccount(application.applicantOpenid, {
        identityMemberId: approvedMemberId,
        identityMemberName: memberData.name,
        identityApproved: true,
        identityApprovedAt: db.serverDate(),
      })
    }
  }

  const reviewedAt = nowText()
  await db.collection(ACCOUNTS_COLLECTION).doc(applicationId).update({
    data: {
      status,
      approvedMemberId: approvedMemberId || application.approvedMemberId || '',
      reviewedAt,
      reviewerOpenid: openid,
      updatedAt: db.serverDate(),
    },
  })
  return {
    ok: true,
    approvedMemberId,
    application: publicApplication(Object.assign({}, application, {
      _id: applicationId,
      status,
      approvedMemberId,
      reviewedAt,
    })),
  }
}

exports.main = async function (event) {
  try {
    const context = cloud.getWXContext()
    const openid = context.OPENID
    const ownerOpenid = process.env.OWNER_OPENID || ''
    const action = event && event.action ? event.action : 'getRole'
    const isOwner = Boolean(ownerOpenid && openid === ownerOpenid)
    const account = await getAccount(openid)

    if (action === 'getRole') {
      return {
        ok: true,
        openid,
        ownerConfigured: Boolean(ownerOpenid),
        role: isOwner ? 'owner' : isAdminAccount(account) ? 'admin' : 'member',
        identityMemberId: getApprovedMemberId(account),
      }
    }

    if (action === 'submitIdentityApplication') {
      return await submitIdentityApplication(openid, event)
    }

    if (action === 'listMyIdentityApplications') {
      const records = await listRecords()
      const applications = records
        .filter(function (item) { return item.recordType === APPLICATION_RECORD_TYPE && item.applicantOpenid === openid })
        .sort(function (left, right) { return String(right.submittedAt || '').localeCompare(String(left.submittedAt || '')) })
        .map(publicApplication)
      return { ok: true, applications }
    }

    if (action === 'listIdentityApplications') {
      if (!isOwner && !isAdminAccount(account)) {
        return { ok: false, code: 'ADMIN_ONLY', message: '只有谱主或管理员可以查看身份申请。' }
      }
      const records = await listRecords()
      const applications = records
        .filter(function (item) { return item.recordType === APPLICATION_RECORD_TYPE })
        .sort(function (left, right) { return String(right.submittedAt || '').localeCompare(String(left.submittedAt || '')) })
        .map(publicApplication)
      return { ok: true, applications }
    }

    if (action === 'reviewIdentityApplication') {
      return await reviewIdentityApplication(openid, event, isOwner, account)
    }

    if (action === 'bindOwnerIdentity') {
      if (!isOwner) {
        return { ok: false, code: 'OWNER_ONLY', message: '只有唯一谱主可以迁移原有身份绑定。' }
      }
      const memberId = text(event.memberId, 80)
      const member = await getMember(memberId)
      if (!member) return { ok: false, code: 'MEMBER_NOT_FOUND', message: '原有绑定的族人资料不存在。' }
      const records = await listRecords()
      if (findBoundAccount(records, memberId, openid)) {
        return { ok: false, code: 'IDENTITY_TAKEN', message: '该族人身份已经绑定其他微信账号，不能迁移。' }
      }
      await saveAccount(openid, {
        identityMemberId: memberId,
        identityMemberName: String(member.data.name || ''),
        identityApproved: true,
        identityApprovedAt: db.serverDate(),
      })
      return { ok: true, identityMemberId: memberId }
    }

    if (!isOwner) {
      return { ok: false, code: 'OWNER_ONLY', message: '只有唯一谱主账号可以授权或撤销管理员。' }
    }

    if (action === 'listAdmins') {
      const records = await listRecords()
      const admins = records.filter(function (item) {
        return item.recordType !== APPLICATION_RECORD_TYPE && isAdminAccount(item)
      }).map(function (item) {
        return {
          openid: String(item.openid || item._id || ''),
          memberId: String(item.memberId || item.identityMemberId || ''),
          memberName: String(item.memberName || item.identityMemberName || ''),
          enabled: true,
        }
      })
      return { ok: true, admins }
    }

    const targetOpenid = text(event.targetOpenid, 128)
    if (!targetOpenid) return { ok: false, code: 'MISSING_OPENID', message: '缺少被授权账号的 OpenID。' }
    if (targetOpenid === ownerOpenid) return { ok: false, code: 'OWNER_IMMUTABLE', message: '唯一谱主账号不能被修改。' }

    if (action === 'grantAdmin') {
      await saveAccount(targetOpenid, {
        adminEnabled: true,
        enabled: true,
        memberId: text(event.memberId, 80),
        memberName: text(event.memberName, 30),
        grantedAt: db.serverDate(),
        grantedBy: openid,
      })
      return { ok: true }
    }

    if (action === 'revokeAdmin') {
      await saveAccount(targetOpenid, {
        adminEnabled: false,
        enabled: false,
        revokedAt: db.serverDate(),
        revokedBy: openid,
      })
      return { ok: true }
    }

    return { ok: false, code: 'BAD_ACTION', message: '不支持的操作。' }
  } catch (error) {
    const message = error && error.message ? error.message : String(error)
    console.error('accountidentity failed:', error && error.stack ? error.stack : message)
    return { ok: false, code: 'ACCOUNT_IDENTITY_ERROR', message }
  }
}

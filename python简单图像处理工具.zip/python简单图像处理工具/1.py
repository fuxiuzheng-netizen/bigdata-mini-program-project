import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
from PIL import Image, ImageTk, ImageEnhance, ImageDraw
import cv2
import numpy as np


class ImageProcessorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("无敌至尊高冷付少人像图像处理工具")
        self.root.geometry("1300x750")
        self.root.configure(bg="#f8f9fa")

        self.style = ttk.Style()
        self.style.theme_use("clam")

        self.style.configure(
            "Accent.TButton",
            font=("Microsoft YaHei", 10),
            background="#e3f2fd",
            foreground="#1976d2",
            borderwidth=2,
            relief="raised",
            padding=(8, 6)
        )
        self.style.map(
            "Accent.TButton",
            background=[("active", "#bbdefb"), ("pressed", "#90caf9")],
            relief=[("pressed", "sunken")],
            foreground=[("active", "#0d47a1")]
        )

        self.style.configure("Title.TLabel", font=("", 11, "bold"), background="#f8f9fa", foreground="#2e7d32")
        self.style.configure("Normal.TLabel", background="#f8f9fa", foreground="#424242")
        self.style.configure("TScale", background="#f8f9fa", troughcolor="#e0e0e0")

        self.bg_image = None
        self.bg_tk = None

        try:
            self.bg_image = Image.open("6.png").convert("RGBA")
            print("✅ 成功加载背景图：6.png")
        except Exception as e:
            print(f"❌ 加载失败：6.png - {e}")
            self.bg_image = None

        # ====================== 修复：使用你的 1.jpg 作为按钮背景 ======================
        self.btn_img = None
        try:
            # 1. 读取你的图片（1.jpg）
            img = Image.open("1.jpg").convert("RGBA")
            # 2. 把白色背景转为透明（关键步骤，JPG不支持透明，这里手动处理）
            data = img.getdata()
            new_data = []
            for item in data:
                # 把接近白色的像素设为透明
                if item[0] > 245 and item[1] > 245 and item[2] > 245:
                    new_data.append((255,255,255,0))
                else:
                    new_data.append(item)
            img.putdata(new_data)
            # 3. 调整为按钮尺寸
            img = img.resize((130, 46), Image.Resampling.LANCZOS)
            self.btn_img = ImageTk.PhotoImage(img)
            print("✅ 成功加载按钮背景图：1.jpg")
        except Exception as e:
            print(f"❌ 加载按钮背景失败：{e}，将使用默认按钮")
            self.btn_img = None

        self.current_image = None
        self.original_image = None
        self.history = []
        self.cur_menu = None

        self.drawing = False
        self.points = []
        self.mask = None
        self.brush_size = 12
        self.eliminate_mode = False

        self.crop_mode = False
        self.crop_start = None
        self.crop_rect = None
        self.crop_confirm_btn = None
        self.crop_cancel_btn = None

        self.temp_slider = None
        self.vignette_slider = None
        self.grain_slider = None

        # ==========滑块独立快照==========
        self._temp_snapshot = None
        self._vignette_snapshot = None
        self._grain_snapshot = None

        self.main_frame = ttk.Frame(root, style="Main.TFrame")
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        self.style.configure("Main.TFrame", background="#f8f9fa")

        self.canvas = tk.Canvas(self.main_frame, bg="#ffffff", bd=2, relief="solid", highlightthickness=0)
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.canvas.bind("<Button-1>", self.start_drawing)
        self.canvas.bind("<B1-Motion>", self.draw)
        self.canvas.bind("<ButtonRelease-1>", self.stop_drawing)
        self.canvas.bind("<Configure>", self.on_canvas_resize)

        self.right_total = ttk.Frame(self.main_frame, width=320, style="Right.TFrame")
        self.right_total.pack(side=tk.RIGHT, fill=tk.Y, padx=(10, 0))
        self.right_total.pack_propagate(False)
        self.style.configure("Right.TFrame", background="#f8f9fa")

        self.menu_col = ttk.Frame(self.right_total, width=140, style="Menu.TFrame")
        self.menu_col.pack(side=tk.LEFT, fill=tk.Y)
        self.menu_col.pack_propagate(False)
        self.style.configure("Menu.TFrame", background="#f8f9fa")

        self.func_col = ttk.Frame(self.right_total, style="Func.TFrame")
        self.func_col.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        self.style.configure("Func.TFrame", background="#f8f9fa")

        self.init_menu()
        self.switch_menu("base_opt")

        # ========== 只在这里加：右下角 2.jpg 水印（大小+透明度） ==========
        self.watermark_img = None
        self.watermark_label = None
        try:
            wm = Image.open("2.jpg").convert("RGBA")
            wm = wm.resize((120, 120), Image.Resampling.LANCZOS)  # 大小：120x120
            # 透明度 40%
            wm.putalpha(int(255 * 0.4))
            self.watermark_img = ImageTk.PhotoImage(wm)
            self.watermark_label = tk.Label(self.root, image=self.watermark_img, bg="#f8f9fa")
            self.watermark_label.place(relx=1.0, rely=1.0, anchor="se", x=-15, y=-15)  # 右下角
        except Exception as e:
            print(f"❌ 水印 2.jpg 加载失败：{e}")

    # ====================== 左侧菜单按钮（使用你的图片，一个按钮都不少） ======================
    def init_menu(self):
        menu_list = [
            ("基础操作", "base_opt"),
            ("旋转与镜像", "rotate"),
            ("尺寸修改", "size"),
            ("精细图像调色", "img_base"),
            ("超清画质修复", "quality_fix"),
            ("精修人像美颜", "beauty"),
            ("专业胶片滤镜", "filter"),
            ("智能涂抹消除", "eliminate")
        ]
        ttk.Label(self.menu_col, text="功能分类", style="Title.TLabel").pack(pady=15)

        # 均匀间距，8个按钮全部保留
        for name, tag in menu_list:
            # 用tk.Button来承载图片，ttk.Button不支持image参数
            btn = tk.Button(
                self.menu_col,
                text=name,
                command=lambda t=tag: self.switch_menu(t),
                font=("Microsoft YaHei", 10, "bold"),
                fg="#1976d2",
                bg="#f8f9fa",
                bd=0,
                activebackground="#f8f9fa",
                activeforeground="#0d47a1",
                image=self.btn_img,
                compound="center"
            )
            btn.pack(pady=6, fill="x", padx=3)

    def switch_menu(self, tag):
        if self.cur_menu == tag:
            return
        self.cur_menu = tag
        self.eliminate_mode = False
        self.points = []
        self.mask = None
        self.exit_crop_mode()
        for widget in self.func_col.winfo_children():
            widget.destroy()

        if tag == "base_opt":
            self.build_base_opt()
        elif tag == "rotate":
            self.build_rotate()
        elif tag == "size":
            self.build_size()
        elif tag == "img_base":
            self.build_img_base()
        elif tag == "quality_fix":
            self.build_quality_fix()
        elif tag == "beauty":
            self.build_beauty()
        elif tag == "filter":
            self.build_filter()
        elif tag == "eliminate":
            self.build_eliminate()

    def build_base_opt(self):
        ttk.Label(self.func_col, text="基础操作面板", style="Title.TLabel").pack(pady=10)
        ttk.Button(self.func_col, text="载入本地图片", command=self.open_image, style="Accent.TButton").pack(pady=5, fill="x", padx=8)
        ttk.Button(self.func_col, text="导出保存图片", command=self.save_image, style="Accent.TButton").pack(pady=5, fill="x", padx=8)
        ttk.Button(self.func_col, text="撤销单次操作", command=self.undo, style="Accent.TButton").pack(pady=5, fill="x", padx=8)
        ttk.Button(self.func_col, text="一键复原原图", command=self.restore_original, style="Accent.TButton").pack(pady=5, fill="x", padx=8)
        ttk.Button(self.func_col, text="裁剪图片", command=self.start_crop_mode, style="Accent.TButton").pack(pady=5, fill="x", padx=8)

    def build_rotate(self):
        ttk.Label(self.func_col, text="旋转与镜像", style="Title.TLabel").pack(pady=10)
        ttk.Button(self.func_col, text="左转90°", command=self.rotate_left, style="Accent.TButton").pack(pady=3, fill="x", padx=8)
        ttk.Button(self.func_col, text="右转90°", command=self.rotate_right, style="Accent.TButton").pack(pady=3, fill="x", padx=8)
        ttk.Button(self.func_col, text="水平翻转", command=self.flip_horizontal, style="Accent.TButton").pack(pady=3, fill="x", padx=8)
        ttk.Button(self.func_col, text="垂直翻转", command=self.flip_vertical, style="Accent.TButton").pack(pady=3, fill="x", padx=8)

    def build_size(self):
        ttk.Label(self.func_col, text="尺寸修改", style="Title.TLabel").pack(pady=10)
        ttk.Button(self.func_col, text="自定义尺寸", command=self.resize_custom, style="Accent.TButton").pack(pady=3, fill="x", padx=8)
        ttk.Button(self.func_col, text="1:1 正方形", command=lambda: self.resize_preset(1, 1), style="Accent.TButton").pack(pady=3, fill="x", padx=8)
        ttk.Button(self.func_col, text="16:9 宽屏", command=lambda: self.resize_preset(16, 9), style="Accent.TButton").pack(pady=3, fill="x", padx=8)
        ttk.Button(self.func_col, text="4:3 标准", command=lambda: self.resize_preset(4, 3), style="Accent.TButton").pack(pady=3, fill="x", padx=8)
        ttk.Button(self.func_col, text="3:2 胶片", command=lambda: self.resize_preset(3, 2), style="Accent.TButton").pack(pady=3, fill="x", padx=8)

    def build_img_base(self):
        ttk.Label(self.func_col, text="精细图像调色", style="Title.TLabel").pack(pady=10)
        ttk.Button(self.func_col, text="黑白质感灰度", command=self.to_gray, style="Accent.TButton").pack(pady=4, fill="x", padx=8)
        ttk.Button(self.func_col, text="超清细节锐化", command=self.sharpen, style="Accent.TButton").pack(pady=4, fill="x", padx=8)
        ttk.Button(self.func_col, text="智能亮度", command=self.brighten, style="Accent.TButton").pack(pady=4, fill="x", padx=8)
        ttk.Button(self.func_col, text="层次对比度", command=self.contrast_up, style="Accent.TButton").pack(pady=4, fill="x", padx=8)
        ttk.Button(self.func_col, text="自然饱和度", command=self.saturate_up, style="Accent.TButton").pack(pady=4, fill="x", padx=8)

        ttk.Label(self.func_col, text="色温调节 (-100 冷 ~ +100 暖)", style="Normal.TLabel").pack(pady=2)
        self.temp_slider = ttk.Scale(
            self.func_col,
            from_=-100,
            to=100,
            value=0,
            command=self.adjust_temperature
        )
        self.temp_slider.pack(fill="x", padx=8, pady=2)
        # ========== 修复：绑定新的重置函数 ==========
        ttk.Button(self.func_col, text="重置色温", command=self.reset_temp, style="Accent.TButton").pack(pady=3, fill="x", padx=8)

        ttk.Label(self.func_col, text="暗角强度 (0 ~ 100)", style="Normal.TLabel").pack(pady=2)
        self.vignette_slider = ttk.Scale(
            self.func_col,
            from_=0,
            to=100,
            value=0,
            command=self.adjust_vignette
        )
        self.vignette_slider.pack(fill="x", padx=8, pady=2)
        # ========== 修复：绑定新的重置函数 ==========
        ttk.Button(self.func_col, text="重置暗角", command=self.reset_vignette, style="Accent.TButton").pack(pady=3, fill="x", padx=8)

        ttk.Button(self.func_col, text="暖调肤色色温", command=self.warm_temp, style="Accent.TButton").pack(pady=4, fill="x", padx=8)
        ttk.Button(self.func_col, text="冷调清冷色温", command=self.cool_temp, style="Accent.TButton").pack(pady=4, fill="x", padx=8)

    def build_quality_fix(self):
        ttk.Label(self.func_col, text="超清画质修复", style="Title.TLabel").pack(pady=10)
        ttk.Button(self.func_col, text="纯降噪修复", command=self.enhance_quality, style="Accent.TButton").pack(pady=5, fill="x", padx=8)
        ttk.Button(self.func_col, text="无损超分辨率放大", command=self.upscale, style="Accent.TButton").pack(pady=5, fill="x", padx=8)

    def build_beauty(self):
        ttk.Label(self.func_col, text="精修人像美颜", style="Title.TLabel").pack(pady=10)
        ttk.Button(self.func_col, text="SkinFiner专业磨皮", command=self.smooth_skin, style="Accent.TButton").pack(pady=4, fill="x", padx=8)
        ttk.Button(self.func_col, text="自然美白", command=self.whiten, style="Accent.TButton").pack(pady=4, fill="x", padx=8)
        ttk.Button(self.func_col, text="自然瘦脸", command=self.beauty_face_slim, style="Accent.TButton").pack(pady=4, fill="x", padx=8)
        ttk.Button(self.func_col, text="自然大眼", command=self.enlarge_eyes, style="Accent.TButton").pack(pady=4, fill="x", padx=8)
        ttk.Button(self.func_col, text="全套精修一键美颜", command=self.full_auto_beauty, style="Accent.TButton").pack(pady=4, fill="x", padx=8)

    def build_filter(self):
        ttk.Label(self.func_col, text="专业胶片滤镜", style="Title.TLabel").pack(pady=10)
        ttk.Button(self.func_col, text="日系清新通透滤镜", command=self.filter_jp, style="Accent.TButton").pack(pady=3, fill="x", padx=8)
        ttk.Button(self.func_col, text="复古胶片怀旧滤镜", command=self.filter_vintage, style="Accent.TButton").pack(pady=3, fill="x", padx=8)
        ttk.Button(self.func_col, text="高级黑白艺术滤镜", command=self.filter_bw, style="Accent.TButton").pack(pady=3, fill="x", padx=8)
        ttk.Button(self.func_col, text="冷调ins高级滤镜", command=self.filter_cold, style="Accent.TButton").pack(pady=3, fill="x", padx=8)
        ttk.Button(self.func_col, text="暖调氛围感滤镜", command=self.filter_warm, style="Accent.TButton").pack(pady=3, fill="x", padx=8)

        ttk.Label(self.func_col, text="胶片颗粒强度 (0 ~ 50)", style="Normal.TLabel").pack(pady=2)
        self.grain_slider = ttk.Scale(
            self.func_col,
            from_=0,
            to=50,
            value=0,
            command=self.add_grain
        )
        self.grain_slider.pack(fill="x", padx=8, pady=2)
        # ========== 修复：绑定新的重置函数 ==========
        ttk.Button(self.func_col, text="重置颗粒", command=self.reset_grain, style="Accent.TButton").pack(pady=3, fill="x", padx=8)

    def build_eliminate(self):
        ttk.Label(self.func_col, text="智能涂抹消除", style="Title.TLabel").pack(pady=10)
        ttk.Label(self.func_col, text="画笔粗细调节", style="Normal.TLabel").pack(pady=2)
        self.brush_slider = ttk.Scale(
            self.func_col,
            from_=5,
            to=30,
            value=self.brush_size,
            command=lambda v: setattr(self, 'brush_size', int(float(v)))
        )
        self.brush_slider.pack(fill="x", padx=8, pady=2)
        self.eliminate_btn = ttk.Button(
            self.func_col,
            text="开启涂抹编辑模式",
            command=self.toggle_eliminate,
            style="Accent.TButton"
        )
        self.eliminate_btn.pack(pady=8, fill="x", padx=8)
        ttk.Button(self.func_col, text="智能填充消除", command=self.run_eliminate, style="Accent.TButton").pack(pady=5, fill="x", padx=8)
        ttk.Button(self.func_col, text="清空当前涂抹轨迹", command=self.clear_drawing, style="Accent.TButton").pack(pady=5, fill="x", padx=8)
        tips = "开启模式后鼠标涂抹瑕疵，自动融合背景纹理"
        ttk.Label(self.func_col, text=tips, wraplength=160, style="Normal.TLabel").pack(pady=10, padx=8)

    # ========== 高级修复：重置色温 ==========
    def reset_temp(self):
        if self._temp_snapshot is not None:
            self.current_image = self._temp_snapshot.copy()
        self.temp_slider.set(0)
        self._temp_snapshot = None
        self.update_canvas()

    # ========== 高级修复：重置暗角 ==========
    def reset_vignette(self):
        if self._vignette_snapshot is not None:
            self.current_image = self._vignette_snapshot.copy()
        self.vignette_slider.set(0)
        self._vignette_snapshot = None
        self.update_canvas()

    # ========== 高级修复：重置颗粒 ==========
    def reset_grain(self):
        if self._grain_snapshot is not None:
            self.current_image = self._grain_snapshot.copy()
        self.grain_slider.set(0)
        self._grain_snapshot = None
        self.update_canvas()

    # ========== 高级修复：色温调节（独立快照） ==========
    def adjust_temperature(self, value):
        if not self.current_image or not self.original_image:
            return
        if self._temp_snapshot is None:
            self._temp_snapshot = self.current_image.copy()
        temp = float(value)
        img = np.array(self._temp_snapshot, dtype=np.float32)

        if temp > 0:
            img[:, :, 0] = np.clip(img[:, :, 0] + temp * 0.8, 0, 255)
            img[:, :, 2] = np.clip(img[:, :, 2] - temp * 0.6, 0, 255)
        else:
            img[:, :, 0] = np.clip(img[:, :, 0] + temp * 0.6, 0, 255)
            img[:, :, 2] = np.clip(img[:, :, 2] - temp * 0.8, 0, 255)

        self.current_image = Image.fromarray(img.astype(np.uint8))
        self.update_canvas()

    # ========== 高级修复：暗角调节（独立快照） ==========
    def adjust_vignette(self, value):
        if not self.current_image or not self.original_image:
            return
        if self._vignette_snapshot is None:
            self._vignette_snapshot = self.current_image.copy()
        strength = float(value) / 100.0
        img = np.array(self._vignette_snapshot, dtype=np.float32) / 255.0
        h, w = img.shape[:2]

        x = np.linspace(-1, 1, w)
        y = np.linspace(-1, 1, h)
        xx, yy = np.meshgrid(x, y)
        distance = np.sqrt(xx ** 2 + yy ** 2)
        mask = 1 - distance * strength

        for i in range(3):
            img[:, :, i] *= mask

        img = np.clip(img * 255, 0, 255).astype(np.uint8)
        self.current_image = Image.fromarray(img)
        self.update_canvas()

    # ========== 高级修复：颗粒调节（独立快照） ==========
    def add_grain(self, value):
        if not self.current_image:
            return
        if self._grain_snapshot is None:
            self._grain_snapshot = self.current_image.copy()
        strength = int(float(value))
        if strength == 0:
            self.current_image = self._grain_snapshot.copy()
            self.update_canvas()
            return

        img = np.array(self._grain_snapshot, dtype=np.int16)
        h, w, c = img.shape

        noise = np.random.normal(0, strength, (h, w, c))
        img_with_grain = img + noise
        img_with_grain = np.clip(img_with_grain, 0, 255).astype(np.uint8)

        self.current_image = Image.fromarray(img_with_grain)
        self.update_canvas()

    def draw_background_decor(self):
        self.canvas.delete("decor")
        if not self.bg_image:
            return

        cw = self.canvas.winfo_width()
        ch = self.canvas.winfo_height()
        if cw < 50 or ch < 50:
            return

        img = self.bg_image.resize((cw, ch), Image.Resampling.LANCZOS)
        img.putalpha(int(255 * 0.20))

        self.bg_tk = ImageTk.PhotoImage(img)
        self.canvas.create_image(0, 0, image=self.bg_tk, anchor=tk.NW, tag="decor")

    def on_canvas_resize(self, event):
        self.draw_background_decor()

    def update_canvas(self, img=None):
        if img is None: img = self.current_image
        self.canvas.delete("all")
        self.draw_background_decor()
        if not img: return
        w, h = img.size
        cw, ch = self.canvas.winfo_width(), self.canvas.winfo_height()
        scale = min(cw / w, ch / h) if cw > 0 and ch > 0 else 1
        nw, nh = int(w * scale), int(h * scale)
        self.img_offset_x = (cw - nw) // 2
        self.img_offset_y = (ch - nh) // 2
        self.img_scale = scale
        resize_img = img.resize((nw, nh), Image.Resampling.LANCZOS)
        self.tk_img = ImageTk.PhotoImage(resize_img)
        self.canvas.create_image(cw // 2, ch // 2, image=self.tk_img)

    def start_crop_mode(self):
        if not self.current_image:
            messagebox.showwarning("提示", "请先载入图片文件")
            return
        self.crop_mode = True
        self.eliminate_mode = False
        self.crop_start = None
        self.crop_rect = None

        self.canvas.unbind("<Button-1>")
        self.canvas.unbind("<B1-Motion>")
        self.canvas.unbind("<ButtonRelease-1>")
        self.canvas.bind("<Button-1>", self.crop_on_press)
        self.canvas.bind("<B1-Motion>", self.crop_on_drag)
        self.canvas.bind("<ButtonRelease-1>", self.crop_on_release)

        self.crop_confirm_btn = ttk.Button(
            self.func_col,
            text="确认裁剪",
            command=self.confirm_crop,
            style="Accent.TButton"
        )
        self.crop_confirm_btn.pack(pady=3, fill="x", padx=8)
        self.crop_cancel_btn = ttk.Button(
            self.func_col,
            text="取消裁剪",
            command=self.exit_crop_mode,
            style="Accent.TButton"
        )
        self.crop_cancel_btn.pack(pady=3, fill="x", padx=8)

        messagebox.showinfo("裁剪模式", "拖动鼠标选择裁剪区域，然后点击确认裁剪")

    def crop_on_press(self, event):
        self.crop_start = (event.x, event.y)
        if self.crop_rect:
            self.canvas.delete(self.crop_rect)

    def crop_on_drag(self, event):
        if not self.crop_start:
            return
        x1, y1 = self.crop_start
        x2, y2 = event.x, event.y
        if self.crop_rect:
            self.canvas.delete(self.crop_rect)
        self.crop_rect = self.canvas.create_rectangle(
            x1, y1, x2, y2,
            outline="#ff3333",
            width=2,
            dash=(5, 5),
            fill="#ff3333",
            stipple="gray50"
        )

    def crop_on_release(self, event):
        pass

    def confirm_crop(self):
        if not self.crop_rect:
            messagebox.showwarning("提示", "请先拖动鼠标选择裁剪区域")
            return

        x1, y1, x2, y2 = self.canvas.coords(self.crop_rect)

        orig_x1 = int((x1 - self.img_offset_x) / self.img_scale)
        orig_y1 = int((y1 - self.img_offset_y) / self.img_scale)
        orig_x2 = int((x2 - self.img_offset_x) / self.img_scale)
        orig_y2 = int((y2 - self.img_offset_y) / self.img_scale)

        orig_x1 = max(0, orig_x1)
        orig_y1 = max(0, orig_y1)
        orig_x2 = min(self.current_image.width, orig_x2)
        orig_y2 = min(self.current_image.height, orig_y2)

        if orig_x1 >= orig_x2 or orig_y1 >= orig_y2:
            messagebox.showwarning("提示", "请选择有效的裁剪区域")
            return

        self.save_history()
        self.current_image = self.current_image.crop((orig_x1, orig_y1, orig_x2, orig_y2))
        self.update_canvas()
        self.exit_crop_mode()
        messagebox.showinfo("完成", "图片裁剪完毕")

    def exit_crop_mode(self):
        if not self.crop_mode:
            return
        self.crop_mode = False
        self.crop_start = None
        if self.crop_rect:
            self.canvas.delete(self.crop_rect)
            self.crop_rect = None

        self.canvas.unbind("<Button-1>")
        self.canvas.unbind("<B1-Motion>")
        self.canvas.unbind("<ButtonRelease-1>")
        self.canvas.bind("<Button-1>", self.start_drawing)
        self.canvas.bind("<B1-Motion>", self.draw)
        self.canvas.bind("<ButtonRelease-1>", self.stop_drawing)

        if self.crop_confirm_btn:
            self.crop_confirm_btn.destroy()
            self.crop_confirm_btn = None
        if self.crop_cancel_btn:
            self.crop_cancel_btn.destroy()
            self.crop_cancel_btn = None

        self.update_canvas()

    def rotate_left(self):
        if not self.current_image:
            messagebox.showwarning("提示", "请先载入图片")
            return
        self.save_history()
        self.current_image = self.current_image.rotate(90, expand=True)
        self.update_canvas()

    def rotate_right(self):
        if not self.current_image:
            messagebox.showwarning("提示", "请先载入图片")
            return
        self.save_history()
        self.current_image = self.current_image.rotate(-90, expand=True)
        self.update_canvas()

    def flip_horizontal(self):
        if not self.current_image:
            messagebox.showwarning("提示", "请先载入图片")
            return
        self.save_history()
        self.current_image = self.current_image.transpose(Image.FLIP_LEFT_RIGHT)
        self.update_canvas()

    def flip_vertical(self):
        if not self.current_image:
            messagebox.showwarning("提示", "请先载入图片")
            return
        self.save_history()
        self.current_image = self.current_image.transpose(Image.FLIP_TOP_BOTTOM)
        self.update_canvas()

    def resize_custom(self):
        if not self.current_image:
            messagebox.showwarning("提示", "请先载入图片")
            return

        w, h = self.current_image.size
        new_w = simpledialog.askinteger("自定义宽度", "输入新宽度(像素):", initialvalue=w, minvalue=1)
        if not new_w:
            return
        new_h = simpledialog.askinteger("自定义高度", "输入新高度(像素):", initialvalue=h, minvalue=1)
        if not new_h:
            return

        self.save_history()
        self.current_image = self.current_image.resize((new_w, new_h), Image.Resampling.LANCZOS)
        self.update_canvas()
        messagebox.showinfo("完成", f"图片已调整为 {new_w}×{new_h} 像素")

    def resize_preset(self, ratio_w, ratio_h):
        if not self.current_image:
            messagebox.showwarning("提示", "请先载入图片")
            return

        w, h = self.current_image.size
        current_ratio = w / h
        target_ratio = ratio_w / ratio_h

        if current_ratio > target_ratio:
            new_w = int(h * target_ratio)
            new_h = h
            x1 = (w - new_w) // 2
            y1 = 0
        else:
            new_h = int(w / target_ratio)
            new_w = w
            x1 = 0
            y1 = (h - new_h) // 2

        self.save_history()
        self.current_image = self.current_image.crop((x1, y1, x1 + new_w, y1 + new_h))
        self.update_canvas()
        messagebox.showinfo("完成", f"图片已裁剪为 {ratio_w}:{ratio_h} 比例")

    def enlarge_eyes(self):
        if not self.current_image:
            messagebox.showwarning("提示", "请先载入图片文件")
            return
        self.save_history()

        img = cv2.cvtColor(np.array(self.current_image), cv2.COLOR_RGB2BGR)
        h, w = img.shape[:2]

        map_x = np.zeros((h, w), dtype=np.float32)
        map_y = np.zeros((h, w), dtype=np.float32)
        for y in range(h):
            for x in range(w):
                map_x[y, x] = x
                map_y[y, x] = y

        center_x = w // 2
        center_y = h // 3
        eye_strength = 0.12
        radius = min(w, h) // 6

        for y in range(max(0, center_y - radius), min(h, center_y + radius)):
            for x in range(max(0, center_x - radius * 2), min(w, center_x + radius * 2)):
                dx = x - center_x
                dy = y - center_y
                dist = np.sqrt(dx ** 2 + dy ** 2)

                if dist < radius * 2:
                    weight = 1 - (dist / (radius * 2))
                    weight = weight ** 2

                    offset_x = dx * eye_strength * weight
                    offset_y = dy * eye_strength * weight

                    map_x[y, x] = x - offset_x
                    map_y[y, x] = y - offset_y

        res_img = cv2.remap(img, map_x, map_y, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        self.current_image = Image.fromarray(cv2.cvtColor(res_img, cv2.COLOR_BGR2RGB))
        self.update_canvas()
        messagebox.showinfo("完成", "自然大眼处理完毕")

    def beauty_face_slim(self):
        if not self.current_image:
            messagebox.showwarning("提示", "请先载入图片文件")
            return
        self.save_history()

        img = cv2.cvtColor(np.array(self.current_image), cv2.COLOR_RGB2BGR)
        h, w = img.shape[:2]
        center_x = w / 2.0
        slim_strength = 0.06

        map_x = np.zeros((h, w), dtype=np.float32)
        map_y = np.zeros((h, w), dtype=np.float32)
        for y in range(h):
            for x in range(w):
                map_x[y, x] = x
                map_y[y, x] = y

        ear_protect = w * 0.12
        for y in range(h):
            vert_weight = np.exp(-((y - h * 0.5) ** 2) / ((h * 0.3) ** 2))
            for x in range(w):
                if x < ear_protect or x > w - ear_protect:
                    continue

                dx = x - center_x
                x_dist = abs(dx)
                hori_weight = np.exp(-((x_dist - w * 0.15) ** 2) / ((w * 0.22) ** 2))
                total_weight = vert_weight * hori_weight

                if total_weight < 0.01:
                    continue
                offset = dx * slim_strength * total_weight
                map_x[y, x] = x + offset

        res_img = cv2.remap(img, map_x, map_y, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        self.current_image = Image.fromarray(cv2.cvtColor(res_img, cv2.COLOR_BGR2RGB))
        self.update_canvas()
        messagebox.showinfo("完成", "自然瘦脸处理完毕")

    def smooth_skin(self):
        if not self.current_image:
            return
        self.save_history()
        img = cv2.cvtColor(np.array(self.current_image), cv2.COLOR_RGB2BGR)
        h, w = img.shape[:2]
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        ycrcb = cv2.cvtColor(img, cv2.COLOR_BGR2YCrCb)
        lower_hsv = np.array([0, 10, 40], dtype=np.uint8)
        upper_hsv = np.array([45, 190, 255], dtype=np.uint8)
        mask_hsv = cv2.inRange(hsv, lower_hsv, upper_hsv)
        lower_ycrcb = np.array([0, 133, 77], dtype=np.uint8)
        upper_ycrcb = np.array([255, 173, 127], dtype=np.uint8)
        mask_ycrcb = cv2.inRange(ycrcb, lower_ycrcb, upper_ycrcb)
        skin_mask = cv2.bitwise_and(mask_hsv, mask_ycrcb)
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15))
        skin_mask = cv2.morphologyEx(skin_mask, cv2.MORPH_CLOSE, kernel, iterations=2)
        skin_mask = cv2.morphologyEx(skin_mask, cv2.MORPH_OPEN, kernel, iterations=1)
        skin_mask = cv2.GaussianBlur(skin_mask, (35, 35), 18)
        skin_mask = skin_mask.astype(np.float32) / 255.0
        skin_mask = np.expand_dims(skin_mask, axis=-1)
        img_float = img.astype(np.float32)
        pyramid = []
        current = img_float.copy()
        for i in range(3):
            pyramid.append(current)
            current = cv2.pyrDown(current)
        layer1 = cv2.bilateralFilter(pyramid[1], d=15, sigmaColor=60, sigmaSpace=60)
        layer2 = cv2.bilateralFilter(pyramid[2], d=20, sigmaColor=80, sigmaSpace=80)
        layer2_up = cv2.pyrUp(layer2, dstsize=(pyramid[1].shape[1], pyramid[1].shape[0]))
        layer1_blend = cv2.addWeighted(layer1, 0.6, layer2_up, 0.4, 0)
        layer1_up = cv2.pyrUp(layer1_blend, dstsize=(w, h))
        high_freq = cv2.subtract(img_float, layer1_up)
        detail_mask = np.abs(high_freq)
        detail_mask = np.clip(detail_mask * 1.5, 0, 1)
        high_freq_filtered = high_freq * detail_mask * 0.7
        skin_smoothed = layer1_up + high_freq_filtered
        skin_smoothed = np.clip(skin_smoothed, 0, 255).astype(np.uint8)
        final_img = img * (1 - skin_mask) + skin_smoothed * skin_mask
        final_img = np.clip(final_img, 0, 255).astype(np.uint8)
        self.current_image = Image.fromarray(cv2.cvtColor(final_img, cv2.COLOR_BGR2RGB))
        self.update_canvas()

    def whiten(self):
        if not self.current_image:
            return
        self.save_history()
        img = np.array(self.current_image)
        img_cv = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
        img_float = img_cv.astype(np.float32)
        hsv = cv2.cvtColor(img_cv, cv2.COLOR_BGR2HSV)
        ycrcb = cv2.cvtColor(img_cv, cv2.COLOR_BGR2YCrCb)
        lower_hsv = np.array([0, 12, 50], dtype=np.uint8)
        upper_hsv = np.array([42, 185, 255], dtype=np.uint8)
        mask_hsv = cv2.inRange(hsv, lower_hsv, upper_hsv)
        lower_ycrcb = np.array([0, 130, 75], dtype=np.uint8)
        upper_ycrcb = np.array([255, 175, 130], dtype=np.uint8)
        mask_ycrcb = cv2.inRange(ycrcb, lower_ycrcb, upper_ycrcb)
        skin_mask = cv2.bitwise_and(mask_hsv, mask_ycrcb)
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (13, 13))
        skin_mask = cv2.morphologyEx(skin_mask, cv2.MORPH_CLOSE, kernel, iterations=2)
        skin_mask = cv2.morphologyEx(skin_mask, cv2.MORPH_OPEN, kernel, iterations=1)
        skin_mask = cv2.GaussianBlur(skin_mask, (31, 31), 15)
        skin_mask = skin_mask.astype(np.float32) / 255.0
        skin_mask = np.expand_dims(skin_mask, axis=-1)
        ycrcb_float = ycrcb.astype(np.float32)
        Y, Cr, Cb = cv2.split(ycrcb_float)
        Y = np.clip(Y * 1.12 + 12, 0, 255)
        Cr = np.clip(Cr - 8, 0, 255)
        Cb = np.clip(Cb + 5, 0, 255)
        ycrcb_whiten = cv2.merge((Y, Cr, Cb))
        img_whiten_ycrcb = cv2.cvtColor(ycrcb_whiten.astype(np.uint8), cv2.COLOR_YCrCb2BGR)
        img_whiten_ycrcb = img_whiten_ycrcb.astype(np.float32)
        img_whiten_ycrcb[:, :, 2] = np.clip(img_whiten_ycrcb[:, :, 2] + 3, 0, 255)
        img_whiten_ycrcb[:, :, 1] = np.clip(img_whiten_ycrcb[:, :, 1] - 2, 0, 255)
        gray = cv2.cvtColor(img_float / 255.0, cv2.COLOR_BGR2GRAY)
        luminance_mask = 1.0 - (gray ** 0.7)
        luminance_mask = cv2.GaussianBlur(luminance_mask, (15, 15), 5)
        luminance_mask = np.expand_dims(luminance_mask, axis=-1)
        final_mask = skin_mask * luminance_mask * 0.85
        final_img = img_float * (1 - final_mask) + img_whiten_ycrcb * final_mask
        final_img = np.clip(final_img, 0, 255).astype(np.uint8)
        result = cv2.cvtColor(final_img, cv2.COLOR_BGR2RGB)
        self.current_image = Image.fromarray(result)
        self.update_canvas()

    def brighten(self):
        if not self.current_image:
            return
        self.save_history()
        img = np.array(self.current_image, np.float32) / 255.0
        hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
        h, s, v = cv2.split(hsv)
        v_new = v + (1.0 - v) * v * 0.35
        v_new = np.clip(v_new, 0, 1)
        hsv_new = cv2.merge((h, s, v_new))
        img_bright = cv2.cvtColor(hsv_new, cv2.COLOR_HSV2RGB)
        hsv_final = cv2.cvtColor(img_bright, cv2.COLOR_RGB2HSV)
        hsv_final[:, :, 1] = np.clip(hsv_final[:, :, 1] * 1.04, 0, 1)
        final = cv2.cvtColor(hsv_final, cv2.COLOR_HSV2RGB)
        final = np.clip(final * 255, 0, 255).astype(np.uint8)
        self.current_image = Image.fromarray(final)
        self.update_canvas()

    def saturate_up(self):
        if not self.current_image:
            return
        self.save_history()
        img = np.array(self.current_image, np.float32) / 255.0
        hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
        h, s, v = cv2.split(hsv)
        s_new = s + (1.0 - s) * s * 0.4
        s_new = np.clip(s_new, 0, 1)
        skin_hue_mask = np.logical_and(h >= 0, h <= 30 / 360)
        s_new[skin_hue_mask] = s[skin_hue_mask] + (1.0 - s[skin_hue_mask]) * s[skin_hue_mask] * 0.2
        hsv_new = cv2.merge((h, s_new, v))
        final = cv2.cvtColor(hsv_new, cv2.COLOR_HSV2RGB)
        final = np.clip(final * 255, 0, 255).astype(np.uint8)
        self.current_image = Image.fromarray(final)
        self.update_canvas()

    def contrast_up(self):
        if not self.current_image:
            return
        self.save_history()
        img = np.array(self.current_image, np.float32) / 255.0
        lab = cv2.cvtColor(img, cv2.COLOR_RGB2LAB)
        L, a, b = cv2.split(lab)

        def ps_contrast_curve(x, strength=0.4):
            if x < 0.25:
                return x * (1 + strength * 0.3)
            elif x > 0.75:
                return 1 - (1 - x) * (1 + strength * 0.3)
            else:
                return 0.5 + (x - 0.5) * (1 + strength)

        vectorized_curve = np.vectorize(ps_contrast_curve)
        L_new = vectorized_curve(L)
        L_blur = cv2.GaussianBlur(L_new, (5, 5), 1)
        L_detail = L_new - L_blur
        L_final = L_new + L_detail * 0.2
        lab_new = cv2.merge((L_final, a, b))
        final = cv2.cvtColor(lab_new, cv2.COLOR_LAB2RGB)
        final = np.clip(final * 255, 0, 255).astype(np.uint8)
        self.current_image = Image.fromarray(final)
        self.update_canvas()

    def warm_temp(self):
        if not self.current_image:
            return
        self.save_history()
        img = np.array(self.current_image, np.float32)
        gray = cv2.cvtColor(img / 255, cv2.COLOR_RGB2GRAY)
        tone_mask = cv2.GaussianBlur(gray, (25, 25), 9)
        r_channel = np.clip(img[:, :, 0] * (1 + tone_mask * 0.20), 0, 255)
        b_channel = np.clip(img[:, :, 2] * (1 - tone_mask * 0.14), 0, 255)
        img[:, :, 0] = r_channel
        img[:, :, 2] = b_channel
        img = np.clip(img, 0, 255).astype(np.uint8)
        self.current_image = Image.fromarray(img)
        self.update_canvas()

    def cool_temp(self):
        if not self.current_image:
            return
        self.save_history()
        img = np.array(self.current_image, np.float32)
        gray = cv2.cvtColor(img / 255, cv2.COLOR_RGB2GRAY)
        tone_mask = cv2.GaussianBlur(gray, (25, 25), 9)
        r_channel = np.clip(img[:, :, 0] * (1 - tone_mask * 0.14), 0, 255)
        b_channel = np.clip(img[:, :, 2] * (1 + tone_mask * 0.20), 0, 255)
        img[:, :, 0] = r_channel
        img[:, :, 2] = b_channel
        img = np.clip(img, 0, 255).astype(np.uint8)
        self.current_image = Image.fromarray(img)
        self.update_canvas()

    def toggle_eliminate(self):
        if not self.current_image:
            messagebox.showwarning("操作提醒", "请先载入图片再使用消除功能")
            return
        self.eliminate_mode = not self.eliminate_mode
        if self.eliminate_mode:
            self.eliminate_btn.config(text="关闭涂抹编辑模式")
        else:
            self.eliminate_btn.config(text="开启涂抹编辑模式")
            self.points = []
            self.update_canvas()

    def start_drawing(self, event):
        if not self.eliminate_mode or not self.current_image:
            return
        self.drawing = True
        self.points.append((event.x, event.y))

    def draw(self, event):
        if not self.drawing or not self.eliminate_mode:
            return
        self.points.append((event.x, event.y))
        self.update_canvas()
        if len(self.points) >= 2:
            self.canvas.create_line(self.points[-2], self.points[-1],
                                    fill="#ff3333", width=self.brush_size, capstyle=tk.ROUND, smooth=True)

    def stop_drawing(self, event):
        self.drawing = False

    def clear_drawing(self):
        self.points = []
        self.mask = None
        self.update_canvas()

    def run_eliminate(self):
        if not self.current_image or len(self.points) < 2:
            messagebox.showwarning("操作提醒", "请涂抹需要消除的画面区域")
            return
        self.save_history()
        w, h = self.current_image.size
        cw, ch = self.canvas.winfo_width(), self.canvas.winfo_height()
        scale = min(cw / w, ch / h)
        offset_x = (cw - w * scale) // 2
        offset_y = (ch - h * scale) // 2
        self.mask = np.zeros((h, w), dtype=np.uint8)
        for (x, y) in self.points:
            orig_x = int((x - offset_x) / scale)
            orig_y = int((y - offset_y) / scale)
            cv2.circle(self.mask, (orig_x, orig_y), int(self.brush_size / scale / 2), 255, -1)
        img = cv2.cvtColor(np.array(self.current_image), cv2.COLOR_RGB2BGR)
        result = cv2.inpaint(img, self.mask, 9, cv2.INPAINT_TELEA)
        self.current_image = Image.fromarray(cv2.cvtColor(result, cv2.COLOR_BGR2RGB))
        self.points = []
        self.mask = None
        self.update_canvas()
        messagebox.showinfo("处理完成", "瑕疵智能消除完毕")

    def save_history(self):
        if self.current_image:
            self.history.append(self.current_image.copy())
            # 重置快照（不影响其他功能）
            self._temp_snapshot = None
            self._vignette_snapshot = None
            self._grain_snapshot = None

    def open_image(self):
        path = filedialog.askopenfilename(filetypes=[("图片格式", "*.png;*.jpg;*.jpeg;*.bmp")])
        if not path: return
        self.original_image = Image.open(path).convert("RGB")
        self.current_image = self.original_image.copy()
        self.history.clear()
        self.eliminate_mode = False
        self.points = []
        self.exit_crop_mode()
        self._temp_snapshot = None
        self._vignette_snapshot = None
        self._grain_snapshot = None
        self.update_canvas()

    def save_image(self):
        if not self.current_image:
            messagebox.showwarning("保存提醒", "请先编辑图片内容")
            return
        path = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG高清图", "*.png"), ("JPG通用图", "*.jpg")])
        if path:
            self.current_image.save(path)
            messagebox.showinfo("保存成功", "图片已导出")

    def undo(self):
        if self.history:
            self.current_image = self.history.pop()
            self.eliminate_mode = False
            self.points = []
            self.exit_crop_mode()
            self._temp_snapshot = None
            self._vignette_snapshot = None
            self._grain_snapshot = None
            self.update_canvas()
        else:
            messagebox.showinfo("撤销提示", "暂无操作可撤回")

    def restore_original(self):
        if self.original_image:
            self.save_history()
            self.current_image = self.original_image.copy()
            self.history.clear()
            self.eliminate_mode = False
            self.points = []
            self.exit_crop_mode()
            self._temp_snapshot = None
            self._vignette_snapshot = None
            self._grain_snapshot = None
            self.update_canvas()

    def to_gray(self):
        if not self.current_image: return
        self.save_history()
        self.current_image = self.current_image.convert("L").convert("RGB")
        self.update_canvas()

    def sharpen(self):
        if not self.current_image: return
        self.save_history()
        en = ImageEnhance.Sharpness(self.current_image)
        self.current_image = en.enhance(2.2)
        self.update_canvas()

    def full_auto_beauty(self):
        if not self.current_image: return
        self.save_history()
        self.smooth_skin()
        self.whiten()
        self.sharpen()
        self.update_canvas()

    def filter_jp(self):
        if not self.current_image: return
        self.save_history()
        arr = np.array(self.current_image).astype(np.float32)
        gray = cv2.cvtColor(arr / 255, cv2.COLOR_RGB2GRAY)
        mask = cv2.GaussianBlur(gray, (21, 21), 7)
        arr[:, :, 0] = np.clip(arr[:, :, 0] * (1 + mask * 0.10), 0, 255)
        arr[:, :, 2] = np.clip(arr[:, :, 2] * (1 - mask * 0.08), 0, 255)
        arr = arr.astype(np.uint8)
        self.current_image = Image.fromarray(arr)
        self.update_canvas()

    def filter_vintage(self):
        if not self.current_image: return
        self.save_history()
        arr = np.array(self.current_image).astype(np.float32)
        gray = cv2.cvtColor(arr / 255, cv2.COLOR_RGB2GRAY)
        mask = cv2.GaussianBlur(gray, (21, 21), 7)
        arr[:, :, 0] = np.clip(arr[:, :, 0] * (1 + mask * 0.25), 0, 255)
        arr[:, :, 2] = np.clip(arr[:, :, 2] * (1 - mask * 0.20), 0, 255)
        arr = arr.astype(np.uint8)
        self.current_image = Image.fromarray(arr)
        self.update_canvas()

    def filter_bw(self):
        if not self.current_image: return
        self.save_history()
        img = np.array(self.current_image)
        gray = np.dot(img[..., :3], [0.299, 0.587, 0.114])
        gray = np.clip(gray * 1.1, 0, 255).astype(np.uint8)
        self.current_image = Image.fromarray(np.stack([gray, gray, gray], axis=-1))
        self.update_canvas()

    def filter_cold(self):
        if not self.current_image: return
        self.save_history()
        arr = np.array(self.current_image).astype(np.float32)
        gray = cv2.cvtColor(arr / 255, cv2.COLOR_RGB2GRAY)
        mask = cv2.GaussianBlur(gray, (21, 21), 7)
        arr[:, :, 0] = np.clip(arr[:, :, 0] * (1 - mask * 0.15), 0, 255)
        arr[:, :, 2] = np.clip(arr[:, :, 2] * (1 + mask * 0.22), 0, 255)
        arr = arr.astype(np.uint8)
        self.current_image = Image.fromarray(arr)
        self.update_canvas()

    def filter_warm(self):
        if not self.current_image: return
        self.save_history()
        arr = np.array(self.current_image).astype(np.float32)
        gray = cv2.cvtColor(arr / 255, cv2.COLOR_RGB2GRAY)
        mask = cv2.GaussianBlur(gray, (21, 21), 7)
        arr[:, :, 0] = np.clip(arr[:, :, 0] * (1 + mask * 0.22), 0, 255)
        arr[:, :, 2] = np.clip(arr[:, :, 2] * (1 - mask * 0.15), 0, 255)
        arr = arr.astype(np.uint8)
        self.current_image = Image.fromarray(arr)
        self.update_canvas()

    def enhance_quality(self):
        if not self.current_image:
            messagebox.showwarning("提示", "请先载入图片文件")
            return
        self.save_history()
        img = cv2.cvtColor(np.array(self.current_image), cv2.COLOR_RGB2BGR)
        lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
        L, a, b = cv2.split(lab)
        denoise_L = cv2.fastNlMeansDenoising(L, h=6, templateWindowSize=7, searchWindowSize=21)
        denoise_a = cv2.fastNlMeansDenoising(a, h=12, templateWindowSize=7, searchWindowSize=21)
        denoise_b = cv2.fastNlMeansDenoising(b, h=12, templateWindowSize=7, searchWindowSize=21)
        lab_denoise = cv2.merge((denoise_L, denoise_a, denoise_b))
        img_denoise = cv2.cvtColor(lab_denoise, cv2.COLOR_LAB2BGR)
        kernel = np.array([[0, -0.15, 0], [-0.15, 1.6, -0.15], [0, -0.15, 0]], dtype=np.float32)
        final_res = cv2.filter2D(img_denoise, -1, kernel)
        self.current_image = Image.fromarray(cv2.cvtColor(final_res, cv2.COLOR_BGR2RGB))
        self.update_canvas()
        messagebox.showinfo("修复完成", "PS级降噪细节增强处理完毕")

    def upscale(self):
        if not self.current_image:
            messagebox.showwarning("提示", "请先载入图片文件")
            return
        self.save_history()
        img = cv2.cvtColor(np.array(self.current_image), cv2.COLOR_RGB2BGR)
        h, w = img.shape[:2]
        enlarge_img = cv2.resize(img, (w * 2, h * 2), cv2.INTER_LANCZOS4)
        sharp_kernel = np.array([[0, -1, 0], [-1, 5.2, -1], [0, -1, 0]])
        enlarge_img = cv2.filter2D(enlarge_img, -1, sharp_kernel)
        self.current_image = Image.fromarray(cv2.cvtColor(enlarge_img, cv2.COLOR_BGR2RGB))
        self.update_canvas()
        messagebox.showinfo("放大完成", "无损超分放大结束")


if __name__ == "__main__":
    root = tk.Tk()
    app = ImageProcessorApp(root)
    root.mainloop()